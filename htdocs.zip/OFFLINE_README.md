# POS Offline Setup

This project has been modified to load dependencies from local `assets/` instead of online CDNs.

## What's changed
- Rewrote script and stylesheet tags in project files to point to `assets/`.
- Added one-time setup scripts to download the exact library versions referenced in your code:
  - `setup_deps.sh` (Linux/macOS, requires `curl`)
  - `setup_deps.ps1` (Windows PowerShell)

## One-time setup
Run ONE of the following from the `POS` folder:

### Windows (PowerShell)
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
./setup_deps.ps1
```

### Linux/macOS
```bash
bash ./setup_deps.sh
```

This will download and place the libraries to:
- `assets/js/`
- `assets/css/`
- `assets/fonts/`

> Note: Google Fonts must be downloaded manually into `assets/fonts/` and defined in `assets/fonts/local-fonts.css` (a template is provided).

## Run locally (offline)
After completing the one-time setup, you can disconnect from the internet and run the project on your local server (XAMPP/WAMP/LAMP).

## Dependency versions
- jQuery: 2.1.1, 3.6.0 (and 1.3.2 legacy reference if used)
- Bootstrap: 3.4.1
- Font Awesome: 6.0.0
- Vue: 2.1.10 (upgrade later to 2.7.x if needed)
- WebRTC adapter: 3.3.3
- Instascan: from GitHub mirror
- html5-qrcode: 2.3.4

You may upgrade versions by editing the download URLs inside the setup scripts.
