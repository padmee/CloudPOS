<?php
// Include your database configuration
include('../gpsconnect.php');

// Select the latest location data for each device with date and time
$sql = "SELECT a.device, a.lat, a.lng, a.created_date
        FROM tbl_gps a
        INNER JOIN (
            SELECT device, MAX(created_date) AS latest_datetime
            FROM tbl_gps
            GROUP BY device
        ) b ON a.device = b.device AND a.created_date = b.latest_datetime
        ORDER BY a.device";

$result = $db->query($sql);

if ($result) {
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($rows);
} else {
    echo json_encode(array()); // Return an empty array in case of an error
}
?>
