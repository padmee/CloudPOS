<?php
session_start();
include('../connect.php');
$a = $_POST['remark'];
$b = $_POST['invoice_number'];
$c = $_POST['ptype'];
$d = $_POST['price'];
$e = $_POST['supplier'];
$f = $_POST['mtype'];
$g = $_POST['o_price'];
$h = $_POST['dueprice'];
$j = $_POST['date'];
// $k = $_POST['bcode'];
$bcode=$_SESSION['SESS_BCODE'];  
$addeduser=$_SESSION['SESS_FIRST_NAME'];

$fileName = $_FILES['filename']['name'];

		$target = "images/transactions/";		
		$fileTarget = $target.$fileName;	
		$tempFileName = $_FILES["filename"]["tmp_name"];

$result = move_uploaded_file($tempFileName,$fileTarget);



$sql = "INSERT INTO transaction (remark,invoice_number,ptype,price,supplier,mtype,o_price,dueprice,date,bcode,addeduser,images) VALUES (:a,:b,:c,:d,:e,:f,:g,:h,:j,:bcode,:addeduser,:fileTarget)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':f'=>$f,':g'=>$g,':h'=>$h,':j'=>$j,':bcode'=>$bcode,':addeduser'=>$addeduser,':fileTarget'=>$fileTarget));


// ✅ Update cash column in sales table using invoice_number
$update = $db->prepare("UPDATE sales SET cash = :cash WHERE invoice_number = :invoice_number");
$update->execute(array(':cash' => $g, ':invoice_number' => $b));


header("location: transaction.php");

?>