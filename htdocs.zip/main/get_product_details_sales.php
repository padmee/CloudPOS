<?php
include('../connect.php');

$product = $_GET['product'];  // Updated variable name

$result = $db->prepare("SELECT * FROM products WHERE product = :product");  // Updated field name
$result->bindParam(':product', $product);
$result->execute();

$product_data = $result->fetch(PDO::FETCH_ASSOC);

echo json_encode($product_data);
?>
