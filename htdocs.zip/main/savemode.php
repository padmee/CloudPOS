<?php
session_start();
include('../connect.php');
$a = $_POST['mode'];

$bcode=$_SESSION['SESS_BCODE'];





$sql = "INSERT INTO mode (mode,bcode) VALUES (:a,:bcode)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':bcode'=>$bcode));
header("location: mode.php");


?>