<!DOCTYPE html>
<html>
<head>
<?php require_once ('auth.php');?>
<title>
POS
</title>
 <link href="css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
  
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


  <link rel="stylesheet" href="css/font-awesome.min.css">
<style type="text/css">
    .sidebar-nav {
        padding: 9px 0;
    }

  @media print {
    .in {
        display: none;
    }

    .some_element {
        page-break-after: always;
    }

    /* Adjust the width and height for the logo in print view */
    #companyLogo {
        width: 80px !important;
        height: auto !important;
    }
}

}

</style>


    

    
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        
        
        
    <!--<link href="css/preview.css" rel="stylesheet">-->
    
    
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>

<script type="text/javascript">
var docprint;

function Clickheretoprint() {
    var disp_setting = "toolbar=yes,location=no,width=50mm,height=auto,directories=yes,menubar=yes,margin-top=auto,margin-bottom=auto,page-break-after=always,page-break-before=avoid";
    disp_setting += "scrollbars=yes,top=25,width=50mm,text-align:left,page-break-after:always;";

    var content_value = document.getElementById("content").innerHTML;

    docprint = window.open("", "", disp_setting);
    docprint.document.open();
    docprint.document.write('<head><title>Print</title></head><body onLoad="self.print()" style="width:50mm;text-align:left;font-size:13px;font-family:arial;border:1px solid white;height:auto;page-break-after:always;page-break-before:avoid;">');
    docprint.document.write(content_value);
    docprint.document.write('</body>');
    docprint.document.close();

   

 // Listen for the afterprint event
    window.addEventListener('afterprint', function () {
        // Close the print preview window when the printing is completed
        if (docprint) {
            docprint.close();
        }
    });
}
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    window.print(); // Trigger print on load

    // After printing is done, redirect back to sales page
    window.onafterprint = function () {
        window.location.href = "sales.php?id=cash=<?php echo $finalcode; ?>";
    };
});
</script>



<!------------------------------------>




<script>


document.onkeydown = function(evt) {
    evt = evt || window.event;
    
    var isEscape = false;
    if ("Back" in evt) {
        isEscape = (evt.key === "Escape" || evt.key === "Esc");
    } else {
        isEscape = (evt.keyCode === 27);
    }
    if (isEscape) {
        // alert("Escape");
        document.getElementById("back").click();
    }
    
    var isShift = false;
    if ("Print" in evt) {
        isShift = (evt.key === "Shift" || evt.key === "shift");
    } else {
        isShift = (evt.keyCode === 16);
    }
    if (isShift) {
      //   alert("Escape");
        document.getElementById("print").click();
    }
};



</script>




<?php
$invoice=$_GET['invoice'];
include('../connect.php');
$result = $db->prepare("SELECT * FROM sales WHERE invoice_number= :userid");
$result->bindParam(':userid', $invoice);
$result->execute();
for($i=0; $row = $result->fetch(); $i++){
$cname=$row['name'];
$invoice=$row['invoice_number'];
$date=$row['date'];
$due_date=$row['due_date'];
$cashier=$row['cashier'];
$discount=$row['discountamount'];

$pt=$row['type'];
$am=$row['amount'];
if($pt=='cash'){
$cash=$row['cash'];
$amount=$cash-$am;
}
}
?>
<?php
function createRandomPassword() {
	$chars = "003232303232023232023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 7) {

		$num = rand() % 33;

		$tmp = substr($chars, $num, 1);

		$pass = $pass . $tmp;

		$i++;

	}
	return $pass;
}
$finalcode=createRandomPassword();
?>




<body>
    
    
    <?php
include('../connect.php');

$bcode=$_SESSION['SESS_BCODE'];
$result = $db->prepare("SELECT * FROM branch WHERE bcode='$bcode'");
$result->execute();

if ($row = $result->fetch()) {
    $branchCode = $row['bcode'];
    $branchName = $row['bname'];
    $branchPhone = $row['bphone'];
    $branchAddress = $row['baddress'];
?>

    <?php
include('../connect.php');

$result = $db->prepare("SELECT * FROM company");
$result->execute();

if ($row = $result->fetch()) {
    $companyname = $row['companyname'];
    $companylocation = $row['companylocation'];
    $companyphone = $row['companyphone'];
    $companylogo = $row['companylogo'];
    $companyreg = $row['companyreg'];
?>



<!--		<div class="pull-right" style="margin-right:100px;" id="Print">-->
<!--    <button class="btn btn-success btn-large" onclick="printBill()" id="Print">-->
<!--        <i class="icon-print"></i> Print-->
<!--    </button>-->
<!--</div>-->

		
<div class="content" id="content">
<div style="margin: 0 auto; padding: 0; width: 70mm; font-weight: normal;">
	<div style="width: 70mm; height: 190px;" >
	<div style="width: 70mm; float: left;">
	    <center>
	        
	    <img src="<?= htmlspecialchars($companylogo) ?>" alt="Company Logo" id="companyLogo" class="company-logo" width="80" height="80">

	        
	        
	<!--<img id="companyLogo" src="<php echo $companylogo; ?>" alt="Company Logo" width="80" height="80"><br>-->
	<div style="font:bold 25px 'Aleo';">Sales Receipt</div>
	<?php echo $companyname; ?> - <?php echo $bcode; ?>	<br>
	<?php echo $branchAddress; ?>	<br>
	<?php echo $branchPhone; ?><br><br>
	
	<?php
				}
			?>
			<?php
				}
			?>
	<div>
    <?php
    $resulta = $db->prepare("SELECT * FROM customer WHERE customer_name= :a");
    $resulta->bindParam(':a', $cname);
    $resulta->execute();
    for($i=0; $rowa = $resulta->fetch(); $i++){
        $address = $rowa['address'];
        $contact = $rowa['contact'];
    }
    ?>
</div>

	
	<tr>
			<td>Date :</td>
			<td><?php echo $date ?></td>
		</tr>
		<br>	
	<tr>
			<td>Order :</td>
			<td><?php echo $invoice ?></td>
		</tr><br>
		
		<tr>
    <td>Payment Type:</td>
    <td><?php echo $pt; ?></td>
</tr>
		
	</center>
	<div>
	<?php
	$resulta = $db->prepare("SELECT * FROM customer WHERE customer_name= :a");
	$resulta->bindParam(':a', $cname);
	$resulta->execute();
	for($i=0; $rowa = $resulta->fetch(); $i++){
	$address=$rowa['address'];
	$contact=$rowa['contact'];
	}
	?>
	</div>
	</div>
	<div style="width: 75mm; float: left; height: 10px;">
	<table cellpadding="3" cellspacing="0" style="font-family: arial; font-size: 12px;text-align:left;width : 55mm;">
	
	</table>
	
	</div>
	<div class="clearfix"></div>
	</div>
	<br><center><div style="width: 70mm; margin-top:-100px;">
	    	<!--<table border="1" cellpadding="4" cellspacing="0" style="font-family: arial; font-size: 12px;	text-align:left;" width="100%">-->
<table cellpadding="4" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: arial; font-size: 12px; text-align: left;">

		<thead>
			<tr>

				<th> Item</th>
				<th> Qty </th>
				<th> Price </th>
				<th> Disc </th>
				<th> Amount </th>
			</tr>
		</thead>
		<tbody>
			
				<?php
					$id=$_GET['invoice'];
					$result = $db->prepare("SELECT * FROM sales_order WHERE invoice= :userid");
					$result->bindParam(':userid', $id);
					$result->execute();
					for($i=0; $row = $result->fetch(); $i++){
				?>
				<tr class="record">

				<td><?php echo $row['name']; ?></td>
				<td><?php echo $row['qty']; ?></td>
			
				<td>
				<?php
				$dfdf=$row['price'];
				echo formatMoney($dfdf, true);
				?>
				</td>
				<td>
                   <?php
                   $itemDiscount = $row['discount'];
                   if ($itemDiscount > 0) {
                      echo $itemDiscount;
                  } else {
                      echo '';
                   }
                   ?>
                </td>
                
                <td>
				<?php
				$dfdf=$row['amount'];
				echo formatMoney($dfdf, true);
				?>
				</td>
				</tr>
				<?php
					}
				?>
			</table>
			<table>
				<!-- Display discount field -->
<tr>
    <td colspan="5" style=" text-align:right;"><strong style="font-size: 15px;"> Full Bill Discount Rs:&nbsp;</strong></td>
    <td colspan="2">
        <strong style="font-size: 15px;">
            <?php echo formatMoney($discount, true); ?>
        </strong>
    </td>
</tr>

<!-- Display total with discount -->
<tr>
    <td colspan="5" style=" text-align:right;"><strong style="font-size: 15px;">Total (with all Discounts):&nbsp;</strong></td>
    <td colspan="2">
        <strong style="font-size: 15px;">
            <?php
            $sdsd=$_GET['invoice'];
            $resultas = $db->prepare("SELECT sum(amount) FROM sales_order WHERE invoice= :a");
            $resultas->bindParam(':a', $sdsd);
            $resultas->execute();
            for($i=0; $rowas = $resultas->fetch(); $i++){
                $fgfg=$rowas['sum(amount)'];

                // Apply discount to the total
            
                $total_with_discount = $fgfg - $discount;

                echo formatMoney($total_with_discount, true);
            }
            ?>
        </strong>
    </td>
</tr>

				<?php if($pt=='cash'){
				?>
				<tr>
					<td colspan="5"style=" text-align:right;"><strong style="font-size: 15px; color: #222222;">Cash Tendered:&nbsp;</strong></td>
					<td colspan="2"><strong style="font-size: 15px; color: #222222;">
					<?php
					echo formatMoney($cash, true);
					?>
					</strong></td>
				</tr>
				<?php
				}
				?>
				
				
				<?php if ($pt == 'credit' || $pt == 'cheques') : ?>
<div>
    <?php
    $resulta = $db->prepare("SELECT * FROM customer WHERE customer_name= :a");
    $resulta->bindParam(':a', $cname);
    $resulta->execute();
    for($i=0; $rowa = $resulta->fetch(); $i++){
        $address = $rowa['address'];
        $contact = $rowa['contact'];
    }
    ?>
    <!-- Display customer information here -->
    Customer : <?php echo $cname; ?><br>
    Customer TP: <?php echo $contact; ?><br><br>
</div>
<?php endif; ?>

				
				
				<tr>
					<td colspan="5" style=" text-align:right;"><strong style="font-size: 15px; color: #222222;">
					<font style="font-size:15px;">
					<?php
					if($pt=='cash'){
					echo 'Balance:';
					}
					if($pt=='credit'){
					echo 'Due Date:';
					}
					if($pt=='cheques'){
					echo 'Due Date:';
					}
					?>&nbsp;
					</strong></td>
					<td colspan="2"><strong style="font-size: 15px; color: #222222;">
					<?php
					function formatMoney($number, $fractional=false) {
						if ($fractional) {
							$number = sprintf('%.2f', $number);
						}
						while (true) {
							$replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
							if ($replaced != $number) {
								$number = $replaced;
							} else {
								break;
							}
						}
						return $number;
					}
					if($pt=='credit'){
					echo $due_date;
					}
					if($pt=='cheques'){
					echo $due_date;
					}
					if($pt=='cash'){
					$change = $cash - $total_with_discount;
                echo formatMoney($change, true);
					}
					?>
					</strong></td>
				</tr>
				</table>
		</tbody>
		<br>
		
		<center><div style="font:bold 10px 'Aleo';">Powerd by : Buddy Technical Solution</div>
	<div style="font:bold 10px 'Aleo';">www.ebuddy.lk / www.info@ebuddy.lk / 0711461785</div>	<br><br>
	</center>
		
	
			
			         
				
	
	
	</div>
	</div>
	</div>
	</div>
	

	
	

		
		
		
		
</div>
</div>


