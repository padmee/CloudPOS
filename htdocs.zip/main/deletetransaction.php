<?php
// 	include('../connect.php');
// 	$id=$_GET['id'];
// 	$result = $db->prepare("DELETE FROM transaction WHERE transaction_id= :memid");
// 	$result->bindParam(':memid', $id);
// 	$result->execute();







include('../connect.php');

$id = $_GET['id'];

// Get the file path of the image before deleting from the database
$getImagePath = $db->prepare("SELECT images FROM transaction WHERE transaction_id = :memid");
$getImagePath->bindParam(':memid', $id);
$getImagePath->execute();
$imagePathResult = $getImagePath->fetch(PDO::FETCH_ASSOC);

if ($imagePathResult) {
    // Delete the image file if it exists
    $imagePath = $imagePathResult['images'];
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
}

// Delete the transaction record from the database
$deleteTransaction = $db->prepare("DELETE FROM transaction WHERE transaction_id = :memid");
$deleteTransaction->bindParam(':memid', $id);
$deleteTransaction->execute();






?>