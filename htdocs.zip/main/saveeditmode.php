<?php
// configuration
include('../connect.php');

// new data




$id = $_POST['memi'];
$a = $_POST['mode'];

$k = $_POST['bcode'];



// query
$sql = "UPDATE mode 
        SET  mode=?
		WHERE mode_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$id));
header("location: mode.php");

?>