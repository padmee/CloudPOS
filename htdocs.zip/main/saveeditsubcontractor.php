<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['memi'];
$a = $_POST['subcontractor_name'];
$b = $_POST['subcontractor_address'];
$c = $_POST['subcontractor_contact'];
$d = $_POST['contact_person'];
$e = $_POST['note'];
// query
$sql = "UPDATE subcontractor 
        SET subcontractor_name=?, subcontractor_address=?, subcontractor_contact=?, contact_person=?, note=?
		WHERE subcontractor_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$b,$c,$d,$e,$id));
header("location: subcontractor.php");

?>