<?php
	require_once('auth.php');
?>
<html>
<head>
<title>POS</title>

<link href="css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link href="css/bootstrap-responsive.css" rel="stylesheet">
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


<style type="text/css">
  body {
    padding-top: 60px;
    padding-bottom: 40px;
  }
  .sidebar-nav {
    padding: 9px 0;
  }
</style>

<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    });
  });

  function Clickheretoprint() {
    var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
    disp_setting += "scrollbars=yes,width=700, height=400, left=100, top=25";
    var content_value = document.getElementById("content").innerHTML;
    var docprint = window.open("", "", disp_setting);
    docprint.document.open();
    docprint.document.write('<head><title>Print</title></head><body onLoad="self.print()" style="width: 700px; font-size:11px; font-family:arial; font-weight:normal;">');
    docprint.document.write(content_value);
    docprint.document.write('</body></html>');
    docprint.document.close();
    docprint.focus();
  }
</script>

<script src="assets/js/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function () {
  var isBarcodeScanned = false;

  // 1. When barcode is typed and Enter is pressed
  $(document).keydown(function (event) {
    if (event.which == 13 && isBarcodeScanned) {
      event.preventDefault();
      var productCode = $('#product_code').val();
      getProductDetails(productCode);
      fetchLastPrice(productCode);
      $('#qty').focus();
      isBarcodeScanned = false;
    }
  });

  $('#product_code').on('input', function () {
    isBarcodeScanned = true;
  });

  // 2. When product is selected from dropdown
  $('#productSelect').on('change', function () {
    var productCode = $(this).val();
    $('#product_code').val(productCode); // Also sync to input
    fetchLastPrice(productCode);
  });

  function fetchLastPrice(productCode) {
    if (!productCode) return;

    $.ajax({
      url: 'get_last_price.php',
      type: 'GET',
      data: { product_code: productCode },
      dataType: 'json',
      success: function (data) {
        if (data) {
          $('#txt1').val(data.o_price);
          $('#txt2').val(data.price);
          $('#qty').val(data.qty);
        } else {
          $('#txt1').val('');
          $('#txt2').val('');
          $('#qty').val('');
        }
      }
    });
  }

  function getProductDetails(productCode) {
    $.ajax({
      url: 'get_product_details.php',
      type: 'GET',
      data: { product_code: productCode },
      dataType: 'json',
      success: function (data) {
        if (data) {
          $('#productSelect').empty().append($('<option>', {
            value: data.product_code,
            text: data.product_code + ' - ' + data.product_name
          }));
        } else {
          $('#productSelect').empty();
        }
      }
    });
  }
});
</script>


</head>
<body>
<?php include('navfixed.php'); ?>

<div class="container-fluid">
  <div class="row-fluid">
    <div class="span2">
      <div class="well sidebar-nav">
        <ul class="nav nav-list">
          <li><a href="index.php"><i class="icon-dashboard icon-2x"></i> Dashboard </a></li>
          <li><a href="sales.php?id=cash&invoice=<?php echo $finalcode ?>"><i class="icon-shopping-cart icon-2x"></i> Sales</a></li>
          <li class="active"><a href="products.php"><i class="icon-list-alt icon-2x"></i> Products</a></li>
          <li><a href="customer.php"><i class="icon-group icon-2x"></i> Customers</a></li>
          <li><a href="supplier.php"><i class="icon-group icon-2x"></i> Suppliers</a></li>
          <li><a href="salesreport.php?d1=0&d2=0"><i class="icon-bar-chart icon-2x"></i> Sales Report</a></li>
        </ul>
      </div>
    </div>

    <div class="span10">
      <div class="contentheader">
        <i class="icon-dashboard"></i> Dashboard
      </div>
      <ul class="breadcrumb">
        <a href="dashboard.php"><li>Dashboard</li></a> /
        <li class="active">Purchase Lists</li>
      </ul>

      <div id="maintable">
        <a href="index.php"><button class="btn btn-default btn-large"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a><br><br>

        <div>
          <?php
          $id = $_GET['iv'];
          include('../connect.php');
          $resultaz = $db->prepare("SELECT * FROM purchases WHERE invoice_number= :xzxz");
          $resultaz->bindParam(':xzxz', $id);
          $resultaz->execute();
          while ($rowaz = $resultaz->fetch()) {
            echo 'Transaction ID : TR-'.$rowaz['transaction_id'].'<br>';
            echo 'Invoice Number : '.$rowaz['invoice_number'].'<br>';
            echo 'Date : '.$rowaz['date'].'<br>';
            echo 'Supplier : '.$rowaz['suplier'].'<br>';
            echo 'Remarks : '.$rowaz['remarks'].'<br><br>';
          }
          ?>
        </div>
        <br>

        <form action="savepurchasesitem.php" method="post">
          <input type="hidden" name="invoice" value="<?php echo $_GET['iv']; ?>" />
          <input type="text" name="product_code" id="product_code" placeholder="Product Code" autocomplete="off" style="width: 200px; height:30px; margin-right: 4px;" />

          <select id="productSelect" name="product" style="width: 600px;">
            <option></option>
            <?php
            include('../connect.php');
            $bcode = $_SESSION['SESS_BCODE'];
            $result = $db->prepare("SELECT * FROM products WHERE bcode=?");
            $result->execute([$bcode]);
            while ($row = $result->fetch()) {
              echo "<option value='{$row['product_code']}'>{$row['product_code']} - {$row['product_name']}</option>";
            }
            ?>
          </select>

          <input type="number" name="qty" id="qty" placeholder="Qty" autocomplete="off" style="width: 68px; height:30px; margin-right: 4px;" />
          
          <input type="text" id="txt1" placeholder="Original Price" style="width:265px; height:30px;" name="o_price" onkeyup="calculateProfit();" required />
          <input type="text" id="txt2" placeholder="Selling Price" style="width:265px; height:30px;" name="price" onkeyup="calculateProfit();" required /><br>
          <span>Expiry Date : </span><input type="date" placeholder="Expire Date"value="<?php echo date('m/d/y'); ?>" style="width:265px; height:30px;" name="exdate" /><br>

          <button type="submit" class="btn btn-info" style="width: 123px; height:35px; margin-top:-5px;"><i class="icon-save icon-large"></i> Save</button>
        </form>

        <div class="content" id="content">
          <table class="table table-bordered" id="resultTable" data-responsive="table">
            <thead>
              <tr>
                 <th width="15%"> Product Code </th>
                <th width="30%"> Name and Details </th>
                <th width="10%"> Qty </th>
                <th width="15%"> Item Price </th>
                <th width="15%"> Selling Price </th>
                <th width="15%"> Expire Date </th>
                <th width="15%"> Full Cost </th>
                <th width="12%"> Action </th>
              </tr>
            </thead>
            <tbody>
              <?php
              $result = $db->prepare("SELECT * FROM purchases_item WHERE invoice= ?");
              $result->execute([$id]);
              while ($row = $result->fetch()) {
                echo "<tr class='record'>";
                $product_code = $row['product_code'];
                $resultss = $db->prepare("SELECT * FROM products WHERE product_code= ?");
                $resultss->execute([$product_code]);
                $product = $resultss->fetch();
                echo "<td>{$row['product_code']}</td>";
                echo "<td>{$product['product_name']}</td>";
                echo "<td>{$row['qty']}</td>";
                echo "<td>{$row['o_price']}</td>";
                echo "<td>{$row['price']}</td>";
                echo "<td>{$row['exdate']}</td>";
                echo "<td>" . formatMoney($row['cost'], true) . "</td>";
                echo "<td><center><a href='deletep.php?id={$row['id']}&invoice={$_GET['iv']}&qty={$row['qty']}&code={$row['product_code']}'><button class='btn btn-danger btn-mini'><i class='icon-trash'></i> Delete</button></a></center></td>";
                echo "</tr>";
              }
              ?>
              <tr>
                <td colspan="6"><strong style="font-size: 12px; color: #222222;">Total:</strong></td>
                <td colspan="2"><strong style="font-size: 12px; color: #222222;">
                  <?php
                  function formatMoney($number, $fractional = false) {
                    if ($fractional) {
                      $number = sprintf('%.2f', $number);
                    }
                    while (true) {
                      $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
                      if ($replaced != $number) {
                        $number = $replaced;
                      } else {
                        break;
                      }
                    }
                    return $number;
                  }

                  $resultas = $db->prepare("SELECT sum(cost) as total FROM purchases_item WHERE invoice= ?");
                  $resultas->execute([$id]);
                  $rowas = $resultas->fetch();
                  echo formatMoney($rowas['total'], true);
                  ?>
                </strong></td>
              </tr>
            </tbody>
          </table>
        </div><br>

        <button style="width: 123px; height:35px; float:right;" class="btn btn-success btn-large" onclick="Clickheretoprint()">
          <i class="icon icon-print icon-large"></i> Print
        </button>

        <div class="clearfix"></div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
