



<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="assets/js/adapter-3.3.3.min.js"></script>
<script type="text/javascript" src="assets/js/vue-2.1.10.min.js"></script>
<script type="text/javascript" src="assets/js/instascan.min.js"></script>
<link rel="stylesheet" href="assets/css/bootstrap-3.4.1.min.css">
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>



    

        

<form action="savetransaction.php" method="post" enctype="multipart/form-data">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Transaction</h4></center>
<hr>
<div id="ac">


    <input type="hidden" name="bcode" value="<?php echo $_SESSION['SESS_BCODE'];?>" />

   <span>Transaction Mode: </span>
<select name="mtype"  style="width:265px; height:30px; margin-left:-5px;" Required>
<option></option>
	
		<option>Income</option>
		<option>Outcome</option>

</select><br>
                
<span>Payment Type: </span>
<select name="ptype"  style="width:265px; height:30px; margin-left:-5px;" Required>
<option></option>
	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM payment_type");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['ptype']; ?></option>
	<?php
	}
	?>
</select><br>

<span>Supplier : </span>
<select name="supplier"  style="width:265px; height:30px; margin-left:-5px;">
<option></option>
	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM supliers");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['suplier_name']; ?></option>
	<?php
	}
	?>
</select><br>                


<span>Invoice Number : </span>
<input type="text" id="invoice_number" style="width:265px; height:30px;" name="invoice_number" Required/><br>

<span>Date Arrival: </span>
<input type="date" id="date" style="width:265px; height:30px;" name="date" /><br>

<span>Full Amount : </span>
<input type="text" id="txt1" style="width:265px; height:30px;" name="price" onkeyup="sum();" Required/><br>

<span>Paied Price : </span>
<input type="text" id="txt2" style="width:265px; height:30px;" name="o_price" onkeyup="sum();" Required/><br>

<span>Due price : </span>
<input type="text" id="txt3" style="width:265px; height:30px;" name="dueprice" readonly><br>




<span>Remark : </span><input type="text" style="width:265px; height:30px;" name="remark" /><br>

<span>Image : </span><input type="file" name="filename" placeholder="Select Image" class="box"><br>
<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;" type="submit" name="submit" value="Upload"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>


        
</form>


<script>
document.getElementById('invoice_number').addEventListener('blur', function () {
    var invoiceNumber = this.value.trim();
    if (invoiceNumber !== "") {
        fetch('get_invoice_details.php?invoice=' + encodeURIComponent(invoiceNumber))
            .then(response => response.json())
            .then(data => {
                if (data && data.amount) {
                    // Fix the date format to YYYY-MM-DD if needed
                    let dateParts = data.date.split(' ')[0].split('/');
                    let formattedDate = '20' + dateParts[2] + '-' + dateParts[0].padStart(2, '0') + '-' + dateParts[1].padStart(2, '0');

                    document.getElementById('date').value = formattedDate;

                    // Amount from invoice
                    document.getElementById('txt1').value = data.amount;

                    // Assume paid = amount - discountamount
                    let paid = parseFloat(data.amount) - parseFloat(data.discountamount || 0);
                    document.getElementById('txt2').value = paid.toFixed(2);

                    // Due = amount - paid
                    document.getElementById('txt3').value = (parseFloat(data.amount) - paid).toFixed(2);
                } else {
                    alert("Invoice not found or data incomplete.");
                }
            })
            .catch(error => {
                console.log("Fetch error: ", error);
            });
    }
});
</script>

