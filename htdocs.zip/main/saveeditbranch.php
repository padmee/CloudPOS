<?php
// configuration
include('../connect.php');

$id = $_POST['memi'];
$bcode = $_POST['bcode'];
$bname = $_POST['bname'];
$baddress = $_POST['baddress'];
$bphone = $_POST['bphone'];
$oldImage = $_POST['old_image'] ?? '';

$imagePath = $oldImage;

// Check if a new image was uploaded
if (!empty($_FILES['filename']['name'])) {
    $fileName = basename($_FILES['filename']['name']);
    $targetDir = "images/branches/";
    $targetFile = $targetDir . $fileName;
    $tempFileName = $_FILES["filename"]["tmp_name"];

    // Validate and move file
    $check = getimagesize($tempFileName);
    if ($check !== false) {
        if (move_uploaded_file($tempFileName, $targetFile)) {
            $imagePath = $targetFile;
        } else {
            echo "<script>alert('Image upload failed.'); history.back();</script>";
            exit;
        }
    } else {
        echo "<script>alert('Invalid image file.'); history.back();</script>";
        exit;
    }
}

// Update query
$sql = "UPDATE branch 
        SET bcode = ?, bname = ?, baddress = ?, bphone = ?, images = ?
        WHERE id = ?";
$q = $db->prepare($sql);
$q->execute([$bcode, $bname, $baddress, $bphone, $imagePath, $id]);

header("location: branchview.php");
exit;
?>
