<?php
include('../connect.php');

$bcode = $_POST['bcode'] ?? '';
// $bcode = $_SESSION['SESS_BCODE'];
$sale_date = $_POST['sale_date'] ?? date('Y-m-d');

if (!$bcode) {
    echo "Branch code is required.";
    exit;
}

// Fetch company details (assuming one record)
$companyStmt = $db->prepare("SELECT * FROM company LIMIT 1");
$companyStmt->execute();
$company = $companyStmt->fetch(PDO::FETCH_ASSOC);

// Fetch branch details using session branch code

$branchStmt = $db->prepare("SELECT * FROM branch WHERE bcode = :bcode LIMIT 1");
$branchStmt->bindParam(':bcode', $bcode);
$branchStmt->execute();
$branch = $branchStmt->fetch(PDO::FETCH_ASSOC);


// Fetch summary for branch & date
$stmt = $db->prepare("SELECT * FROM dailysales WHERE sale_date = ? AND bcode = ?");
$stmt->execute([$sale_date, $bcode]);
$summary = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$summary) {
    echo "No summary found for this branch and date.";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daily Summary Receipt</title>
    
    
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


    <style>
        body { font-family: monospace; width: 80mm; margin: 0 auto; }
        h2, h3 { text-align: center; margin: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        td { padding: 5px; }
        .total { font-weight: bold; }
        .company-logo { max-height: 80px; margin-bottom: 10px; }
    </style>
</head>
<body onload="window.print();">

<div style="text-align:center; margin-bottom:15px;">
    <?php if (!empty($company['companylogo'])): ?>
        <img src="<?= htmlspecialchars($company['companylogo']) ?>" alt="Company Logo" class="company-logo">
    <?php endif; ?>
    <h2><?= htmlspecialchars($company['companyname'] ?? '') ?></h2>
    <p><?= htmlspecialchars($company['companylocation'] ?? '') ?></p>
    <p>Phone: <?= htmlspecialchars($company['companyphone'] ?? '') ?></p>
    <p>Reg. No: <?= htmlspecialchars($company['companyreg'] ?? '') ?></p>
</div><br>

<div style="text-align:center; margin-bottom:15px;">
    <?php if (!empty($branch['images'])): ?>
          <img src="<?= htmlspecialchars($branch['images']) ?>" alt="Branch Logo" class="company-logo"><br>
        <?php endif; ?>
        <strong><?= htmlspecialchars($branch['bname'] ?? '') ?></strong><br>
        <?= htmlspecialchars($branch['baddress'] ?? '') ?><br>
        Phone: <?= htmlspecialchars($branch['bphone'] ?? '') ?>
</div><br>




<h2>Branch Code : <?= htmlspecialchars($bcode) ?></h2>
<h3>Daily Summary (<?= htmlspecialchars($sale_date) ?>)</h3>
<h3>Last Update: <?= htmlspecialchars($summary['last_updated']) ?></h3><br>

<!--<php-->
<!--$total_sales_count = ($summary['cash_count'] ?? 0) + ($summary['credit_count'] ?? 0) + ($summary['cheque_count'] ?? 0);-->
<!--?>-->

<table>
    <!--<tr><td>Total Sales Count:</td><td><?= number_format($total_sales_count, 0) ?></td></tr>-->
    <tr><td>Total Sales:</td><td><?= number_format($summary['total_sales'], 2) ?></td></tr>
    <tr><td>Total Full Bill Discount:</td><td><?= number_format($summary['total_discount'], 2) ?></td></tr>
    <tr><td>Total Product Discount:</td><td><?= number_format($summary['total_item_discount'], 2) ?></td></tr><br><br>
    <tr class="total">
        <td><strong>Final Total (Sales - All Discount):</strong></td>
        <td><strong><?= number_format(($summary['total_sales'] ?? 0) - ($summary['total_discount'] ?? 0) - ($summary['total_item_discount'] ?? 0), 2) ?></strong></td>
    </tr>
    <tr>
        <td>Total Profit (Profit - Discount):</td>
        <td><?= number_format(($summary['total_profit'] ?? 0)- ($summary['total_discount'] ?? 0)- ($summary['total_item_discount'] ?? 0), 2) ?></td>
    </tr>
    
    <tr><td>Total Balance paid:</td><td><?= number_format($summary['total_balance'], 2) ?></td></tr>
    <tr><td>Total Transactions:</td><td><?= $summary['total_transactions'] ?></td></tr>
</table><br><br>


<h3>By Payment Type</h3>
<table>
    <tr><td>Cash Total:</td><td><?= number_format($summary['cash_total'], 2) ?></td></tr>
    <tr><td>Cash Transactions:</td><td><?= $summary['cash_count'] ?></td></tr>
    <tr><td>Credit Total:</td><td><?= number_format($summary['credit_total'], 2) ?></td></tr>
    <tr><td>Credit Transactions:</td><td><?= $summary['credit_count'] ?></td></tr>
    <tr><td>Cheque Total:</td><td><?= number_format($summary['cheque_total'], 2) ?></td></tr>
    <tr><td>Cheque Transactions:</td><td><?= $summary['cheque_count'] ?></td></tr>
</table>

<p style="text-align:center; margin-top: 20px;">Thank you!</p>

</body>
</html>
