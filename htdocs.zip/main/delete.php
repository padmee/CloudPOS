<?php
include('../connect.php');

$id = $_GET['id']; // sales_order.transaction_id
$invoice = $_GET['invoice'];
$customer_id = $_GET['dle'];
$qty = $_GET['qty'];
$product_code = $_GET['code'];
$purchase_item_id = $_GET['purchase_item_id'];

// Step 1: Restore to correct batch
$restoreBatch = $db->prepare("UPDATE purchases_item SET qty = qty + ? WHERE id = ?");
$restoreBatch->execute([$qty, $purchase_item_id]);



// Step 3: Remove the sale record
$deleteSale = $db->prepare("DELETE FROM sales_order WHERE transaction_id = ?");
$deleteSale->execute([$id]);

// Redirect back
header("location: sales.php?id=$customer_id&invoice=$invoice");
?>
