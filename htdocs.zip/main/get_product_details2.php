<?php
include('../connect.php');

$productCode = $_GET['productCode'];
$query = $db->prepare("SELECT price, images FROM products WHERE product_code = :productCode");
$query->bindParam(':productCode', $productCode);
$query->execute();
$result = $query->fetch(PDO::FETCH_ASSOC);

if ($result) {
    // Return the product details as a JSON response
    header('Content-Type: application/json');
    echo json_encode([
        'price' => $result['price'],
        'photo' => $result['images'], // Corrected this line to use 'images' instead of 'photo'
    ]);
} else {
    // Return a message indicating that the product code was not found
    echo "Product not found";
}
?>
