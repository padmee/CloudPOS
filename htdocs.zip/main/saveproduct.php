<?php
session_start();
include('../connect.php');

// Retrieve the input data
$a = $_POST['code'];

// Check if the product with the same code already exists in the database for the same branch
$checkQuery = "SELECT COUNT(*) FROM products WHERE product_code = :code AND bcode = :bcode";
$checkStatement = $db->prepare($checkQuery);
$checkStatement->bindParam(':code', $a);
$checkStatement->bindParam(':bcode', $_SESSION['SESS_BCODE']);
$checkStatement->execute();

$productExists = $checkStatement->fetchColumn();

if ($productExists > 0) {
    // Product with the same code already exists for the same branch, display an error message
    $_SESSION['error_message'] = "Product with the same code already exists for this branch.";
    header("location: addproduct.php");
    exit(); // Stop further execution
}

// Continue inserting the new product if it doesn't already exist
$b = $_POST['name'];
// $c = $_POST['exdate'];
// $d = $_POST['price'];
$e = $_POST['supplier'];
// $f = $_POST['qty'];
// $g = $_POST['o_price'];
// $h = $_POST['profit'];
$i = $_POST['gen'];
// $j = $_POST['date'];
$bcode = $_SESSION['SESS_BCODE'];

$fileName = $_FILES['filename']['name'];
$target = "images/products/";
$fileTarget = $target . $fileName;
$tempFileName = $_FILES["filename"]["tmp_name"];
$result = move_uploaded_file($tempFileName, $fileTarget);

$sql = "INSERT INTO products (product_code,product_name,supplier,gen_name,bcode,images) VALUES (:a,:b,:e,:i,:bcode,:fileTarget)";
$q = $db->prepare($sql);
$q->execute(array(':a' => $a, ':b' => $b,  ':e' => $e,  ':i' => $i,  ':bcode' => $bcode, ':fileTarget' => $fileTarget));

header("location: products.php");
?>
