<?php
// 	include('../connect.php');
// 	$id=$_GET['id'];
// 	$result = $db->prepare("DELETE FROM branch WHERE id= :memid");
// 	$result->bindParam(':memid', $id);
// 	$result->execute();






include('../connect.php');

$id = $_GET['id'];

// Get the file path of the image before deleting from the database
$getImagePath = $db->prepare("SELECT images FROM branch WHERE id = :memid");
$getImagePath->bindParam(':memid', $id);
$getImagePath->execute();
$imagePathResult = $getImagePath->fetch(PDO::FETCH_ASSOC);

if ($imagePathResult) {
    // Delete the image file if it exists
    $imagePath = $imagePathResult['images'];
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
}

// Delete the branch record from the database
$deleteBranch = $db->prepare("DELETE FROM branch WHERE id = :memid");
$deleteBranch->bindParam(':memid', $id);
$deleteBranch->execute();







?>