const $btnPrint = document.querySelector("#btnPrint");
var content_vlue = document.getElementById("content").innerHTML; 



$btnPrint.addEventListener("click", (content_vlue) => {
    
    window.print();
});



