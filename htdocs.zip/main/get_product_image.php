<?php
include('../connect.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$code = $_GET['productCode'] ?? '';

if (!$code) {
    echo json_encode(['images' => 'images/pos.png']);
    exit;
}

try {
    // Assuming the images column stores full path like 'images/products/filename.jpeg'
    $stmt = $db->prepare("SELECT images FROM products WHERE product_code = :code LIMIT 1");
    $stmt->bindParam(':code', $code);
    $stmt->execute();

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && !empty($row['images']) && file_exists($row['images'])) {
        echo json_encode(['images' => $row['images']]);
    } else {
        echo json_encode(['images' => 'images/pos.png']); // fallback
    }

} catch (Exception $e) {
    echo json_encode(['images' => 'images/pos.png']);
}
?>
