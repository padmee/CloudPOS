<?php
// 	include('../connect.php');
// 	$id=$_GET['id'];
// 	$result = $db->prepare("DELETE FROM products WHERE product_id= :memid");
// 	$result->bindParam(':memid', $id);
// 	$result->execute();





include('../connect.php');

$id = $_GET['id'];

// Get the file path of the image before deleting from the database
$getImagePath = $db->prepare("SELECT images FROM products WHERE product_id = :memid");
$getImagePath->bindParam(':memid', $id);
$getImagePath->execute();
$imagePathResult = $getImagePath->fetch(PDO::FETCH_ASSOC);

if ($imagePathResult) {
    // Delete the image file if it exists
    $imagePath = $imagePathResult['images'];
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
}

// Delete the product record from the database
$deleteProduct = $db->prepare("DELETE FROM products WHERE product_id = :memid");
$deleteProduct->bindParam(':memid', $id);
$deleteProduct->execute();


?>