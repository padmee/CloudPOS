 <?php
// 	include('../connect.php');
// 	$id=$_GET['id'];
// 	$result = $db->prepare("DELETE FROM production WHERE production_id= :memid");
// 	$result->bindParam(':memid', $id);
// 	$result->execute();





session_start();
include('../connect.php');

$id = $_GET['id'];

// Get the file path of the image before deleting from the database
$getImagePath = $db->prepare("SELECT images FROM production WHERE production_id = :memid");
$getImagePath->bindParam(':memid', $id);
$getImagePath->execute();
$imagePathResult = $getImagePath->fetch(PDO::FETCH_ASSOC);

if ($imagePathResult) {
    // Delete the image file if it exists
    $imagePath = $imagePathResult['images'];
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
}

// Delete the production record from the database
$deleteProduction = $db->prepare("DELETE FROM production WHERE production_id = :memid");
$deleteProduction->bindParam(':memid', $id);
$deleteProduction->execute();






 ?>