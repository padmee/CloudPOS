<?php
session_start();
include('../connect.php');
$a = $_POST['design_no'];
$b = $_POST['date'];
$c = $_POST['qty'];
$d = $_POST['mode'];
$e = $_POST['colour_code'];
$f = $_POST['target_date'];
$g = $_POST['state'];
$h = $_POST['subcontractor_name'];
// $k = $_POST['bcode'];
$bcode=$_SESSION['SESS_BCODE'];


$fileName = $_FILES['filename']['name'];

		$target = "images/productions/";		
		$fileTarget = $target.$fileName;	
		$tempFileName = $_FILES["filename"]["tmp_name"];

$result = move_uploaded_file($tempFileName,$fileTarget);
// query
$sql = "INSERT INTO production (design_no,date,qty,mode,colour_code,target_date,state,subcontractor_name,bcode,images) VALUES (:a,:b,:c,:d,:e,:f,:g,:h,:bcode,:fileTarget)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':f'=>$f,':g'=>$g,':h'=>$h,':bcode'=>$bcode,':fileTarget'=>$fileTarget));
header("location: production.php");



?>





