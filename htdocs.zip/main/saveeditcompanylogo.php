<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['memi'];
$a = $_POST['companyid'];


// Handle file uploads for company image
$fileName = $_FILES['logo']['name'];
$target = "images/company/";
$fileTarget = $target . $fileName;
$tempFileName = $_FILES["logo"]["tmp_name"];
$result = move_uploaded_file($tempFileName, $fileTarget);


// query
$sql = "UPDATE company 
        SET companyid=?, companylogo=?
        WHERE companyid=?";
$q = $db->prepare($sql);
$q->execute(array($a, $fileTarget, $id));


header("location: company.php");
?>
