<?php
// configuration
include('../connect.php');

// new data




$id = $_POST['memi'];
$a = $_POST['remark'];
$b = $_POST['invoice_number'];
$c = $_POST['ptype'];
$d = $_POST['price'];
$e = $_POST['supplier'];
$f = $_POST['mtype'];
$g = $_POST['o_price'];
$h = $_POST['dueprice'];
$i = $_POST['date'];
$k = $_POST['bcode'];



// query
$sql = "UPDATE transaction 
        SET  remark=?, invoice_number=?, ptype=?, price=?,supplier=?,mtype=?, o_price=?, dueprice=?, date=?, bcode=?
		WHERE transaction_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$b,$c,$d,$e,$f,$g,$h,$i,$k, $id));
header("location: transaction.php");

?>