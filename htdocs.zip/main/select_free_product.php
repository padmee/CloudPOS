<?php
session_start();
if (!isset($_SESSION['product_matches']) || !isset($_SESSION['form_data'])) {
    echo "Session expired. Please go back and try again.";
    exit;
}

$products = $_SESSION['product_matches'];
$form = $_SESSION['form_data'];
?>

<h3>Select the correct product (Free Item)</h3>
<table border="1" cellpadding="5">
    <tr>
        <th>Product Name</th>
        <th>Expiry</th>
        <th>Available Qty</th>
        <th>Action</th>
    </tr>
    <?php foreach ($products as $item): ?>
    <tr>
        <td><?= htmlspecialchars($item['product_name']) ?></td>
        <td><?= htmlspecialchars($item['expiry']) ?></td>
        <td><?= $item['qty'] ?></td>
        <td>
            <form action="freesale_process.php" method="post">
                <?php foreach ($form as $key => $value): ?>
                    <input type="hidden" name="<?= $key ?>" value="<?= htmlspecialchars($value) ?>">
                <?php endforeach; ?>
                <input type="hidden" name="selected_product_id" value="<?= $item['id'] ?>">
                <button type="submit">Select</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
