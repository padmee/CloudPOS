<?php
session_start();
include('../connect.php');

$purchases_item_id = $_POST['purchases_item_id'] ?? null;
$product_code = $_POST['product'];
$qty = $_POST['qty'];
$invoice = $_POST['invoice'];
$pt = $_POST['pt'];
$date = $_POST['date'];

$bcode = $_SESSION['SESS_BCODE'];

// Get product details
$stmt = $db->prepare("SELECT * FROM products WHERE bcode = :bcode AND product_code = :product_code");
$stmt->execute([':bcode' => $bcode, ':product_code' => $product_code]);
$product = $stmt->fetch();

if (!$product) {
    die("Product not found.");
}

$product_name = $product['product_name'] . " (Free of Charge)";
$gen_name = $product['gen_name'];
$price = 0;
$amount = 0;
$profit = 0;
$discount = 0;

if ($purchases_item_id) {
    $update = $db->prepare("UPDATE purchases_item SET qty = qty - ? WHERE id = ? AND qty >= ?");
    $update->execute([$qty, $purchases_item_id, $qty]);
} else {
    // FIFO fallback
    $remaining = $qty;
    $stmt = $db->prepare("
        SELECT pi.id, pi.qty 
        FROM purchases_item pi 
        JOIN purchases p ON pi.invoice = p.invoice_number 
        WHERE pi.product_code = :code AND p.bcode = :bcode AND pi.qty > 0 
        ORDER BY pi.id ASC
    ");
    $stmt->execute([':code' => $product_code, ':bcode' => $bcode]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($items as $item) {
        if ($remaining <= 0) break;

        $deduct = min($remaining, $item['qty']);
        $db->prepare("UPDATE purchases_item SET qty = qty - ? WHERE id = ?")
           ->execute([$deduct, $item['id']]);

        $remaining -= $deduct;
    }

    if ($remaining > 0) {
        echo "<script>alert('Warning: Not enough stock.');</script>";
    }
}

// Insert into sales_order
$db->prepare("INSERT INTO sales_order (invoice, product_code, product, gen_name, name, price, qty, amount, profit, discount, date, purchases_item_id) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
->execute([
    $invoice, $product_code, $product_code, $gen_name, $product_name,
    $price, $qty, $amount, $profit, $discount, $date, $purchases_item_id
]);

header("Location: sales.php?id=$pt&invoice=$invoice");
exit;
?>
