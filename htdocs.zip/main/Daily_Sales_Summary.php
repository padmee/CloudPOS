<html>
<?php
	require_once('auth.php');
	require_once('../connect.php');
$bcode = $_SESSION['SESS_BCODE'];
	
// Fetch company details
$companyStmt = $db->prepare("SELECT * FROM company LIMIT 1");
$companyStmt->execute();
$company = $companyStmt->fetch(PDO::FETCH_ASSOC);

// Fetch branch details using session branch code

$branchStmt = $db->prepare("SELECT * FROM branch WHERE bcode = :bcode LIMIT 1");
$branchStmt->bindParam(':bcode', $bcode);
$branchStmt->execute();
$branch = $branchStmt->fetch(PDO::FETCH_ASSOC);






// Get date range from GET parameters
// $d1 = $_GET['d1'] ?? date('Y-m-d');
// $d2 = $_GET['d2'] ?? date('Y-m-d');



$d1 = $d2 = '';
$rows = [];

if (isset($_GET['d1']) && isset($_GET['d2'])) {
    $d1_raw = $_GET['d1'];
    $d2_raw = $_GET['d2'];

    $d1_obj = DateTime::createFromFormat('m/d/Y', $d1_raw);
    $d2_obj = DateTime::createFromFormat('m/d/Y', $d2_raw);

    if (!$d1_obj || !$d2_obj) {
        // echo "Invalid date format. Please use MM/DD/YYYY.";
    } else {
        $d1 = $d1_obj->format('Y-m-d');
        $d2 = $d2_obj->format('Y-m-d');

        $stmt = $db->prepare("SELECT * FROM dailysales WHERE bcode = :bcode AND sale_date BETWEEN :d1 AND :d2 ORDER BY sale_date DESC");
        $stmt->execute([
            ':bcode' => (int)$bcode,
            ':d1' => $d1,
            ':d2' => $d2
        ]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}


?>












<head>
<title>
POS
</title>
 <link href="css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="css/bootstrap-responsive.css" rel="stylesheet">


<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script>


<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


// <script language="javascript">
// function Clickheretoprint()
// { 
//   var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
//       disp_setting+="scrollbars=yes,width=700, height=400, left=100, top=25"; 
//   var content_vlue = document.getElementById("content").innerHTML; 
  
//   var docprint=window.open("","",disp_setting); 
//   docprint.document.open(); 
//   docprint.document.write('</head><body onLoad="self.print()" style="width: 700px; font-size:11px; font-family:arial; font-weight:normal;">');          
//   docprint.document.write(content_vlue); 
//   docprint.document.close(); 
//   docprint.focus(); 
// }
// </script>







<script>
function Clickheretoprint() {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=900,height=600,left=100,top=25";
  var content_value = document.getElementById("content").innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();

  docprint.document.write(`<!DOCTYPE html>
  <html>
  <head>
    <title>Print - Daily Sales Report</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        font-size: 12px;
        padding: 20px;
      }
      .header-container {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 20px;
        border-bottom: 1px solid #000;
        padding-bottom: 10px;
      }
      .header-box {
        width: 48%;
        font-size: 12px;
      }
      .header-box img {
        max-height: 80px;
        margin-bottom: 5px;
      }
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
      }
      table, th, td {
        border: 1px solid black;
      }
      th, td {
        padding: 8px;
        text-align: left;
      }
    </style>
  </head>
  <body onload="window.print()">
    <div class="header-container">
      <div class="header-box">
        <?php if (!empty($company['companylogo'])): ?>
          <img src="<?= htmlspecialchars($company['companylogo']) ?>" alt="Company Logo"><br>
        <?php endif; ?>
        <strong><?= htmlspecialchars($company['companyname'] ?? '') ?></strong><br>
        <?= htmlspecialchars($company['companylocation'] ?? '') ?><br>
        Phone: <?= htmlspecialchars($company['companyphone'] ?? '') ?><br>
        Reg. No: <?= htmlspecialchars($company['companyreg'] ?? '') ?>
      </div>

      <div class="header-box" style="text-align:right;">
        <?php if (!empty($branch['images'])): ?>
          <img src="<?= htmlspecialchars($branch['images']) ?>" alt="Branch Logo"><br>
        <?php endif; ?>
        <strong><?= htmlspecialchars($branch['bname'] ?? '') ?></strong><br>
        <?= htmlspecialchars($branch['baddress'] ?? '') ?><br>
        Phone: <?= htmlspecialchars($branch['bphone'] ?? '') ?>
      </div>
    </div>

    ${content_value}
  </body>
  </html>`);

  docprint.document.close();
  docprint.focus();
}
</script>




<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}

function myFunction1() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput1");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[4];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}



function myFunction2() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput2");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[5];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}


function myFunction3() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput3");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[3];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}


function myFunction4() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput4");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>




</head>
<?php
function createRandomPassword() {
	$chars = "003232303232023232023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 7) {

		$num = rand() % 33;

		$tmp = substr($chars, $num, 1);

		$pass = $pass . $tmp;

		$i++;

	}
	return $pass;
}
$finalcode='SB-'.createRandomPassword();
?>
<body>
<?php include('navfixed.php');?>
<div class="container-fluid">
      <div class="row-fluid">
	<div class="span2">
          <div class="well sidebar-nav">
              <ul class="nav nav-list">
                  <br>
              <li><a href="index.php"><i class="icon-dashboard icon-2x"></i> Dashboard </a></li> 
			<li><a href="sales.php?id=cash&invoice=<?php echo $finalcode ?>"><i class="icon-shopping-cart icon-2x"></i> Sales</a>  </li>             
				<li><a href="products.php"><i class="icon-list-alt icon-2x"></i> Products</a>                                     </li>
				<li><a href="salesreport.php?d1=0&d2=0"><i class="icon-bar-chart icon-2x"></i> Sales Report</a>                </li>

					<br><br><br><br><br><br>		
			
				
				</ul>     
          </div><!--/.well -->
        </div><!--/span-->
	<div class="span10">
	<div class="contentheader">
			<i class="icon-bar-chart"></i> Daily Sales Report
			</div>
			<ul class="breadcrumb">
			<li><a href="index.php">Dashboard</a></li> /
			<li class="active">Daily Sales Report</li>
			</ul>

<div style="margin-top: -19px; margin-bottom: 21px;">
<a  href="index.php"><button class="btn btn-default btn-large" style="float: none;"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>
<button  style="float:right;" class="btn btn-success btn-large"><a href="javascript:Clickheretoprint()"> Print</button></a>
<form method="post" action="dailysalesreport.php">
    <input type="submit" name="generate_summary" value="Generate Daily Summary" class="btn btn-primary">
</form>

<!-- Assuming you have the branch code available in $bcode -->
<form method="POST" action="print_daily_summary.php" target="_blank">
    <input type="hidden" name="bcode" value="<?= htmlspecialchars($bcode) ?>">
    <input type="hidden" name="sale_date" value="<?= date('Y-m-d') ?>">
    <button type="submit" class="btn btn-primary">Print Daily Summary</button>
</form>




</div>
<form action="Daily_Sales_Summary.php" method="get">
<center><strong>From : <input type="text" style="width: 223px; padding:14px;" name="d1" class="tcal" value="" /> To: <input type="text" style="width: 223px; padding:14px;" name="d2" class="tcal" value="" />
 <button class="btn btn-info" style="width: 123px; height:35px; margin-top:-8px;margin-left:8px;" type="submit"><i class="icon icon-search icon-large"></i> Search</button>
</strong></center>
</form>

<!--<input type="text" style="padding:15px;" id="myInput" onkeyup="myFunction()" placeholder="Search Transection ID..." >-->
<!--<input type="text" style="padding:15px;" id="myInput1" onkeyup="myFunction1()" placeholder="Search Invoice Number..." >-->
<!--<input type="text" style="padding:15px;" id="myInput2" onkeyup="myFunction2()" placeholder="Search Payment type..." >-->
<!--<input type="text" style="padding:15px;" id="myInput3" onkeyup="myFunction3()" placeholder="Search Cashiyer..." >-->
<!--<input type="text" style="padding:15px;" id="myInput4" onkeyup="myFunction4()" placeholder="Search Customer..." >-->

<div class="content" id="content">
<div style="font-weight:bold; text-align:center;font-size:14px;margin-bottom: 15px;">
Sales Report from&nbsp;<?= htmlspecialchars($_GET['d1'] ?? '') ?>&nbsp;to&nbsp;<?= htmlspecialchars($_GET['d2'] ?? '') ?>

</div>



<?php
if (isset($_SESSION['summary_message'])) {
    $msg = $_SESSION['summary_message'];
    $type = $msg['type'];  // 'success' or 'warning'
    $text = $msg['text'];
    // Clear the message after use
    unset($_SESSION['summary_message']);
    echo "
    <script>
        Swal.fire({
            icon: '$type',
            title: '" . ($type === 'success' ? 'Success!' : 'Warning!') . "',
            text: '$text',
            confirmButtonText: 'OK'
        });
    </script>";
}
?>


<table class="table table-bordered" id="resultTable" data-responsive="table" style="text-align: left;">
    <thead>
        <tr>
            <th>Date</th>
            <th>Total Transactions</th>
            <th>Total Sales</th>
            <th>Total Full Bill Discount</th>
            <th>Total Product Discount</th>
            <th>Final Total (Sales - All Discounts)</th>
            <th>Total Profit (Profit - Discount)</th>
            <th>Total Balance Paid</th>
            <th>Cash Total</th>
            <th>Cash Transactions</th>
            <th>Credit Total</th>
            <th>Credit Transactions</th>
            <th>Cheque Total</th>
            <th>Cheque Transactions</th>
        </tr>
    </thead>
    <tbody>
    <?php if (!empty($rows)): ?>
        <?php foreach ($rows as $summary): ?>
            <tr class="record">
                <td><?= htmlspecialchars($summary['sale_date']) ?></td>
                <td><?= htmlspecialchars($summary['total_transactions']) ?></td>
                <td><?= number_format($summary['total_sales'], 2) ?></td>
                <td><?= number_format($summary['total_discount'], 2) ?></td>
                <td><?= number_format($summary['total_item_discount'], 2) ?></td>
                <td><?= number_format(($summary['total_sales'] ?? 0) - ($summary['total_discount'] ?? 0) - ($summary['total_item_discount'] ?? 0), 2) ?></td>
                <td><?= number_format(($summary['total_profit'] ?? 0) - ($summary['total_discount'] ?? 0) - ($summary['total_item_discount'] ?? 0), 2) ?></td>
                <td><?= number_format($summary['total_balance'], 2) ?></td>
                <td><?= number_format($summary['cash_total'], 2) ?></td>
                <td><?= htmlspecialchars($summary['cash_count']) ?></td>
                <td><?= number_format($summary['credit_total'], 2) ?></td>
                <td><?= htmlspecialchars($summary['credit_count']) ?></td>
                <td><?= number_format($summary['cheque_total'], 2) ?></td>
                <td><?= htmlspecialchars($summary['cheque_count']) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="14" style="text-align:center;">No records found for selected date range.</td></tr>
    <?php endif; ?>
    </tbody>
</table>

<!--<a><center>Please Note That a Full Bill Discount does Not Affect Profit. Item Wise Discounts Only effecting. </center></a>-->
</div>
<div class="clearfix"></div>
</div>
</div>
</div>

</body>

<?php include('footer.php');?>
</html>