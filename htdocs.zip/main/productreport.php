<?php
require_once('auth.php');
include('../connect.php');

$bcode = $_SESSION['SESS_BCODE'];
	
// Fetch company details
$companyStmt = $db->prepare("SELECT * FROM company LIMIT 1");
$companyStmt->execute();
$company = $companyStmt->fetch(PDO::FETCH_ASSOC);

// Fetch branch details using session branch code

$branchStmt = $db->prepare("SELECT * FROM branch WHERE bcode = :bcode LIMIT 1");
$branchStmt->bindParam(':bcode', $bcode);
$branchStmt->execute();
$branch = $branchStmt->fetch(PDO::FETCH_ASSOC);





function createRandomPassword() {
    $chars = "003232303232023232023456789";
    srand((double)microtime()*1000000);
    $i = 0;
    $pass = '';
    while ($i <= 7) {
        $num = rand() % 33;
        $tmp = substr($chars, $num, 1);
        $pass = $pass . $tmp;
        $i++;
    }
    return $pass;
}
$finalcode='SB-'.createRandomPassword();


// Date range filtering
$d3 = $_GET['d3'] ?? '';
$d4 = $_GET['d4'] ?? '';
$filterByDate = !empty($d3) && !empty($d4);
?>
<html>
<head>
    <title>POS</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="tcal.css" />
    <script type="text/javascript" src="tcal.js"></script>
    
    
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


    <style>
        body { padding-top: 60px; padding-bottom: 40px; }
        .sidebar-nav { padding: 9px 0; }
    </style>
</head>
<body>
<?php include('navfixed.php'); ?>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="span2">
            <div class="well sidebar-nav">
                <ul class="nav nav-list">
                    <li><a href="index.php"><i class="icon-dashboard icon-2x"></i> Dashboard </a></li>
                    <li><a href="sales.php?id=cash&invoice=<?php echo $finalcode ?>"><i class="icon-shopping-cart icon-2x"></i> Sales</a></li>
                    <li><a href="products.php"><i class="icon-list-alt icon-2x"></i> Products</a></li>
                    <li><a href="customer.php"><i class="icon-group icon-2x"></i> Customers</a></li>
                    <li><a href="supplier.php"><i class="icon-group icon-2x"></i> Suppliers</a></li>
                    <li><a href="salesreport.php"><i class="icon-bar-chart icon-2x"></i> Sales Report</a></li>
                    <li class="active"><a href="productreport.php?d3=0&d4=0"><i class="icon-bar-chart icon-2x"></i> Product Report</a></li>
                </ul>
            </div>
        </div>
        <div class="span10">
            <div class="contentheader">
                <i class="icon-bar-chart"></i> Product Report
            </div>
            <ul class="breadcrumb">
                <li><a href="index.php">Dashboard</a></li>
                <li class="active">Product Report</li>
            </ul>
            <!--<form action="" method="get">-->
            <!--    <center>-->
            <!--        <strong>From: <input type="text" style="width: 223px; padding:10px;" name="d3" class="tcal" value="<?php echo $d3; ?>" />-->
            <!--        To: <input type="text" style="width: 223px; padding:10px;" name="d4" class="tcal" value="<?php echo $d4; ?>" />-->
            <!--        <button class="btn btn-info" style="width: 123px; height:35px; margin-top:-8px;"><i class="icon icon-search icon-large"></i> Search</button></strong>-->
            <!--    </center>-->
            <!--</form>-->
            <br>
            <div style="margin-top: -19px; margin-bottom: 21px;">
                <a href="index.php"><button class="btn btn-default btn-large"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>
                <button style="float:right;" class="btn btn-success btn-large"><a href="javascript:Clickheretoprint()"> Print</a></button>
            </div>
            <input type="text" style="padding:15px;" id="myInput" onkeyup="myFunction()" placeholder="Search Product ID...">
            <input type="text" style="padding:15px;" id="myInput2" onkeyup="myFunction2()" placeholder="Search Product Code...">
            <input type="text" style="padding:15px;" id="myInput3" onkeyup="myFunction3()" placeholder="Search Supplier Name...">
            <p><strong>Note:</strong> Rows in <span style="background-color: #ffcccc;">red</span> indicate products with quantity less than 10.</p>
            <div class="content" id="content">
                
                <table class="table table-bordered" id="resultTable" data-responsive="table" style="text-align: left;">
                    <thead>
                        <tr>
                            <th>Product ID</th>
                            <th>Product Code</th>
                            <th>Last Arrival Date</th>
                            <th>Supplier Name</th>
                            <th>Branch Code</th>
                            <th>Total Amount</th>
                            <th>Total Qty</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $lowStockRows = '';
                        $otherRows = '';

                        $result = $db->prepare("SELECT * FROM products WHERE bcode = :bcode ORDER BY product_id DESC");
                        $result->execute([':bcode' => $bcode]);

                        while ($row = $result->fetch()) {
                            $product_code = $row['product_code'];

                            $stmt = $db->prepare("SELECT MAX(p.date) AS arrival_date FROM purchases_item pi JOIN purchases p ON pi.invoice = p.invoice_number WHERE pi.product_code = :code AND p.bcode = :bcode");
                            $stmt->execute([':code' => $product_code, ':bcode' => $bcode]);
                            $arrival = $stmt->fetch();
                            $arrival_date = $arrival['arrival_date'] ?? 'N/A';

                            if ($filterByDate && ($arrival_date < $d3 || $arrival_date > $d4)) {
                                continue;
                            }

                            $sqlItems = "
                                SELECT SUM(price * qty) AS total_amount, SUM(qty) AS total_qty
                                FROM purchases_item pi
                                JOIN purchases p ON pi.invoice = p.invoice_number
                                WHERE pi.product_code = :code
                                  AND p.bcode = :bcode
                            ";
                            $stmt2 = $db->prepare($sqlItems);
                            $stmt2->execute([':code' => $product_code, ':bcode' => $bcode]);
                            $amountData = $stmt2->fetch();
                            $total_amount = $amountData['total_amount'] !== null ? $amountData['total_amount'] : 0;
                            $total_qty = $amountData['total_qty'] !== null ? $amountData['total_qty'] : 0;

                            $rowHTML = '<tr class="record" style="' . ($total_qty < 10 ? 'background-color: #ffcccc;' : '') . '">';
                            $rowHTML .= '<td>' . $row['product_id'] . '</td>';
                            $rowHTML .= '<td>' . $product_code . '</td>';
                            $rowHTML .= '<td>' . $arrival_date . '</td>';
                            $rowHTML .= '<td>' . $row['supplier'] . '</td>';
                            $rowHTML .= '<td>' . $row['bcode'] . '</td>';
                            $rowHTML .= '<td>' . number_format($total_amount, 2) . '</td>';
                            $rowHTML .= '<td>' . $total_qty . '</td>';
                            $rowHTML .= '</tr>';

                            if ($total_qty < 10) {
                                $lowStockRows .= $rowHTML;
                            } else {
                                $otherRows .= $rowHTML;
                            }
                        }

                        echo $lowStockRows . $otherRows;
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.js"></script>
<script>
// function Clickheretoprint() {
//     var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
//     disp_setting += "scrollbars=yes,width=700, height=400, left=100, top=25";
//     var content_vlue = document.getElementById("content").innerHTML;
//     var docprint = window.open("", "", disp_setting);
//     docprint.document.open();
//     docprint.document.write('</head><body onLoad="self.print()" style="width: 700px; font-size:11px; font-family:arial; font-weight:normal;">');
//     docprint.document.write(content_vlue);
//     docprint.document.close();
//     docprint.focus();
// }




function Clickheretoprint() {
  var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
  disp_setting += "scrollbars=yes,width=900,height=600,left=100,top=25";
  var content_value = document.getElementById("content").innerHTML;

  var docprint = window.open("", "", disp_setting);
  docprint.document.open();

  docprint.document.write(`<!DOCTYPE html>
  <html>
  <head>
    <title>Print - Product Report</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        font-size: 12px;
        padding: 20px;
      }
      .header-container {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 20px;
        border-bottom: 1px solid #000;
        padding-bottom: 10px;
      }
      .header-box {
        width: 48%;
        font-size: 12px;
      }
      .header-box img {
        max-height: 80px;
        margin-bottom: 5px;
      }
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
      }
      table, th, td {
        border: 1px solid black;
      }
      th, td {
        padding: 8px;
        text-align: left;
      }
    </style>
  </head>
  <body onload="window.print()">
    <div class="header-container">
      <div class="header-box">
        <?php if (!empty($company['companylogo'])): ?>
          <img src="<?= htmlspecialchars($company['companylogo']) ?>" alt="Company Logo"><br>
        <?php endif; ?>
        <strong><?= htmlspecialchars($company['companyname'] ?? '') ?></strong><br>
        <?= htmlspecialchars($company['companylocation'] ?? '') ?><br>
        Phone: <?= htmlspecialchars($company['companyphone'] ?? '') ?><br>
        Reg. No: <?= htmlspecialchars($company['companyreg'] ?? '') ?>
      </div>

      <div class="header-box" style="text-align:right;">
        <?php if (!empty($branch['images'])): ?>
          <img src="<?= htmlspecialchars($branch['images']) ?>" alt="Branch Logo"><br>
        <?php endif; ?>
        <strong><?= htmlspecialchars($branch['bname'] ?? '') ?></strong><br>
        <?= htmlspecialchars($branch['baddress'] ?? '') ?><br>
        Phone: <?= htmlspecialchars($branch['bphone'] ?? '') ?>
      </div>
    </div>

    ${content_value}
  </body>
  </html>`);

  docprint.document.close();
  docprint.focus();
}














function myFunction() {
    var input = document.getElementById("myInput");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("resultTable");
    var tr = table.getElementsByTagName("tr");
    for (var i = 0; i < tr.length; i++) {
        var td = tr[i].getElementsByTagName("td")[0];
        if (td) {
            var txtValue = td.textContent || td.innerText;
            tr[i].style.display = txtValue.toUpperCase().indexOf(filter) > -1 ? "" : "none";
        }
    }
}
function myFunction2() {
    var input = document.getElementById("myInput2");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("resultTable");
    var tr = table.getElementsByTagName("tr");
    for (var i = 0; i < tr.length; i++) {
        var td = tr[i].getElementsByTagName("td")[1];
        if (td) {
            var txtValue = td.textContent || td.innerText;
            tr[i].style.display = txtValue.toUpperCase().indexOf(filter) > -1 ? "" : "none";
        }
    }
}
function myFunction3() {
    var input = document.getElementById("myInput3");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("resultTable");
    var tr = table.getElementsByTagName("tr");
    for (var i = 0; i < tr.length; i++) {
        var td = tr[i].getElementsByTagName("td")[3];
        if (td) {
            var txtValue = td.textContent || td.innerText;
            tr[i].style.display = txtValue.toUpperCase().indexOf(filter) > -1 ? "" : "none";
        }
    }
}
</script>
<?php include('footer.php'); ?>
</body>
</html>
