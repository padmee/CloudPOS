<?php
session_start();
include('../connect.php');
date_default_timezone_set('Asia/Colombo');

// Safe inputs
$purchases_item_id = isset($_POST['purchases_item_id']) && is_numeric($_POST['purchases_item_id']) ? intval($_POST['purchases_item_id']) : null;
$is_free = isset($_POST['is_free']) && $_POST['is_free'] == '1';

$a = $_POST['invoice'];
$b = $_POST['product'];
$c = isset($_POST['qty']) && is_numeric($_POST['qty']) ? (float)$_POST['qty'] : 0;
$w = $_POST['pt'];
$date = $_POST['date'];
$discount = isset($_POST['discount']) && is_numeric($_POST['discount']) ? (float)$_POST['discount'] : 0;
$upprice = isset($_POST['upprice']) && is_numeric($_POST['upprice']) ? (float)$_POST['upprice'] : 0;
$o_price = isset($_POST['o_price']) && is_numeric($_POST['o_price']) ? (float)$_POST['o_price'] : null;

$bcode = $_SESSION['SESS_BCODE'] ?? '';

// Validation
if (!$b || $c <= 0 || (!$is_free && $upprice <= 0)) {
   // die("Error: Missing or invalid product, quantity, or price.");
 echo "<script>alert('Warning:  Missing or invalid product, quantity, or price.');</script>";
}

// Fetch product details
$result = $db->prepare("SELECT * FROM products WHERE bcode = :bcode AND product_code = :product_code");
$result->execute([':bcode' => $bcode, ':product_code' => $b]);

$row = $result->fetch();
if (!$row) {
  //  die("Product not found.");
    echo "<script>alert('Warning:  Product not found.');</script>";
}

$asasa = $row['price'];
$code = $row['product_code'];
$gen = $row['gen_name'];
$name = $row['product_name'];
$default_profit = isset($row['profit']) && is_numeric($row['profit']) ? (float)$row['profit'] : 0;

// If free item, override price and discount
if ($is_free) {
    $upprice = 0;
    $discount = 0;
    $profit = -($o_price * $c);  // Negative profit for free items
} else {
    if ($o_price !== null) {
        $profit = ($upprice - $o_price) * $c - $discount;
    } else {
        // Fallback to saved profit per unit in product table
        $profit = $default_profit * $c - $discount;
    }
}

// Deduct stock
if ($purchases_item_id) {
    $update = $db->prepare("UPDATE purchases_item SET qty = qty - ? WHERE id = ? AND qty >= ?");
    $update->execute([$c, $purchases_item_id, $c]);

    if ($update->rowCount() == 0) {
        echo "<script>alert('Warning: Selected item does not have enough quantity.');</script>";
    }
} else {
    // FIFO fallback
    $qtyToDeduct = $c;
    $product_code = $b;

    $select_items = $db->prepare("
        SELECT pi.id, pi.qty
        FROM purchases_item pi
        INNER JOIN purchases p ON pi.invoice = p.invoice_number
        WHERE pi.product_code = :product_code
          AND p.bcode = :bcode
          AND pi.qty > 0
        ORDER BY pi.id ASC
    ");
    $select_items->execute([
        ':product_code' => $product_code,
        ':bcode' => $bcode
    ]);

    $purchases = $select_items->fetchAll(PDO::FETCH_ASSOC);

    foreach ($purchases as $row) {
        if ($qtyToDeduct <= 0) break;

        $item_id = $row['id'];
        $available_qty = $row['qty'];

        if ($available_qty >= $qtyToDeduct) {
            $update = $db->prepare("UPDATE purchases_item SET qty = qty - ? WHERE id = ?");
            $update->execute([$qtyToDeduct, $item_id]);
            $purchases_item_id = $item_id;
            $qtyToDeduct = 0;
        } else {
            $update = $db->prepare("UPDATE purchases_item SET qty = 0 WHERE id = ?");
            $update->execute([$item_id]);
            $qtyToDeduct -= $available_qty;
        }
    }

    if ($qtyToDeduct > 0) {
        echo "<script>alert('Warning: Not enough stock in branch to fulfill sale.');</script>";
    }
}

// Final amount
$amount = ($upprice * $c) - $discount;

// Insert into sales_order
$sql = "INSERT INTO sales_order 
        (invoice, product, qty, amount, name, price, profit, product_code, gen_name, date, discount, purchases_item_id, is_free)
        VALUES (:a, :b, :c, :d, :e, :upprice, :h, :i, :j, :k, :discount, :purchases_item_id, :is_free)";
$q = $db->prepare($sql);
$q->execute([
    ':a' => $a,
    ':b' => $b,
    ':c' => $c,
    ':d' => $amount,
    ':e' => $name,
    ':upprice' => $upprice,
    ':h' => $profit,
    ':i' => $code,
    ':j' => $gen,
    ':k' => $date,
    ':discount' => $discount,
    ':purchases_item_id' => $purchases_item_id,
    ':is_free' => $is_free ? 1 : 0
]);

// Redirect
header("location: sales.php?id=$w&invoice=$a");
?>
