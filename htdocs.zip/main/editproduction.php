<?php
	include('../connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM production WHERE production_id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


<form action="saveeditproduction.php" method="post">
<center><h4><i class="icon-edit icon-large"></i> Edit Product</h4></center>
<hr>
<div id="ac">
<input type="hidden" name="memi" value="<?php echo $id; ?>" />

<?php echo' <img src="'.$row["images"].'" alt=""> '; ?><br>
<input type="hidden" name="bcode" value="<?php echo $row['bcode']; ?>"/>


<span>Design No : </span><input type="text" style="width:265px; height:30px;"  name="design_no" value="<?php echo $row['design_no']; ?>" Required/><br>

<span>Date: </span><input type	="date" style="width:265px; height:30px;" name="date" value="<?php echo $row['date']; ?>" /><br>
<span>QTY: </span><input type="number" style="width:265px; height:30px;" min="0" name="qty" value="<?php echo $row['qty']; ?>" /><br>
<span>Colour : </span><input type="text" style="width:265px; height:30px;"  name="colour_code" value="<?php echo $row['colour_code']; ?>" Required/><br>
<span>Target Date :  </span><input type	="date" style="width:265px; height:30px;" name="target_date" value="<?php echo $row['target_date']; ?>" /><br>

<span>Mode : </span>
<select name="mode"  style="width:265px; height:30px; margin-left:-5px;" >
<option></option>
	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM mode");
		$result->bindParam(':mode_id', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['mode']; ?></option>
		
	<?php
	}
	?>
</select><br>


<span>Sub : </span>
<select name="subcontractor_name"  style="width:265px; height:30px; margin-left:-5px;" >
<option></option>
	<?php
	include('../connect.php');
	$result1 = $db->prepare("SELECT * FROM subcontractor");
		$result1->bindParam(':subcontractor_name', $res1);
		$result1->execute();
		for($i=0; $row1 = $result1->fetch(); $i++){
	?>
		<option><?php echo $row1['subcontractor_name']; ?></option>
		
	<?php
	}
	?>
</select><br>













<span>State : </span>
<select name="state"  style="width:265px; height:30px; margin-left:-5px;" >
<option></option>
	<?php
	include('../connect.php');
	$result3 = $db->prepare("SELECT * FROM state");
		$result3->bindParam(':state_id', $res3);
		$result3->execute();
		for($i=0; $row3 = $result3->fetch(); $i++){
	?>
		<option><?php echo $row3['state']; ?></option>
	<?php
	}
	?>
</select><br>




<div style="float:right; margin-right:10px;">

<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save Changes</button>
</div>
</div>
</form>
<?php
}
?>