<?php
session_start();

if (isset($_POST['pt'], $_POST['invoice'])) {
    $_SESSION['selected_payment'][$_POST['invoice']] = $_POST['pt'];
    echo "Saved";
} else {
    echo "Invalid";
}
?>
