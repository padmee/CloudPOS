<html>
<head>
<style>
p.inline {display: inline-block;}
span { font-size: 13px;}
</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */

    }
</style>
</head>
<body onload="window.print();">
	<div style="margin-left: 5%">
		<?php
		session_start();
        include('../connect.php');
		include 'barcode128.php';
		$product = $_POST['product'];
		$product_id = $_POST['product_id'];
		$rate = $_POST['rate'];
		$print_qty = $_POST['print_qty'];
		$current_date = date('Y-m-d'); // Get the current date in YYYY-MM-DD format

		for ($i = 1; $i <= $_POST['print_qty']; $i++) {
			echo "<p class='inline'><span ><b>Item: $product</b></span>" . bar128(stripcslashes($_POST['product_id'])) . "<span ><b>Price: $rate</b><span></p>&nbsp&nbsp&nbsp&nbsp";
		}
		
		$sql = "INSERT INTO barcodegenerate (product, product_id, price, print_qty, upload_date) VALUES (:product, :product_id, :price, :print_qty, :upload_date)";
        $q = $db->prepare($sql);
        $q->execute(array(':product' => $product, ':product_id' => $product_id, ':price' => $rate, ':print_qty' => $print_qty, ':upload_date' => $current_date));
       
		?>
	</div>
	

</body>
</html>
