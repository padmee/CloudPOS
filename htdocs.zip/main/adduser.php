<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="assets/js/adapter-3.3.3.min.js"></script>
<script type="text/javascript" src="assets/js/vue-2.1.10.min.js"></script>
<script type="text/javascript" src="assets/js/instascan.min.js"></script>
<link rel="stylesheet" href="assets/css/bootstrap-3.4.1.min.css">



    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


        

<form action="register.php" method="post" enctype="multipart/form-data">
<center><h4><i class="icon-plus-sign icon-large"></i> Add User</h4></center>
<hr>
<div id="ac">

    

                

<span>Full Name : </span><input type="text" style="width:265px; height:30px;" name="name" ><br>
<span>Email : </span><input type="text" style="width:265px; height:30px;" name="username" Required/><br>
<span>Address :</span><textarea style="width:265px; height:50px;" name="address"> </textarea><br>
<span>Phone :  </span><input type="number" style="width:265px; height:30px;" name="phone" Required/><br>
<span>Password :  </span><input type="password" style="width:265px; height:30px;" id="password" name="password" Placeholder="enter your password" title="Eight or more characters" required/><br>
<span>Password :  </span><input type="password" style="width:265px; height:30px;" id="cpassword" name="cpassword" Placeholder="conform your password" title="Eight or more characters" required/><br>


        
        
<span>Position : </span>
<select name="type"  style="width:265px; height:30px; margin-left:-5px;" Required>
        <option></option>
         <option value="admin">Admin</option>
         <option value="cashiyer">Cashiyer</option>
         <option value="grn">GRN Editor</option>
         <option value="production">Production</option>
    </select>
<br>


<span>Branch : </span>
<select name="bcode"  style="width:265px; height:30px; margin-left:-5px;" Required>
<option></option>
	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM branch WHERE bcode");
		$result->bindParam(':bcode', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['bcode']; ?></option>
	<?php
	}
	?>
</select><br> 


<span>Image : </span><input type="file" name="filename" placeholder="Select Image" class="box"><br>

<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;" type="submit" name="submit" value="Upload"><i class="icon icon-save icon-large"></i> Save User</button>
</div>
</div>


        
</form>



