<?php
session_start();
include('../connect.php');




$a = $_POST['invoice'];
$b = $_POST['product'];
$c = $_POST['qty'];
$w = $_POST['pt'];
$date = $_POST['date'];
$discount = $_POST['discount'];


$asasa=$_POST['price'];
$code=$_POST['product_code'];
$gen=$_POST['gen_name'];
$name=$_POST['product_name'];
$p=$_POST['profit'];




$fffffff=$asasa-$discount;
$d=$fffffff*$c;
$profit=$asasa*$c;


// query
$sql = "INSERT INTO sales_order (invoice,product,qty,amount,name,price,profit,product_code,gen_name,date) VALUES (:a,:b,:c,:d,:name,:asasa,:profit,:code,:gen,:date)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':name'=>$name,':asasa'=>$asasa,':profit'=>$profit,':code'=>$code,':gen'=>$gen,':date'=>$date));
header("location: sales.php?id=$w&invoice=$a");



?>