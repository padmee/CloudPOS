<?php
	include('../connect.php');
	$id=$_GET['subcontractor_id'];
	$result = $db->prepare("DELETE FROM subcontractor WHERE subcontractor_id= :memid");
	$result->bindParam(':memid', $subcontractor_id);
	$result->execute();
?>