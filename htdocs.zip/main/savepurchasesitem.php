<?php
session_start();
include('../connect.php');

$a = $_POST['invoice'];
$b = $_POST['product'];
$c = $_POST['qty'];
$e = $_POST['exdate'];
$f = $_POST['o_price']; // cost price
$g = $_POST['price'];   // selling price

// Validate quantity
if (!isset($c) || !is_numeric($c)) {
    echo "Invalid quantity value.";
    exit;
}

// Optional: get last purchase item (if needed for comparison/log)
$result = $db->prepare("SELECT * FROM purchases_item WHERE product_code = :userid ORDER BY id DESC LIMIT 1");
$result->bindParam(':userid', $b);
$result->execute();
$row = $result->fetch();



// Calculate cost using NEW o_price
$d = $f * $c;

// Insert new purchase
$sqlInsert = "INSERT INTO purchases_item (product_code, qty, cost, invoice, exdate, o_price, price)
              VALUES (:product_code, :qty, :cost, :invoice, :exdate, :o_price, :price)";
$qInsert = $db->prepare($sqlInsert);
$qInsert->execute([
    ':product_code' => $b,
    ':qty' => $c,
    ':cost' => $d,
    ':invoice' => $a,
    ':exdate' => $e,
    ':o_price' => $f,
    ':price' => $g
]);

header("Location: purchasesportal.php?iv=$a");
?>
