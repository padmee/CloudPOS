<?php
	include('../connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM branch WHERE id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


<form action="saveeditbranch.php" method="post" enctype="multipart/form-data">
    <center><h4><i class="icon-edit icon-large"></i> Edit Branch</h4></center>
    <hr>
    <div id="ac">
        <input type="hidden" name="memi" value="<?php echo $id; ?>" />

        <!-- Show existing image -->
        <?php if (!empty($row["images"])): ?>
            <img src="<?= $row["images"] ?>" alt="Branch Image" style="max-height: 100px;"><br>
        <?php endif; ?>

        <!-- Image upload -->
        <span>Change Image: </span><input type="file" name="filename" class="box"><br>
        <input type="hidden" name="old_image" value="<?php echo htmlspecialchars($row['images']); ?>">

        <span>Branch Code : </span><input type="text" name="bcode" value="<?php echo $row['bcode']; ?>" required style="width:200px; height:30px;"><br>
        <span>Branch Name : </span><input type="text" name="bname" value="<?php echo $row['bname']; ?>" style="width:200px; height:30px;"><br>
        <span>Address :</span><textarea name="baddress" style="width:200px; height:50px;"><?php echo $row['baddress']; ?></textarea><br>
        <span>Phone: </span><input type="text" name="bphone" value="<?php echo $row['bphone']; ?>" style="width:200px; height:30px;"><br>

        <div style="float:right; margin-right:10px;">
            <button class="btn btn-success btn-block btn-large" style="width:200px;"><i class="icon icon-save icon-large"></i> Save Changes</button>
        </div>
    </div>
</form>

<?php
}
?>