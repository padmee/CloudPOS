


<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="assets/js/adapter-3.3.3.min.js"></script>
<script type="text/javascript" src="assets/js/vue-2.1.10.min.js"></script>
<script type="text/javascript" src="assets/js/instascan.min.js"></script>
<link rel="stylesheet" href="assets/css/bootstrap-3.4.1.min.css">

<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


    

        

<form action="savemode.php" method="post" enctype="multipart/form-data">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Mode</h4></center>
<hr>
<div id="ac">


    <input type="hidden" name="bcode" value="<?php echo $_SESSION['SESS_BCODE'];?>" />

   
                

<span>Mode : </span><input type="text" style="width:265px; height:30px;" name="mode" Required/><br>


<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;" type="submit" name="submit" value="Upload"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>


        
</form>


