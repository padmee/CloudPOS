<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
   
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


   <title>Bar/QR Scan</title>
</head>
<body>

<script src="assets/js/html5-qrcode-2.3.4.min.js" integrity="sha512-k/KAe4Yff9EUdYI5/IAHlwUswqeipP+Cp5qnrsUjTPCgl51La2/JhyyjNciztD7mWNKLSXci48m7cctATKfLlQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<style>
main {
display: flex;
justify-content: center;
align-items: center;
}
#reader {
width: 600px;
}
#result {
text-align: center;
font-size: 1.5rem;
}
</style>

<main>
<div id="reader"></div>
<div id="result"></div>
</main>

<script>
const scanner = new Html5QrcodeScanner('reader', {
    qrbox: {
        width: 250,
        height: 250,
    },
    fps: 20,
});

scanner.render(success, error);

function success(result) {
    console.log("Function called");
    // Retrieve the invoice number from the URL parameter
    var invoiceNumber = "<?php echo $_GET['invoice']; ?>";

    // Corrected URL building with both scanned value and invoice number
     window.location.href = "sales.php?value=" + encodeURIComponent(result) + "&invoice=" + encodeURIComponent(invoiceNumber);
}

function error(err) {
    console.error(err);
}
</script>
  
</body>
</html>
