<?php
include('../connect.php');

$code = $_GET['code'];
$stmt = $db->prepare("SELECT pi.id, p.product_name, pi.expiry_date, pi.location_name
                      FROM purchases_item pi
                      JOIN products p ON pi.product_code = p.product_code
                      WHERE pi.product_code = ?");
$stmt->execute([$code]);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
