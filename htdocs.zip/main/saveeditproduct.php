<?php
// configuration
include('../connect.php');

// new data




$id = $_POST['memi'];
$a = $_POST['code'];
$z = $_POST['gen'];
$b = $_POST['name'];

$e = $_POST['supplier'];


$k = $_POST['bcode'];

// Handle file uploads for company image
$fileName = $_FILES['image']['name'];
$target = "images/products/";
$fileTarget = $target . $fileName;
$tempFileName = $_FILES["image"]["tmp_name"];
$result = move_uploaded_file($tempFileName, $fileTarget);


// query
$sql = "UPDATE products 
        SET  product_code=?, gen_name=?, product_name=?,  supplier=?,  images=?
		WHERE product_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$z,$b,$e,$fileTarget, $id));
header("location: products.php");

?>