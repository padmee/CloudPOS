<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


<form action="savesubcontractor.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Sub-Contractor</h4></center>
<hr>
<div id="ac">
<span>Sub-Contractor Name : </span><input type="text" style="width:265px; height:30px;" name="subcontractor_name" required/><br>


<span>State : </span>
<select name="mode"  style="width:265px; height:30px; margin-left:-5px;" >
<option></option>
	<?php
	include('../connect.php');
	$result3 = $db->prepare("SELECT * FROM mode");
		$result3->bindParam(':mode_id', $res3);
		$result3->execute();
		for($i=0; $row3 = $result3->fetch(); $i++){
	?>
		<option><?php echo $row3['mode']; ?></option>
	<?php
	}
	?>
</select><br>


<span>Address : </span><input type="text" style="width:265px; height:30px;" name="subcontractor_address" /><br>
<span>Contact Person : </span><input type="text" style="width:265px; height:30px;" name="contact_person" /><br>
<span>Contact No. : </span><input type="text" style="width:265px; height:30px;" name="subcontractor_contact" /><br>
<span>Note : </span><textarea style="width:265px; height:80px;" name="note" /></textarea><br>
<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>