<?php
session_start();
include('../connect.php');




    


$name=$_POST["name"];
$username=$_POST["username"];
$address=$_POST["address"];
$phone=$_POST["phone"];
$type=$_POST["type"];
$bcode=$_POST["bcode"];
$pass=$_POST["password"];

$fileName = $_FILES['filename']['name'];

		$target = "images/users/";		
		$fileTarget = $target.$fileName;	
		$tempFileName = $_FILES["filename"]["tmp_name"];

$result = move_uploaded_file($tempFileName,$fileTarget);



$sql = "INSERT INTO user (name,username,address,phone,password,position,bcode,images) VALUES (:name,:username,:address,:phone,:pass,:type,:bcode,:fileTarget)";
$q = $db->prepare($sql);
$q->execute(array(':name'=>$name,':username'=>$username,':address'=>$address,':phone'=>$phone,':pass'=>$pass,':type'=>$type,':bcode'=>$bcode,':fileTarget'=>$fileTarget));
header("location: userview.php");





?>



