<?php
session_start();
include('../connect.php');
$a = $_POST['iv'];
$b = $_POST['date'];
$c = $_POST['supplier'];
$d = $_POST['remarks'];
// $bcode = $_POST['bcode'];

$bcode=$_SESSION['SESS_BCODE'];
// query
$sql = "INSERT INTO purchases (invoice_number,date,suplier,remarks,bcode) VALUES (:a,:b,:c,:d,:bcode)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':bcode'=>$bcode));
header("location: purchasesportal.php?iv=$a");


?>