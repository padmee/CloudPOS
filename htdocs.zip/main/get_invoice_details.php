<?php
include('../connect.php');

if (isset($_GET['invoice'])) {
    $invoice = $_GET['invoice'];
    $stmt = $db->prepare("SELECT * FROM sales WHERE invoice_number = :invoice LIMIT 1");
    $stmt->bindParam(':invoice', $invoice);
    $stmt->execute();
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($data);
}
?>
