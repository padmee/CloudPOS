<?php
	include('../connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM transaction WHERE transaction_id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


<center><h4><i class="icon-edit icon-large"></i> Image View</h4></center>
<hr>
<div id="ac" >
<input type="hidden" name="memi" value="<?php echo $id; ?>"  />

<?php echo' <img src="'.$row["images"].'" alt="" > '; ?><br>




</div>

<?php
}
?>

