<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['memi'];
$a = $_POST['companyid'];
$z = $_POST['companyname'];
$b = $_POST['companylocation'];
$c = $_POST['companyphone'];
$d = $_POST['companyowner'];
$e = $_POST['companyreg'];
$f = $_POST['companytype'];


// query
$sql = "UPDATE company 
        SET companyid=?, companyname=?, companylocation=?, companyphone=?, companyowner=?, companyreg=?, companytype=?
        WHERE companyid=?";
$q = $db->prepare($sql);
$q->execute(array($a, $z, $b, $c, $d, $e, $f, $id));

header("location: company.php");
?>
