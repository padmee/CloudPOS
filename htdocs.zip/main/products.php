<html>
<head>
<title>
POS
</title>

<?php 
require_once('auth.php');
?>
 <link href="css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="css/bootstrap-responsive.css" rel="stylesheet">


    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="tcal.css">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="tcal.js"></script>


<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<!--sa poip up-->
<script src="jeffartagame.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>
</head>
<?php
function createRandomPassword() {
	$chars = "003232303232023232023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 7) {

		$num = rand() % 33;

		$tmp = substr($chars, $num, 1);

		$pass = $pass . $tmp;

		$i++;

	}
	return $pass;
}
$finalcode='SB-'.createRandomPassword();
?>

<script>
function sum() {
            var txtFirstNumberValue = document.getElementById('txt1').value;
            var txtSecondNumberValue = document.getElementById('txt2').value;
            var result = parseInt(txtFirstNumberValue) - parseInt(txtSecondNumberValue);
            if (!isNaN(result)) {
                document.getElementById('txt3').value = result;
				
            }
			
			 var txtFirstNumberValue = document.getElementById('txt11').value;
            var result = parseInt(txtFirstNumberValue);
            if (!isNaN(result)) {
                document.getElementById('txt22').value = result;				
            }
			
			 var txtFirstNumberValue = document.getElementById('txt11').value;
            var txtSecondNumberValue = document.getElementById('txt33').value;
            var result = parseInt(txtFirstNumberValue) + parseInt(txtSecondNumberValue);
            if (!isNaN(result)) {
                document.getElementById('txt55').value = result;
				
            }
			
			 var txtFirstNumberValue = document.getElementById('txt4').value;
			 var result = parseInt(txtFirstNumberValue);
            if (!isNaN(result)) {
                document.getElementById('txt5').value = result;
				}
			
        }
</script>


<script>
function searchByDateRange() {
  var startDate = document.getElementById("dateRangeStart").value;
  var endDate = document.getElementById("dateRangeEnd").value;
  
  var table = document.getElementById("resultTable");
  var rows = table.getElementsByTagName("tr");
  
  for (var i = 1; i < rows.length; i++) {
    var row = rows[i];
    var dateColumn = row.getElementsByTagName("td")[8]; // Assuming the date column index is 8
    var rowDate = dateColumn.textContent;
    
    if (startDate === "" && endDate === "") {
      row.style.display = ""; // Show all rows if no filter applied
    } else {
      var startDateValid = startDate === "" || rowDate >= startDate;
      var endDateValid = endDate === "" || rowDate <= endDate;
      
      if (startDateValid && endDateValid) {
        row.style.display = ""; // Both dates match, show the row
      } else {
        row.style.display = "none"; // Dates don't match, hide the row
      }
    }
  }
}

</script>




<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

<script>
function myFunction2() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput2");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

<script>
function myFunction3() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput3");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

<script>
function myFunction4() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput4");
  filter = input.value.toUpperCase();
  table = document.getElementById("resultTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[6];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
	

<body>
<?php include('navfixed.php');?>
<div class="container-fluid">
      <div class="row-fluid">
	<div class="span2">
          <div class="well sidebar-nav">
              <ul class="nav nav-list">
              <li><a href="index.php"><i class="icon-dashboard icon-2x"></i> Dashboard </a></li> 
			<li><a href="sales.php?id=cash&invoice=<?php echo $finalcode ?>"><i class="icon-shopping-cart icon-2x"></i> Sales</a>  </li>             
			<li class="active"><a href="products.php"><i class="icon-list-alt icon-2x"></i> Products</a>                                     </li>
			<li><a href="customer.php"><i class="icon-group icon-2x"></i> Customers</a>                                    </li>
			<li><a href="supplier.php"><i class="icon-group icon-2x"></i> Suppliers</a>                                    </li>
			<li><a href="salesreport.php?d1=0&d2=0"><i class="icon-bar-chart icon-2x"></i> Sales Report</a>                </li>


			<br><br><br><br><br><br>		
		
				
				</ul>             
          </div><!--/.well -->
        </div><!--/span-->
	<div class="span10">
	<div class="contentheader">
			<i class="icon-table"></i> Products
			</div>
			<ul class="breadcrumb">
			<li><a href="index.php">Dashboard</a></li> /
			<li class="active">Products</li>
			</ul>


<div style="margin-top: -19px; margin-bottom: 21px;">
<a  href="index.php"><button class="btn btn-default btn-large" style="float: left;"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>
			<?php 
			include('../connect.php');
			    $bcode=$_SESSION['SESS_BCODE'];
				$result = $db->prepare("SELECT * FROM products WHERE bcode='$bcode'");
				$result->execute();
				$rowcount = $result->rowcount();
			?>
			
			<?php 
			include('../connect.php');
			    $bcode=$_SESSION['SESS_BCODE'];
				// Count products with total available qty < 10 from purchases_item (branch-specific)
$lowStockQuery = $db->prepare("
    SELECT COUNT(DISTINCT pi.product_code) AS low_stock_count
    FROM purchases_item pi
    INNER JOIN purchases p ON pi.invoice = p.invoice_number
    WHERE p.bcode = :bcode
    GROUP BY pi.product_code
    HAVING SUM(pi.qty) < 10
");
$lowStockQuery->execute([':bcode' => $bcode]);
$rowcount123 = $lowStockQuery->rowCount();


			?>
			
				<div style="text-align:center;">
			Total Number of Products:  <font color="green" style="font:bold 22px 'Aleo';">[<?php echo $rowcount;?>]</font>
			</div>
			
			<div style="text-align:center;">
			<font style="color:rgb(255, 95, 66);; font:bold 22px 'Aleo';">[<?php echo $rowcount123;?>]</font> Products are below QTY of 10 
			</div>
</div>




<form action="product.php" method="get">
    <center>
        <strong>
            Date Received From:
            <input type="text" style="width: 223px; padding: 14px;" name="d1" id="dateRangeStart" class="tcal" value="" />
            Expiry Date From:
            <input type="text" style="width: 223px; padding: 14px;" name="d2" id="dateRangeEnd" class="tcal" value="" />
            <button class="btn btn-info" style="width: 123px; height: 35px; margin-top: -8px; margin-left: 8px;" type="button" onclick="searchByDateRange();">
                <i class="icon icon-search icon-large"></i> Search
            </button>
        </strong>
    </center>
</form>




<input type="text" style="padding:15px;" id="myInput" onkeyup="myFunction()" placeholder="Search Branch Products..." >
<input type="text" style="padding:15px;" id="myInput2" onkeyup="myFunction2()" placeholder="Search Products ID..." >
<input type="text" style="padding:15px;" id="myInput3" value="<?php echo isset($_GET['value']) ? $_GET['value'] : ''; ?>" onkeyup="myFunction3()" placeholder="Search Brand/Code..." >
<input type="text" style="padding:15px;" id="myInput4" onkeyup="myFunction4()" placeholder="Search Supplier..." >
<a href="qrsr.php"><i class="icon-plus-sign icon-large"></i> BAR / QR Search</a>
<a rel="facebox" href="addproduct.php"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px;" /><i class="icon-plus-sign icon-large"></i> Add Product</button></a>
<a href="qr.php"><Button type="submit" class="btn btn-info" style="float:right; width:230px; height:35px;" /><i class="icon-plus-sign icon-large"></i> Add BAR / QR</button></a><br><br>





<table class="hoverTable" id="resultTable" data-responsive="table" style="text-align: left;">
	<thead>
		<tr>
		    <th width="6%"> Branch code </th>
		    <th width="6%"> Product ID </th>
			<th width="12%"> QR / Bar Code </th>
			<th width="15%"> Image </th>
			<th width="12%"> Generic Name <br> (ex:book , pen...)</th>
			<th width="13%"> Product Name / Description </th>
			<th width="10%"> Supplier </th>
			<th width="8%"> QTY </th>
			<th width="10%"> Total </th>
			<th width="8%"> Action </th>
		</tr>
	</thead>
	<tbody>
<?php
function formatMoney($number, $fractional = false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}

include('../connect.php');
$bcode = $_SESSION['SESS_BCODE'];

// Get all products for this branch
$result = $db->prepare("SELECT * FROM products WHERE bcode = :bcode ORDER BY product_id DESC");
$result->execute([':bcode' => $bcode]);

while ($row = $result->fetch()) {
    $product_code = $row['product_code'];
    $branch_code = $row['bcode'];

    // Get total qty and value from purchases_item + purchases (branch-specific)
    $qty_stmt = $db->prepare("
        SELECT 
            SUM(pi.qty) AS total_qty, 
            SUM(pi.qty * pi.o_price) AS total_value
        FROM purchases_item pi
        INNER JOIN purchases p ON pi.invoice = p.invoice_number
        WHERE pi.product_code = :pcode AND p.bcode = :bcode
    ");
    $qty_stmt->execute([':pcode' => $product_code, ':bcode' => $branch_code]);
    $qty_result = $qty_stmt->fetch(PDO::FETCH_ASSOC);

    $total_qty = $qty_result['total_qty'] ?? 0;
    $total_value = $qty_result['total_value'] ?? 0;

    // Highlight row if stock is less than 10
    if ($total_qty < 10) {
        echo '<tr class="alert alert-warning record" style="color: #fff; background:rgb(255, 95, 66);">';
    } else {
        echo '<tr class="record">';
    }
    ?>
    <td><?php echo $row['bcode']; ?></td>
    <td><?php echo $row['product_id']; ?></td>
    <td><?php echo $row['product_code']; ?></td>
    <td><?php echo '<img src="' . $row["images"] . '" alt="">'; ?></td>
    <td><?php echo $row['gen_name']; ?></td>
    <td><?php echo $row['product_name']; ?></td>
    <td><?php echo $row['supplier']; ?></td>
    <td><?php echo $total_qty; ?></td>
    <td><?php echo formatMoney($total_value, true); ?></td>
    <td>
        <a rel="facebox" title="Click to Open Image" href="viewimage.php?id=<?php echo $row['product_id']; ?>">
            <button class="btn btn-success"><i class="icon-bar-chart icon-2x"></i></button>
        </a>
        <a rel="facebox" title="Click to edit the product" href="editproduct.php?id=<?php echo $row['product_id']; ?>">
            <button class="btn btn-warning"><i class="icon-edit"></i></button>
        </a>
        <a href="#" id="<?php echo $row['product_id']; ?>" class="delbutton" title="Click to Delete the product">
            <button class="btn btn-danger"><i class="icon-trash"></i></button>
        </a>
    </td>
    </tr>
    <?php
}
?>
</tbody>

</table>
<div class="clearfix"></div>
</div>
</div>
</div>

<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
 if(confirm("Sure you want to delete this Product? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deleteproduct.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>







</body>
<?php include('footer.php');?>

</html>