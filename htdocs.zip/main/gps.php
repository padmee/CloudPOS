<!DOCTYPE html>
<html>
<head>
    <title>Device Locations</title>
    <style>
        body {
            font-family: Arial;
        }

        #map {
            height: 850px;
            width: 100%; /* Make the map width scalable */
        }
    </style>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


</head>
<body>
    <h1>Latest Device Locations</h1>

    <div id="map"></div>

    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        var map = L.map('map').setView([0, 0], 2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var group = L.featureGroup([]).addTo(map); // Create an empty feature group

        function loadMarkers() {
            // Clear the existing markers
            group.clearLayers();

            // Fetch the latest markers from load_markers.php
            fetch('load_markers.php')
                .then(response => response.json())
                .then(data => {
                    // Add the new markers to the group
                    data.forEach(location => {
                        L.marker([location.lat, location.lng])
                            .bindPopup(`<strong>${location.device}:</strong><br>Latest Location: ${location.created_date}<br><a href="https://www.google.com/maps?q=${location.lat},${location.lng}" target="_blank">Open in Google Maps</a>`)
                            .addTo(group);
                    });

                    // Fit the map bounds to show all markers
                    map.fitBounds(group.getBounds(), { padding: [50, 50] });
                });
        }

        // Initial load of markers
        loadMarkers();

        // Refresh the markers every 1 minute (adjust the interval as needed)
        setInterval(loadMarkers, 30000);
    </script>
</body>
</html>
