


<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="assets/js/adapter-3.3.3.min.js"></script>
<script type="text/javascript" src="assets/js/vue-2.1.10.min.js"></script>
<script type="text/javascript" src="assets/js/instascan.min.js"></script>
<link rel="stylesheet" href="assets/css/bootstrap-3.4.1.min.css">


<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>





        

<form action="generalsalesave.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Sale</h4></center>
<hr>
<div id="ac">



											
<!--<input type="text" name="pt" value="<?php echo $_GET['id']; ?>" />-->

<span>PType:</span>
<select name="pt" style="width:255px; height:30px;" >

	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM payment_type");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['ptype']; ?></option>
	<?php
	}
	?>
</select>





<!-- <input type="number" name="price" value="" min="0" placeholder="Price" autocomplete="on" style="width: 68px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />-->
<!--<input type="hidden" name="product" placeholder="Product Code" value ="1" style="width: 200px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />-->
<!--<input type="number" name="qty" value="1" min="1" placeholder="Qty" autocomplete="on" style="width: 68px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" / required>-->
<!--<input type="hidden" name="discount" value="0" min="0" placeholder="Discount" autocomplete="on" style="width: 68px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />-->
<!--<input type="hidden" name="date" value="<?php echo date("m/d/y"); ?>" />-->

<!--<input type="hidden" name="gen_name" placeholder="gen_name" value ="General" style="width: 200px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />-->
<!--<input type="hidden" name="product_name" placeholder="product_name" value ="product_name" style="width: 200px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />-->
<!--<input type="hidden" name="profit" value="0" min="0" placeholder="profit" autocomplete="on" style="width: 68px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />-->










<span>Price : </span><input type="number" style="width:265px; height:30px;" name="price" /><br>
<span>Quantity : </span><input type="number" style="width:265px; height:30px;"value="1" min="1" name="qty" /><br>


<!--<span>Product : </span>-->
<input type="hidden" value ="1" style="width:265px; height:30px;" name="product"/><br>
<!--<span>Discount: </span>-->
<input type="hidden" value="0" min="0" style="width:265px; height:30px;" name="discount" /><br>
<!--<span>Date : </span>-->
<input type="hidden" value="<?php echo date ('M-d-Y'); ?>" style="width:265px; height:30px;" name="date" /><br>
<!--<span>Gen Name : </span>-->
<input type="hidden" value ="General" style="width:265px; height:30px;" name="gen_name"/><br>
<!--<span>Product Name : </span>-->
<input type="hidden" value ="General" style="width:265px; height:30px;" name="product_name"/><br>
<!--<span>Profit : </span>-->
<input type="hidden" value="0" min="0" style="width:265px; height:30px;" name="profit" readonly><br>






<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;" type="submit" name="submit" ><i class="icon icon-save icon-large"></i> Add</button>
</div>
</div>


        
</form>
