<?php
// configuration
include('../connect.php');

// new data




$id = $_POST['memi'];
$name=$_POST["name"];
$username=$_POST["username"];
$address=$_POST["address"];
$phone=$_POST["phone"];
$position=$_POST["position"];
$bcode=$_POST["bcode"];


// Handle file uploads for company image
$fileName = $_FILES['image']['name'];
$target = "images/users/";
$fileTarget = $target . $fileName;
$tempFileName = $_FILES["image"]["tmp_name"];
$result = move_uploaded_file($tempFileName, $fileTarget);



// query
$sql = "UPDATE user 
        SET  name=?, username=?, address=?, phone=?, position=?, bcode=?, images=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($name,$username,$address,$phone,$position,$bcode,$fileTarget,$id));
header("location: userview.php");

?>