<?php
function createRandomPassword() {
	$chars = "003232303232023232023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 7) {

		$num = rand() % 33;

		$tmp = substr($chars, $num, 1);

		$pass = $pass . $tmp;

		$i++;

	}
	return $pass;
}
$finalcode='IN-'.createRandomPassword();
?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>

<form action="saveledger.php" method="post" enctype="multipart/form-data">
<!--<input type="hidden" name="name" value="<?php echo $_GET['invoice']; ?>" />-->


<span>Customer : </span>
<select name="customer_name"  style="width:265px; height:30px; margin-left:-5px;" Required>
<option></option>
	<?php 
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM customer WHERE customer_id");
		$result->bindParam(':customer_name', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['customer_name']; ?></option>
	<?php
	}
	?>
</select><br> 



<input type="hidden" name="invoice" value="<?php echo $finalcode; ?>" />
<input type="hidden" name="tot" value="<?php echo $_GET['amount']; ?>" />
<div id="ac">
<span>Amount : </span><input type="text" style="width:265px; height:30px;" name="amount" /><br>
<span>Remarks : </span><input type="text" style="width:265px; height:30px;" name="remarks" /><br>
<span>&nbsp;</span>
<button class="btn btn-success btn-block btn-large" style="width:267px;" type="submit" name="submit" value="Upload"><i class="icon icon-save icon-large"></i> Save</button>

</div>
</form>