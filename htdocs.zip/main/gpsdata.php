<?php 

include('../gpsconnect.php');

$lat = $_GET['lat'];
$lng = $_GET['lng'];
$device = $_GET['device'];

echo $lat;
echo "<br>";
echo $lng;
echo "<br>";
echo $device;

$sql = "INSERT INTO tbl_gps(lat,lng,device,created_date) 
	VALUES('".$lat."','".$lng."','".$device."','".date("Y-m-d H:i:s")."')";

if($db->query($sql) === FALSE)
	{ echo "Error: " . $sql . "<br>" . $db->error; }

echo "<br>";
echo $db->insert_id;
