<?php
session_start();
include('../connect.php');

$bcode = $_SESSION['SESS_BCODE']; // Get current branch

$stmt = $db->prepare("
    SELECT 
        so.product, 
        p.gen_name AS name,
        p.product_code AS code,
        p.images AS image,  -- changed to 'images' if that's your actual column name
        SUM(so.qty) as total_qty
    FROM sales_order so
    JOIN sales s ON so.invoice = s.invoice_number
    JOIN products p ON so.product = p.product_code
    WHERE s.bcode = ?
    GROUP BY so.product
    ORDER BY total_qty DESC
    LIMIT 12
");
$stmt->execute([$bcode]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fallback image if none is set
foreach ($items as &$item) {
    if (empty($item['image']) || !file_exists($item['image'])) {
        $item['image'] = 'images/pos.png';
    }
}

echo json_encode($items);
?>
