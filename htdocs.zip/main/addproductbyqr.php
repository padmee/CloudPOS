<html>
    <head>
<script type="text/javascript" src="assets/js/adapter-3.3.3.min.js"></script>
<script type="text/javascript" src="assets/js/vue-2.1.10.min.js"></script>
<script type="text/javascript" src="assets/js/instascan.min.js"></script>
<link rel="stylesheet" href="assets/css/bootstrap-3.4.1.min.css">

<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <video id="preview" width="100%"></video>
                </div>
                <div class="col-md-6">
                    <label>SCAN QR CODE</label>
                    <input type="text" name="text" id="text" readonyy="" placeholder="scan qrcode" class="form-control">
                </div>
            </div>
        </div>

        <script>
           let scanner = new Instascan.Scanner({ video: document.getElementById('preview')});
           Instascan.Camera.getCameras().then(function(cameras){
               if(cameras.length > 2 ){
                   scanner.start(cameras[2]);
               } else{
                   alert('No cameras found');
               }

           }).catch(function(e) {
               console.error(e);
           });

           scanner.addListener('scan',function(c){
               document.getElementById('text').value=c;
           });

        </script>
    </body>
</html>