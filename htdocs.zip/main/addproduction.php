<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="assets/js/adapter-3.3.3.min.js"></script>
<script type="text/javascript" src="assets/js/vue-2.1.10.min.js"></script>
<script type="text/javascript" src="assets/js/instascan.min.js"></script>
<link rel="stylesheet" href="assets/css/bootstrap-3.4.1.min.css">


<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>

    

        

<form action="saveproduction.php" method="post" enctype="multipart/form-data">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Production</h4></center>
<hr>
<div id="ac">

    

    
    
     <input type="hidden" name="bcode" value="<?php echo $_SESSION['SESS_BCODE'];?>" />
    
                

<span>Design No : </span><input type="text" style="width:265px; height:30px;" name="design_no" Required><br>

<span>Date: </span><input type="date" style="width:265px; height:30px;" name="date"Required /><br>
<span>Qty : </span><input type="text" value="1" min="1" style="width:265px; height:30px;" name="qty" Required/><br>
<span>Color : </span><input type="color" style="width:50px; height:30px;" name="colour_code" ><br>
<span>Target Date : </span><input type="date" value="<?php echo date ('M-d-Y'); ?>" style="width:265px; height:30px;" name="target_date" Required/><br>



<span>Mode : </span>
<select name="mode"  style="width:265px; height:30px; margin-left:-5px;" Required>
<option></option>
	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM mode");
		$result->bindParam(':mode_id', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['mode']; ?></option>
		
	<?php
	}
	?>
</select><br>


<span>Sub : </span>
<select name="subcontractor_name"  style="width:265px; height:30px; margin-left:-5px;" >
<option></option>
	<?php
	include('../connect.php');
	$result1 = $db->prepare("SELECT * FROM subcontractor");
		$result1->bindParam(':subcontractor_id', $res1);
		$result1->execute();
		for($i=0; $row1 = $result1->fetch(); $i++){
	?>
		<option><?php echo $row1['subcontractor_name']; ?></option>
		
	<?php
	}
	?>
</select><br>


<span>State : </span>
<select name="state"  style="width:265px; height:30px; margin-left:-5px;" Required>
<option></option>
	<?php
	include('../connect.php');
	$result3 = $db->prepare("SELECT * FROM state");
		$result3->bindParam(':state_id', $res3);
		$result3->execute();
		for($i=0; $row3 = $result3->fetch(); $i++){
	?>
		<option><?php echo $row3['state']; ?></option>
	<?php
	}
	?>
</select><br>

<span>Image : </span><input type="file" name="filename" placeholder="Select Image" class="box"><br>

<div style="float:right; margin-right:10px;">
<!--<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>-->
<button class="btn btn-success btn-block btn-large" style="width:267px;" type="submit" name="submit" value="Upload"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>


        
</form>





