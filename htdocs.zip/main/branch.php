<?php
session_start();
include('../connect.php');


$bcode=$_POST["bcode"];
$bname=$_POST["bname"];
$baddress=$_POST["baddress"];
$bphone=$_POST["bphone"];



$sql = "INSERT INTO branch (bcode,bname,baddress,bphone) VALUES (:bcode,:bname,:baddress,:bphone)";
$q = $db->prepare($sql);
$q->execute(array(':bcode'=>$bcode,':bname'=>$bname,':baddress'=>$baddress,':bphone'=>$bphone));
header("location: index.php");





?>



