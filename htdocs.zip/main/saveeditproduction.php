<?php
// configuration
include('../connect.php');

// new data




$id = $_POST['memi'];
$a = $_POST['design_no'];
$b = $_POST['date'];
$c = $_POST['qty'];
$d = $_POST['mode'];
$e = $_POST['subcontractor_name'];
$f = $_POST['colour_code'];
$g = $_POST['target_date'];
$h = $_POST['state'];
$k = $_POST['bcode'];



// query
$sql = "UPDATE production 
        SET  design_no=?, date=?, qty=?, mode=?, subcontractor_name=?, colour_code=?, target_date=?, state=?
		WHERE production_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$b,$c,$d,$e,$f,$g,$h, $id));
header("location: production.php");

?>