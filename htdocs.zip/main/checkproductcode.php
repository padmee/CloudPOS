<?php
include('../connect.php');

$productCode = $_GET['code'];
$branchCode = $_GET['branch'];

$query = "SELECT COUNT(*) FROM products WHERE product_code = :code AND bcode = :branch";
$statement = $db->prepare($query);
$statement->bindParam(':code', $productCode);
$statement->bindParam(':branch', $branchCode);
$statement->execute();

$count = $statement->fetchColumn();

if ($count > 0) {
    echo "exists";
} else {
    echo "not_exists";
}
?>
