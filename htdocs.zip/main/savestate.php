<?php
session_start();
include('../connect.php');
$a = $_POST['state'];

$bcode=$_SESSION['SESS_BCODE'];





$sql = "INSERT INTO state (state,bcode) VALUES (:a,:bcode)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':bcode'=>$bcode));
header("location: state.php");


?>