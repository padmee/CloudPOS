<?php
include('../connect.php');

$productCode = $_GET['productCode'];
$query = $db->prepare("SELECT price FROM products WHERE product_code = :productCode");
$query->bindParam(':productCode', $productCode);
$query->execute();
$result = $query->fetch(PDO::FETCH_ASSOC);

if ($result) {
    // Return the product price as a response
    echo $result['price'];
} else {
    // Return a message indicating that the product code was not found
    echo "Product not found";
}
?>
