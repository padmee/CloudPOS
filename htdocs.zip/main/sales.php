<?php
require_once('auth.php');
include('../connect.php'); // Make sure DB connection is available

function generateUniqueInvoice($db) {
    do {
        $chars = "003232303232023232023456789";
        $pass = '';
        for ($i = 0; $i < 8; $i++) {
            $num = rand() % strlen($chars);
            $pass .= substr($chars, $num, 1);
        }

        // Check if this invoice already exists in the sales_order table
        $stmt = $db->prepare("SELECT COUNT(*) FROM sales_order WHERE invoice = ?");
        $stmt->execute([$pass]);
        $count = $stmt->fetchColumn();
    } while ($count > 0); // Keep generating if duplicate found

    return $pass;
}

// Check if invoice number exists in the URL, else generate a unique one
if (isset($_GET['invoice'])) {
    $invoiceNumber = $_GET['invoice'];
} else {
    $invoiceNumber = generateUniqueInvoice($db);
    $_SESSION['invoice_number'] = $invoiceNumber;
}

// Load selected payment type from session (if any)
$selectedPayment = $_SESSION['selected_payment'][$invoiceNumber] ?? '';




?>




<!DOCTYPE html>
<html>
<head>
	<!-- js -->			
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<!--<script src="lib/jquery.js" type="text/javascript"></script>-->
<script src="assets/js/jquery-3.6.0.min.js" type="text/javascript"></script>






<!--<link rel="stylesheet" href="assets/css/bootstrap.min.css">-->
<!--<script src="assets/js/bootstrap.bundle.min.js"></script>-->


<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
  
  $(document).on('afterReveal.facebox', function() {
    // Focus cash input inside facebox modal after it opens
    $('#facebox').find('#cash').focus();
});


</script>


<meta name="viewport" content="width=device-width, initial-scale=1">




<style>
.form-wrapper {
    display: flex;
    flex-direction: column;
    justify-content: flex-start; /* Align forms to the right */
    align-items: flex-end; /* Align forms to the right */
}

.form-container {
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 20px;
    margin-bottom: 20px;
    width: 100%; /* Adjust the width as needed */
    box-sizing: border-box;
    background-color: rgba(240, 240, 240, 0.5); /* Set the background color with opacity */
    
}

.form-container:last-child {
    margin-bottom: 0; /* Remove margin for the last container */
}

@media screen and (max-width: 768px) {
    .form-container {
        width: 100%; /* Adjust for smaller screens */
    }
}


.container {
    display: flex;
}

.left-panel {
    flex: 1;
    padding-right: 10px; /* Add some space between the panels */
}

.right-panel {
    flex: 1;
    padding-left: 10px; /* Add some space between the panels */
}

/* Add styling for product images and names */
.product-images {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    grid-gap: 20px;
}

.product {
    text-align: center;
}

.product-image {
    width: 100%; /* Adjust the width to fit the container */
    height: auto; /* Maintain the aspect ratio */
    max-height: 150px; /* Set a maximum height for the images */
}



.product-name {
    margin-top: 10px;
    font-size: 14px;
}


</style>

<title>
POS
</title>

		<link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
  <link href="css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }
    </style>
    <link href="css/bootstrap-responsive.css" rel="stylesheet">

	<!-- combosearch box-->	
	
	  <!--<script src="vendors/jquery-1.7.2.min.js"></script>-->
    <script src="vendors/bootstrap.js"></script>

	
	
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<!--sa poip up-->




<!--<script type="text/javascript" src="jquery.js"></script>-->

<script type="text/javascript">
  $(document).ready(function ()
  {
    //remember that this is a global variable
    var altPressed = false;
    $(document).keydown(function (event) 
    {
      if(event.which == 18) 
        altPressed = true;
      if(altPressed)
      {
         switch(event.which)
        {
           case 83:
               $('select:option').slideToggle('click');
               return false;
               break;
        }
      }
    });
  });
</script>




<!---------------------------------->

<script>


document.onkeydown = function(evt) {
    evt = evt || window.event;
    var isEscape = false;
    if ("incoming" in evt) {
        isEscape = (evt.key === "Escape" || evt.key === "Esc");
    } else {
        isEscape = (evt.keyCode === 27);
    }
    if (isEscape) {
        // alert("Escape");
        document.getElementById("product").select();
    }
    
    var isShift = false;
    if ("checkout" in evt) {
        isShift = (evt.key === "Shift" || evt.key === "shift");
    } else {
        isShift = (evt.keyCode === 16);
    }
    if (isShift) {
      //   alert("Shift");
        document.getElementById("checkout").click();
    }
    
    var isShift = false;
    if ("generalsalesave" in evt) {
        isControl = (evt.key === "Control" || evt.key === "control");
    } else {
        isControl = (evt.keyCode === 17);
    }
    if (isControl) {
      //   alert("Control");
        document.getElementById("price").select();
    }
    
};



</script>




<!---------------------------------------------->

<script type="text/javascript">
  $(document).ready(function() {
    var isBarcodeScanned = false;

    // Capture barcode scanner input
    $(document).keydown(function(event) {
      if (event.which == 13 && isBarcodeScanned) {
        event.preventDefault(); // Prevent form submission
        var barcodeValue = $('#product').val(); // Change 'product' to the actual input field's ID
        // Perform action with barcodeValue (e.g., insert into input field)
        $('#qty').focus(); // Focus on the next input field (Qty)
        isBarcodeScanned = false;
      }
    });

    // Barcode scanner input detection
    $('#product').on('input', function() {
      isBarcodeScanned = true;
    });
    
    // Automatically focus on the quantity input field after scanning barcode
    $('#qty').on('focus', function() {
      if (isBarcodeScanned) {
        isBarcodeScanned = false;
      }
    });
  });
</script>


<script type="text/javascript">
$(document).ready(function () {

    var isBarcodeScanned = false;

    // Capture Enter key on product input
    $('#product').on('keydown', function (event) {
        if (event.which === 13) { // Enter key
            event.preventDefault(); // Prevent default form submit
            $('#submitButton').click(); // Submit the form
        }
    });

    // Track if barcode was entered (not used here but kept for future logic)
    $('#product_code').on('input', function () {
        isBarcodeScanned = true;
    });

    // Reset flag after quantity input gets focus
    $('#qty').on('focus', function () {
        if (isBarcodeScanned) {
            isBarcodeScanned = false;
        }
    });

});
</script>


 <style type="text/css">
        /* Default style: Hide the result table */
        .external-display-table {
            display: none;
        }
    </style>

    <!--<script src="assets/js/jquery-3.6.0.min.js" type="text/javascript"></script>-->

    <script type="text/javascript">
        $(document).ready(function () {
            // Check if the window is on an external display based on screen width
            function isExternalDisplay() {
                return window.screen.width > 1024; // Adjust the width as needed
            }

            // Show/hide the result table based on external display condition
            function updateTableVisibility() {
                if (isExternalDisplay()) {
                    $('.external-display-table').show();
                } else {
                    $('.external-display-table').hide();
                }
            }

            // Initial visibility check
            updateTableVisibility();

            // Update visibility on window resize
            $(window).resize(function () {
                updateTableVisibility();
            });
        });
    </script>




</head>






<body>
<!--<php include('navfixed.php');?><br><br>-->
<?php include('navfixed.php');?>
<div class="container-fluid">
        <div class="row-fluid">
        
        <div class="span2">
            <div class="well sidebar-nav.hidden">
        <div class="form-wrapper">
    <div class="form-container">
        
<form action="generalsalesave.php" id="generalsalesave" method="post" >
<a class="active" style="float:left; width: 150px auto; height:30px; padding-top:9px; padding-bottom: 0px; margin: auto; font-size:20px; color:black;">General Product </a><br><br><br>
<input type="number" name="price" id="price" value="" min="0" placeholder="price" autocomplete="off" style="margin: 2 auto; width: 80px; height: 30px; padding-top: 0px; padding-bottom: 0px; font-size: 15px;"/>
<input type="number" name="qty" value="1" min="1" placeholder="Qty" autocomplete="off" style="margin: 2 auto; width: 80px; height: 30px; padding-top: 0px; padding-bottom: 0px; font-size: 15px;"/>
<input type="hidden" name="invoice" value="<?php echo $_GET['invoice']; ?>"  style="float:left; width: 123px; height:35px; margin-top:-5px;"readonly/><br>
<input type="hidden" value ="1" style="width:265px; height:30px;" name="product_code"/>
<input type="hidden" value ="1" style="width:265px; height:30px;" name="product"/>
<input type="hidden" value="0" min="0" style="width:265px; height:30px;" name="discount" />
<input type="hidden" name="date" value="<?php echo date('m/d/y H:i:s'); ?>" />
<input type="hidden" value ="General" style="width:265px; height:30px;" name="gen_name"/>
<input type="hidden" value ="General" style="width:265px; height:30px;" name="product_name"/>
<input type="hidden" value="0" min="0" style="width:265px; height:30px;" name="profit" readonly>
<Button type="submit" class="btn btn-info" style="margin: 2 auto; width: 95px; height: 30px; padding-top: 0px; padding-bottom: 0px; font-size: 15px;"
 id="general" /><i class="icon-plus-sign icon-large"></i> Add</button>
</form>




 </div>
</div>


         </div><!--/.well -->
         
<div style="margin-top: 20px;">
    <h4 style="font-weight: bold;">🔥 Most Sold Products</h4>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 15px;">
        <?php
        $bcode = $_SESSION['SESS_BCODE']; // Current branch code

        // Get most sold products for the current branch using join with sales table
        $stmt = $db->prepare("
            SELECT so.product, SUM(so.qty) as total_qty
            FROM sales_order so
            JOIN sales s ON so.invoice = s.invoice_number
            WHERE s.bcode = ?
            GROUP BY so.product
            ORDER BY total_qty DESC
            LIMIT 12
        ");
        $stmt->execute([$bcode]);
        $topProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($topProducts as $row) {
            $productCode = $row['product'];

            $productStmt = $db->prepare("SELECT product_code, gen_name, images FROM products WHERE product_code = ?");
            $productStmt->execute([$productCode]);
            $product = $productStmt->fetch(PDO::FETCH_ASSOC);

            if ($product) {
                $image = !empty($product['images']) && file_exists($product['images']) ? $product['images'] : 'images/pos.png';
                echo '
                
                <div class="breadcrumb" onclick="fillProductCode(\'' . htmlspecialchars($product['product_code'], ENT_QUOTES) . '\')" 
                     style="text-align: center; cursor: pointer; border: 1px solid #ccc; padding: 10px; border-radius: 8px;">
                    <img src="' . htmlspecialchars($image, ENT_QUOTES) . '" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px;">
                    <div style="font-size: 13px; margin-top: 5px;">' . htmlspecialchars($product['gen_name']) . '</div>
                </div>
                ';
            }
        }
        ?>
        <!--class="product-tile"-->
    </div>
</div>

<script>
// Fill product code into the input field and trigger event
function fillProductCode(code) {
    document.getElementById('product').value = code;
    $('#product').trigger('input'); // triggers price/image load logic
    $('#product').focus();
}
</script>

        </div><!--/span-->
        <!----------------------------------------------------------------------------------------------------------->
        
        
        
	<div class="span10">
	<div class="contentheader">
			<i class="icon-money"></i> Sales
			</div>
			<ul class="breadcrumb">
			<a href="index.php"><li>Dashboard</li></a> /
			<li class="active">Sales</li>
			</ul>
<div >
<a  href="index.php"><button class="btn btn-default btn-large" style="width: 123px; height:35px; margin-top: -5px; margin-bottom: 21px; loat: none;"><i class="icon icon-circle-arrow-left icon-large"></i> Back</button></a>



    <!-- Placeholder for Product Photo -->
<div id="productPhoto" style="float: right;">
        <img id="productImage" src="images/pos.png" style="max-width: 200px; max-height: 200px;">

</div>
</div>


<form action="incoming.php" id="incoming" method="post">
    <input type="hidden" name="purchases_item_id" id="purchases_item_id" value="">
    <input type="hidden" name="is_free" id="is_free" value="0">
    <input type="hidden" name="o_price" id="o_price" value=""> <!-- ✅ ADDED -->

   <select name="pt" id="paymentType" style="width:265px; height:30px;">
    <?php
    $result = $db->prepare("SELECT * FROM payment_type");
    $result->execute();
    while ($row = $result->fetch()) {
        $ptype = $row['ptype'];
        $selected = ($ptype === $selectedPayment) ? 'selected' : '';
        echo "<option value=\"$ptype\" $selected>$ptype</option>";
    }
    ?>
</select>


    <input type="text" name="invoice" value="<?php echo $invoiceNumber; ?>" readonly />
    <a href="qrsale.php?invoice=<?php echo $invoiceNumber; ?>" class="btn btn-info" style="width: 100px; height:20px; margin-top:-5px;">
        <i class="icon-plus-sign icon-large"></i> BAR / QR
    </a>
    <br>

    <input type="text" name="product" id="product" placeholder="Product Code"
           value="<?php echo isset($_GET['value']) ? $_GET['value'] : ''; ?>"
           style="width: 200px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />

    <input type="number" name="upprice" id="upprice" value="" placeholder="Price"
           style="width: 68px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />

    <input type="number" name="qty" value="1" min="1" placeholder="Qty" required
           style="width: 68px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />

    <input type="number" name="discount" value="" placeholder="Discount"
           style="width: 68px; height:30px; padding-top:6px; padding-bottom: 4px; margin-right: 4px; font-size:15px;" />

    <input type="hidden" name="date" value="<?php echo date('m/d/y H:i:s'); ?>" />

    <button type="submit" id="submitButton" class="btn btn-info"
            style="width: 123px; height:35px; margin-top:-5px;">
        <i class="icon-plus-sign icon-large"></i> Add
    </button>

    <button type="submit" class="btn btn-success" onclick="setFree()" 
            style="width: 123px; height:35px; margin-top:-5px; margin-left: 10px;">
        <i class="icon-check icon-large"></i> Free
    </button>
</form>





<div id="productPopup" class="well" style="display:none; position:fixed; top:20%; left:35%;  border:1px solid #ccc; padding:20px; z-index:9999; color: black;">
    <div class="form-container">
        <h4 style="text-align: center;">Select Product</h4>
        <table id="productOptionsTable" border="1" cellpadding="5">
            <thead>
                <tr><th>Price</th><th>Expiry Date</th><th>Action</th></tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>



<script>
$(document).ready(function () {
    $('#paymentType').on('change', function () {
        const selectedType = $(this).val();
        const invoice = '<?php echo $invoiceNumber; ?>';

        $.ajax({
            type: 'POST',
            url: 'save_payment_type.php',
            data: { pt: selectedType, invoice: invoice },
            success: function (response) {
                console.log("Payment type saved:", response);
            }
        });
    });
});
</script>





<script>
function setFree() {
    document.getElementById('is_free').value = '1';
}

// ✅ Load product image using product code
function loadProductImage(productCode) {
    $.ajax({
        type: "GET",
        url: "get_product_image.php",
        data: { productCode: productCode },
        dataType: "json",
        success: function (data) {
            if (data && data.images) {
                $("#productImage").attr("src", data.images);
            } else {
                $("#productImage").attr("src", "images/pos.png"); // fallback image
            }
        },
        error: function () {
            $("#productImage").attr("src", "images/pos.png"); // fallback on error
        }
    });
}

$(document).ready(function () {
    $("#product").on("input", function () {
        var productCode = $(this).val().trim();
        if (!productCode) return;

        // ✅ Load product image directly based on product code
        loadProductImage(productCode);

        // Optional: Your existing logic to check matching items
        $.ajax({
            type: "GET",
            url: "get_product_options.php",
            data: { productCode: productCode },
            dataType: "json",
            success: function (data) {
                if (data.length === 1) {
                    $("#upprice").val(data[0].price);
                    $("#o_price").val(data[0].o_price);
                    $("#purchases_item_id").val(data[0].id);
                    $("#productPopup").hide();
                } else if (data.length > 1) {
                    var tbody = $("#productOptionsTable tbody");
                    tbody.empty();

                    $.each(data, function (index, item) {
                        var row = `<tr>
                            <td>${item.price}</td>
                            <td>${item.exdate}</td>
                            <td><button type="button" class="selectProductBtn" 
                                        data-id="${item.id}" 
                                        data-price="${item.price}" 
                                        data-o_price="${item.o_price}">
                                Select</button></td>
                        </tr>`;
                        tbody.append(row);
                    });

                    $("#productPopup").show();
                } else {
                    $("#upprice").val("");
                    $("#o_price").val("");
                    $("#purchases_item_id").val("");
                }
            }
        });
    });

    $(document).on("click", ".selectProductBtn", function () {
        var selectedPrice = $(this).data("price");
        var selectedo_Price = $(this).data("o_price");
        var purchasesItemId = $(this).data("id");

        $("#upprice").val(selectedPrice);
        $("#o_price").val(selectedo_Price);
        $("#purchases_item_id").val(purchasesItemId);
        $("#productPopup").hide();
        
          // ✅ Focus and select the Qty field after closing popup
    setTimeout(function () {
        $('input[name="qty"]').focus().select();
    }, 200); // slight delay ensures the popup is hidden first
    });
});
</script>




<div class="row-fluid">

  <!-- Left: Sales Table -->
  <div class="span9">
<div class="table-responsive">
<table class="table table-bordered" id="resultTable">
	<thead>
		<tr>
			<th> Product Code </th>
			<th> Product Name </th>
			<!--<th> Description </th>-->
			<th> Price </th>
			<th> Qty </th>
			<th> Amount </th>
			<!--<th> Profit </th>-->
			<th> Discount </th>
			<th> Action </th>
		</tr>
	</thead>
	<tbody>
		
			<?php
				$id=$_GET['invoice'];
				include('../connect.php');
				$result = $db->prepare("SELECT * FROM sales_order WHERE invoice= :userid");
				$result->bindParam(':userid', $id);
				$result->execute();
				for($i=1; $row = $result->fetch(); $i++){
			?>
			<tr class="record">
			<td hidden><?php echo $row['product']; ?></td>
			<td><?php echo $row['product_code']; ?></td>
			<td><?php echo $row['gen_name']; ?></td>
			<!--<td><php echo $row['name']; ?></td>-->
			<td>
			<?php
			$ppp=$row['price'];
			echo formatMoney($ppp, true);
			?>
			</td>
			<td><?php echo $row['qty']; ?></td>
			<td>
			<?php
			$dfdf=$row['amount'];
			echo formatMoney($dfdf, true);
			?>
			</td>
			<!--<td>-->
			<?php
			$profit=$row['profit'];
// 			echo formatMoney($profit, true);
			?>
			<!--</td>-->
			
			<td>
			<?php
			$discount=$row['discount'];
			echo formatMoney($discount, true);
			?>
			</td>
			<td width="90"><a href="delete.php?id=<?php echo $row['transaction_id']; ?>
    &invoice=<?php echo $_GET['invoice']; ?>
    &dle=<?php echo $_GET['id']; ?>
    &qty=<?php echo $row['qty']; ?>
    &code=<?php echo $row['product']; ?>
    &purchase_item_id=<?php echo $row['purchases_item_id']; ?>"><button class="btn btn-mini btn-warning"><i class="icon icon-remove"></i> Cancel </button></a></td>
			</tr>
			<?php
				}
			?>
			<tr>
			<th> </th>
			<th>  </th>
			<th>  </th>
			<th>  </th>
			<!--<th>  </th>-->
			<td> Total Amount: </td>
			<!--<td> Total Profit: </td>-->
			<td> Total Discount: </td>
			<th>  </th>
		</tr>
			<tr>
				<th colspan="4"><strong style="font-size: 20px; color: #222222;">Total:</strong></th>
				<td colspan="1"><strong style="font-size: 20px; color: #222222;">
				<?php
				function formatMoney($number, $fractional=false) {
					if ($fractional) {
						$number = sprintf('%.2f', $number);
					}
					while (true) {
						$replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
						if ($replaced != $number) {
							$number = $replaced;
						} else {
							break;
						}
					}
					return $number;
				}
				$sdsd=$_GET['invoice'];
				$resultas = $db->prepare("SELECT sum(amount) FROM sales_order WHERE invoice= :a");
				$resultas->bindParam(':a', $sdsd);
				$resultas->execute();
				for($i=0; $rowas = $resultas->fetch(); $i++){
				$fgfg=$rowas['sum(amount)'];
				echo formatMoney($fgfg, true);
				}
				?>
				</strong></td>
				<!--<td colspan="1"><strong style="font-size: 12px; color: #222222;">-->
			<?php 
				$resulta = $db->prepare("SELECT sum(profit) FROM sales_order WHERE invoice= :b");
				$resulta->bindParam(':b', $sdsd);
				$resulta->execute();
				for($i=0; $qwe = $resulta->fetch(); $i++){
				$asd=$qwe['sum(profit)'];
				// echo formatMoney($asd, true);
				}
				?>
		
				<!--</td>-->
				
				<td colspan="1"><strong style="font-size: 20px; color: #222222;">
    <!-- Calculate and Display Total Discount -->
    <?php 
    $totalDiscount = 0; // Initialize total discount
    $sdsd=$_GET['invoice'];
    $resultas = $db->prepare("SELECT sum(amount), sum(price*qty) as total_price FROM sales_order WHERE invoice= :a");
    $resultas->bindParam(':a', $sdsd);
    $resultas->execute();
    $rowas = $resultas->fetch();
    $fgfg = $rowas['sum(amount)'];
    $totalPrice = $rowas['total_price'];
    $totalDiscount = $totalPrice - $fgfg; // Calculate total discount
    echo formatMoney($totalDiscount, true);
    ?>
    </strong></td>
				
				
				<th></th>
			</tr>
		
	</tbody>
</table>
</div><br>
<a rel="facebox" href="checkout.php?pt=<?php echo $_GET['id']?>&invoice=<?php echo $_GET['invoice']?>&total=<?php echo $fgfg ?>&totalprof=<?php echo $asd ?>&totalDiscount=<?php echo $totalDiscount ?>&cashier=<?php echo $_SESSION['SESS_FIRST_NAME']?>" ><button class="btn btn-success btn-large btn-block" id="checkout"><i class="icon icon-save icon-large"></i> Payment Process</button></a>
<br>
<br>







</div>





 <!-- Right: Number Pad -->
  <div class="span3">
    
    
    <div class="well" style="width: 100%; padding: 10px; margin-top: 20px;">
      <h5 style="text-align: center;">🧮 Number Pad</h5>
      <div class="row-fluid">
        <div class="span12" style="text-align: center;">
          <button class="btn num-btn">7</button>
          <button class="btn num-btn">8</button>
          <button class="btn num-btn">9</button><br>
          <button class="btn num-btn">4</button>
          <button class="btn num-btn">5</button>
          <button class="btn num-btn">6</button><br>
          <button class="btn num-btn">1</button>
          <button class="btn num-btn">2</button>
          <button class="btn num-btn">3</button><br>
          <button class="btn num-btn">0</button>
          <button class="btn num-btn">.</button>
          <button class="btn btn-danger num-btn" data-action="backspace">⌫</button><br>
          <button class="btn btn-warning num-btn" data-action="clear">C</button>
        </div>
      </div>
      <a rel="facebox" href="checkout.php?pt=<?php echo $_GET['id']?>&invoice=<?php echo $_GET['invoice']?>&total=<?php echo $fgfg ?>&totalprof=<?php echo $asd ?>&totalDiscount=<?php echo $totalDiscount ?>&cashier=<?php echo $_SESSION['SESS_FIRST_NAME']?>" ><button class="btn btn-success btn-large btn-block" id="checkout"><i class="icon icon-save icon-large"></i> Payment Process</button></a>

    </div><br><br>
    

    
    			    
		
			    <a style="color: white"> Esc  &nbsp;&nbsp; = &nbsp;&nbsp;  Product Code</a> <br>               
				<a style="color: white"> Shift&nbsp;&nbsp; =  &nbsp;&nbsp; Save</a>          <br>      
				<a style="color: white"> Ctrl &nbsp;&nbsp;&nbsp; = &nbsp;&nbsp;  General Product</a> <br>      
				<a style="color: white"> Enter &nbsp;=  &nbsp;&nbsp; Add Product</a>              <br>  
				<a style="color: white"> Tab  &nbsp;&nbsp;&nbsp; = &nbsp;&nbsp;  Navigate</a>                
    
  </div>

</div>





<script>

if (document.querySelector('.num-btn') && !window.opener) { 
  // init main page numpad only if buttons exist and NOT inside popup
  initNumpad();
}

function initNumpad() {
 
  let activeInput = null;

  document.addEventListener('focusin', function(e) {
    if (e.target.tagName === 'INPUT' && (e.target.type === 'text' || e.target.type === 'number')) {
      activeInput = e.target;
    }
  });

  document.querySelectorAll('.num-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      if (!activeInput) return;

      const action = btn.getAttribute('data-action');
      const value = btn.textContent;

      if (action === 'backspace') {
        activeInput.value = activeInput.value.slice(0, -1);
      } else if (action === 'clear') {
        activeInput.value = '';
      } else {
        activeInput.value += value;
      }

      const event = new Event('input', { bubbles: true });
      activeInput.dispatchEvent(event);
    });
  });
}
</script>





<style>
  .num-btn {
    width: 60px;
    margin: 4px;
    font-size: 18px;
    padding: 10px;
    text-align: center;
  }
</style>























	
			    
			 <!--   <a style="color: white"> &nbsp;&nbsp;&nbsp;Shortcuts</a>                <br><br>-->
		
			 <!--   <a style="color: white"> Esc  &nbsp;&nbsp; = &nbsp;&nbsp;  Product Code</a>                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
				<!--<a style="color: white"> Shift&nbsp;&nbsp; =  &nbsp;&nbsp; Save</a>          <br>      -->
				<!--<a style="color: white"> Ctrl &nbsp;&nbsp;&nbsp; = &nbsp;&nbsp;  General Product</a>       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
				<!--<a style="color: white"> Enter &nbsp;=  &nbsp;&nbsp; Add Product</a>              <br>  -->
				<!--<a style="color: white"> Tab  &nbsp;&nbsp;&nbsp; = &nbsp;&nbsp;  Navigate</a>                -->
				
				
				    


<!--------------------------------------->

<div class="clearfix"></div>
</div>


</div>
</div>


<script>
document.addEventListener("DOMContentLoaded", function () {
    const productInput = document.getElementById("product");
    if (productInput) {
        productInput.focus();
        productInput.select();
    }
});
</script>


</body>
<?php include('footer.php');?>
</html>