<html>
    
    <?php
date_default_timezone_set('Asia/Colombo');
?>


<head>
<title>Checkout</title>
<!--<script type="text/javascript" src="assets/js/jquery-1.3.2.js"></script>-->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script>
function suggest(inputString){
		if(inputString.length == 0) {
			$('#suggestions').fadeOut();
		} else {
		$('#country').addClass('load');
			$.post("autosuggestname.php", {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$('#suggestions').fadeIn();
					$('#suggestionsList').html(data);
					$('#country').removeClass('load');
				}
			});
		}
	}

	function fill(thisValue) {
		$('#country').val(thisValue);
		setTimeout("$('#suggestions').fadeOut();", 600);
	}

</script>

<style>
#result {
	height:20px;
	font-size:16px;
	font-family:Arial, Helvetica, sans-serif;
	color:#333;
	padding:5px;
	margin-bottom:10px;
	background-color:#FFFF99;
}
#country{
	border: 1px solid #999;
	background: #EEEEEE;
	padding: 5px 10px;
	box-shadow:0 1px 2px #ddd;
    -moz-box-shadow:0 1px 2px #ddd;
    -webkit-box-shadow:0 1px 2px #ddd;
}
.suggestionsBox {
	position: absolute;
	left: 10px;
	margin: 0;
	width: 268px;
	top: 40px;
	padding:0px;
	background-color: #000;
	color: #fff;
}
.suggestionList {
	margin: 0px;
	padding: 0px;
}
.suggestionList ul li {
	list-style:none;
	margin: 0px;
	padding: 6px;
	border-bottom:1px dotted #666;
	cursor: pointer;
}
.suggestionList ul li:hover {
	background-color: #FC3;
	color:#000;
}
ul {
	font-family:Arial, Helvetica, sans-serif;
	font-size:11px;
	color:#FFF;
	padding:0;
	margin:0;
}

.load{
background-image:url(loader.gif);
background-position:right;
background-repeat:no-repeat;
}

#suggest {
	position:relative;
}
.combopopup{
	padding:3px;
	width:268px;
	border:1px #CCC solid;
}
   	<?php
	$bcode=$_SESSION['SESS_BCODE'];
	?>
</style>	


 <script>
document.addEventListener('DOMContentLoaded', function() {
    // Check if the page was opened in a new tab
    if (performance.navigation.type === 1) {
        // Set focus to the Cash input field
        document.getElementById('cash').focus();
    }
});
</script>



</head>
<body onLoad="document.getElementById('country').focus();">
<form action="savesales.php" method="post" id="savesales">
<div id="ac">
<center><h4><i class="icon icon-money icon-large"></i> <?php echo $_GET['pt']; ?></h4></center><hr>
<input type="hidden" name="date" value="<?php echo date('m/d/y H:i:s'); ?>" />
<input type="hidden" name="invoice" value="<?php echo $_GET['invoice']; ?>" />
<input type="hidden" name="amount" value="<?php echo $_GET['total']; ?>" />
<input type="hidden" name="ptype" value="<?php echo $_GET['pt']; ?>" />
<input type="hidden" name="cashier" value="<?php echo $_GET['cashier']; ?>" />
<input type="hidden" name="profit" value="<?php echo $_GET['totalprof']; ?>" />
<input type="hidden" name="bcode" value="<?php echo $_GET['bcode']; ?>" />
<input type="hidden" name="totalDiscount" value="<?php echo $_GET['totalDiscount']; ?>" />

<center>
<!--<input type="text" size="25" value="Customer" name="cname" id="country" onkeyup="suggest(this.value);" onblur="fill();" class="" autocomplete="off" placeholder="Enter Customer Name" style="width: 268px; height:30px;" />-->
   

   
   
   
   
   <select name="cname" style="width:265px; height:30px;" >
	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM customer");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['customer_name']; ?></option>
	<?php
	}
	?>
</select><br>
<!--<label for="cash">Total: Rs. <?php echo $_GET['total']; ?></label>-->

      <div class="suggestionsBox" id="suggestions" style="display: none;">
        <div class="suggestionList" id="suggestionsList"> &nbsp; </div>
      </div>
      <br>
<?php
$asas=$_GET['pt'];
if($asas=='credit') {
?>Due Date: <br><input type="date" name="due" placeholder="Due Date" style="width: 268px; height:30px; margin-bottom: 15px;" /><br>
<!-- Display discount input field -->
<input type="number" name="discount_percentage" id="discount_percentage" value="" placeholder="Full Bil Discount Percentage (%)" min="0" max="100" step="0.01" style="width: 268px; height:30px; margin-bottom: 15px;" />

<?php
}
if($asas=='cash') {
?>
<!--<input type="number" name="cash" id="cash" placeholder="Cash" onfocus="this.select()" style="width: 268px; height:30px;  margin-bottom: 15px;" autofocus required/><br>-->


<input type="number" name="cash" id="cash" placeholder="Rs. <?php echo$_GET['total']; ?>" onfocus="this.select()" style="width: 268px; height:30px; margin-bottom: 15px;" autofocus required /><br>


<!-- Display discount input field -->
<input type="number" name="discount_percentage" id="discount_percentage" value="" placeholder="Full Bil Discount Percentage (%)" min="0" max="100" step="0.01" style="width: 268px; height:30px; margin-bottom: 15px;" />

<?php
}

if($asas=='cheques') {
?>
Due Date: <br><input type="date" name="due" placeholder="Due Date" style="width: 268px; height:30px; margin-bottom: 15px;" /><br>

<!-- Display discount input field -->
<input type="number" name="discount_percentage" id="discount_percentage" value="" placeholder="Full Bil Discount Percentage (%)" min="0" max="100" step="0.01" style="width: 268px; height:30px; margin-bottom: 15px;" />

<?php
}
?>


<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</center>
</div>
</form>



      <h5 style="text-align: center;">Number Pad</h5>
      <div class="row-fluid">
        <div class="span12" style="text-align: center;">
          <button class="btn num-btn">7</button>
          <button class="btn num-btn">8</button>
          <button class="btn num-btn">9</button><br>
          <button class="btn num-btn">4</button>
          <button class="btn num-btn">5</button>
          <button class="btn num-btn">6</button><br>
          <button class="btn num-btn">1</button>
          <button class="btn num-btn">2</button>
          <button class="btn num-btn">3</button><br>
          <button class="btn num-btn">0</button>
          <button class="btn num-btn">.</button>
          <button class="btn btn-danger num-btn" data-action="backspace">âŒ«</button><br>
          <button class="btn btn-warning num-btn" data-action="clear">C</button>
        </div>
      </div>
   






<script>

if (document.querySelector('.num-btn')) {
  initPopupNumpad();
}

function initPopupNumpad() {
  let activeInput = null;

  document.addEventListener('focusin', function(e) {
    if (e.target.tagName === 'INPUT' && (e.target.type === 'text' || e.target.type === 'number')) {
      activeInput = e.target;
    }
  });

  document.querySelectorAll('.num-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      if (!activeInput) return;

      const action = btn.getAttribute('data-action');
      const value = btn.textContent;

      if (action === 'backspace') {
        activeInput.value = activeInput.value.slice(0, -1);
      } else if (action === 'clear') {
        activeInput.value = '';
      } else {
        activeInput.value += value;
      }

      const event = new Event('input', { bubbles: true });
      activeInput.dispatchEvent(event);
    });
  });
}
</script>





<style>
  .num-btn {
    width: 60px;
    margin: 4px;
    font-size: 18px;
    padding: 10px;
    text-align: center;
  }
</style>



</body>
</html>