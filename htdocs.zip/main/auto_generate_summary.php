<?php
include('/home/ebuddylk/public_html/Demo/POS/connect.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


date_default_timezone_set('Asia/Colombo');
$today = date('Y-m-d'); // e.g., 2025-06-19

// Fetch all distinct branch codes from sales table
$branchStmt = $db->query("SELECT DISTINCT bcode FROM sales");

while ($row = $branchStmt->fetch(PDO::FETCH_ASSOC)) {
    $bcode = $row['bcode'];

    // Get overall sales summary for this branch
    $stmt = $db->prepare("
        SELECT 
            SUM(amount) AS total_sales,
            SUM(profit) AS total_profit,
            SUM(discountamount) AS total_discount,
            SUM(balance) AS total_balance,
            COUNT(*) AS total_transactions
        FROM sales
        WHERE STR_TO_DATE(date, '%m/%d/%y') = ? AND bcode = ?
    ");
    $stmt->execute([$today, $bcode]);
    $summary = $stmt->fetch(PDO::FETCH_ASSOC);
    
    
    
    // Get today's invoice numbers from already filtered sales
$invoiceStmt = $db->prepare("SELECT invoice_number FROM sales WHERE STR_TO_DATE(date, '%m/%d/%y') = ?");
$invoiceStmt->execute([$today]);
$invoices = $invoiceStmt->fetchAll(PDO::FETCH_COLUMN);

// Calculate total item-wise discount from sales_order
$item_discount_total = 0;
if (!empty($invoices)) {
    $placeholders = implode(',', array_fill(0, count($invoices), '?'));
    $discountQuery = "SELECT SUM(discount) FROM sales_order WHERE invoice IN ($placeholders)";
    $discountStmt = $db->prepare($discountQuery);
    $discountStmt->execute($invoices);
    $item_discount_total = $discountStmt->fetchColumn() ?? 0;
}

    
    

    // Totals & counts by payment type
    $types = ['cash', 'credit', 'cheques'];
    $typeTotals = [];
    $typeCounts = [];

    foreach ($types as $type) {
        $qt = $db->prepare("SELECT SUM(amount) FROM sales WHERE STR_TO_DATE(date, '%m/%d/%y') = ? AND type = ? AND bcode = ?");
        $qt->execute([$today, $type, $bcode]);
        $typeTotals[$type] = $qt->fetchColumn() ?? 0;

        $qc = $db->prepare("SELECT COUNT(*) FROM sales WHERE STR_TO_DATE(date, '%m/%d/%y') = ? AND type = ? AND bcode = ?");
        $qc->execute([$today, $type, $bcode]);
        $typeCounts[$type] = $qc->fetchColumn() ?? 0;
    }

    // Check if today's summary already exists for this branch
    $check = $db->prepare("SELECT COUNT(*) FROM dailysales WHERE sale_date = ? AND bcode = ?");
    $check->execute([$today, $bcode]);
    $count = $check->fetchColumn();

    if ($count > 0) {
        // Update existing summary
        $update = $db->prepare("
            UPDATE dailysales SET 
                total_sales = ?, 
                total_profit = ?, 
                total_discount = ?, 
                total_item_discount = ?,
                total_balance = ?, 
                total_transactions = ?, 
                cash_total = ?, 
                credit_total = ?, 
                cheque_total = ?, 
                cash_count = ?, 
                credit_count = ?, 
                cheque_count = ?,
                last_updated = NOW()
            WHERE sale_date = ? AND bcode = ?
        ");
        $update->execute([
            $summary['total_sales'] ?? 0,
            $summary['total_profit'] ?? 0,
            $summary['total_discount'] ?? 0,
            $item_discount_total,
            $summary['total_balance'] ?? 0,
            $summary['total_transactions'] ?? 0,
            $typeTotals['cash'],
            $typeTotals['credit'],
            $typeTotals['cheques'],
            $typeCounts['cash'],
            $typeCounts['credit'],
            $typeCounts['cheques'],
            $today,
            $bcode
        ]);
    } else {
        // Insert new summary
        $insert = $db->prepare("
            INSERT INTO dailysales (
                sale_date, bcode, total_sales, total_profit, total_discount, total_item_discount, total_balance,
                total_transactions, cash_total, credit_total, cheque_total,
                cash_count, credit_count, cheque_count, last_updated
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $insert->execute([
            $today,
            $bcode,
            $summary['total_sales'] ?? 0,
            $summary['total_profit'] ?? 0,
            $summary['total_discount'] ?? 0,
            $item_discount_total,
            $summary['total_balance'] ?? 0,
            $summary['total_transactions'] ?? 0,
            $typeTotals['cash'],
            $typeTotals['credit'],
            $typeTotals['cheques'],
            $typeCounts['cash'],
            $typeCounts['credit'],
            $typeCounts['cheques']
        ]);
    }
    file_put_contents('/home/ebuddylk/cron_success.log', "Cron executed on: " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

}
