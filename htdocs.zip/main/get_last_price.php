<?php
include('../connect.php');

$productCode = $_GET['product_code'] ?? '';

if (!empty($productCode)) {
    $stmt = $db->prepare("SELECT o_price, price, qty FROM purchases_item WHERE product_code = :code ORDER BY id DESC LIMIT 1");
    $stmt->bindParam(':code', $productCode);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        echo json_encode([
            'o_price' => $row['o_price'],
            'price' => $row['price'],
            'qty' => $row['qty']
        ]);
    } else {
        echo json_encode(null);
    }
} else {
    echo json_encode(null);
}
