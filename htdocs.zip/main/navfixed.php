<?php
include('../connect.php');

$result = $db->prepare("SELECT * FROM company ORDER BY companyid DESC");
$result->execute();

if ($row = $result->fetch()) {
    $companyName = $row['companyname'];
    $companyPhone = $row['companyphone'];
}
?>

<!-- Include Bootstrap CSS & JS properly (outside script) -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>

<div class="navbar navbar-inverse navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container-fluid">
      <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <a class="brand" href="#"><b><?php echo $companyName; ?></b> - POS</a>

      <div class="nav-collapse collapse">
        <ul class="nav pull-right">
          <li><a><i class="icon-user icon-large"></i> Welcome: <strong><?php echo $_SESSION['SESS_FIRST_NAME'];?></strong></a></li>
          <li><a><i class="icon-user icon-large"></i> Branch: <strong><?php echo $_SESSION['SESS_BCODE'];?></strong></a></li>
          <li><a><i class="icon-calendar icon-large"></i>
              <?php
              date_default_timezone_set('Asia/Colombo');
              echo date('l, F d, Y');
              ?>
          </a></li>
          <li>
            <div class="hero-unit-clock">
              <form name="clock">
                <font color="white">Time:</font>&nbsp;
                <!-- Change type submit to text, readonly so JS can update -->
                <input type="text" name="face" readonly
                       style="width:150px; background: none; margin-top: 8px; color: white; border: none;font-size: 16px;"/>
              </form>
            </div>
          </li>
          <li><a href="../index.php"><font color="red"><i class="icon-off icon-large"></i></font> Log Out</a></li>
          <li>
            <a>
              <strong>
                <?php echo '<img src="'.$_SESSION['SESS_IMAGES'].'" alt="" style="width:50px; border:none;">'; ?>
              </strong>
            </a>
          </li>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </div>
</div><br>

<script>
// Clock JS — place after HTML form so it can access the elements
var timerID = null;
var timerRunning = false;

function stopclock() {
  if (timerRunning)
    clearTimeout(timerID);
  timerRunning = false;
}

function showtime() {
  var now = new Date();
  var hours = now.getHours();
  var minutes = now.getMinutes();
  var seconds = now.getSeconds();

  var timeValue = ((hours > 12) ? hours - 12 : hours);
  if (timeValue == 0) timeValue = 12;
  timeValue += ((minutes < 10) ? ":0" : ":") + minutes;
  timeValue += ((seconds < 10) ? ":0" : ":") + seconds;
  timeValue += (hours >= 12) ? " P.M." : " A.M.";

  // Update input value
  document.clock.face.value = timeValue;

  timerID = setTimeout(showtime, 1000);
  timerRunning = true;
}

function startclock() {
  stopclock();
  showtime();
}

window.onload = startclock;
</script>
