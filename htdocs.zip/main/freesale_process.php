<?php
include('../connect.php');
$code = $_GET['product_code'] ?? '';
$bcode = $_SESSION['SESS_BCODE'];

$stmt = $db->prepare("
    SELECT pi.id, pi.exdate, pi.price 
    FROM purchases_item pi 
    JOIN purchases p ON pi.invoice = p.invoice_number 
    WHERE pi.product_code = :code AND p.bcode = :bcode AND pi.qty > 0
");
$stmt->execute([':code' => $code, ':bcode' => $bcode]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($rows);
?>
