<?php
session_start();
include('../connect.php');
$a = $_POST['invoice'];
$b = $_POST['cashier'];
$c = $_POST['date'];
$d = $_POST['ptype'];
$e = $_POST['amount'];
$z = $_POST['profit'];
$i = $_POST['totalDiscount'];
$h = $_POST['discountamount'];
$cname = $_POST['cname'];
$user_id = $_POST['user_id'];

$bcode=$_SESSION['SESS_BCODE'];


$discount_percentage = isset($_POST['discount_percentage']) ? floatval($_POST['discount_percentage']) : 0;

// Calculate the discounted amount based on the discount percentage
$discount_amount = ($discount_percentage / 100) * $e;

// Calculate the final total after applying the discount
$total_with_discount = $e - $discount_amount;




if($d=='cheques') {
$f = $_POST['due'];
$sql = "INSERT INTO sales (invoice_number,cashier,date,type,amount,profit,due_date,name,bcode,discountamount,fulldiscount,user_id) VALUES (:a,:b,:c,:d,:e,:z,:f,:g,:bcode,:h,:j,:k)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':z'=>$z,':f'=>$f,':g'=>$cname,':bcode'=>$bcode,':h'=>$discount_amount,':j'=>$j,':k'=>$user_id));
header("location: preview.php?invoice=$a");
exit();
}


if($d=='credit') {
$f = $_POST['due'];
$sql = "INSERT INTO sales (invoice_number,cashier,date,type,amount,profit,due_date,name,bcode,discountamount,fulldiscount,user_id) VALUES (:a,:b,:c,:d,:e,:z,:f,:g,:bcode,:h,:j,:k)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':z'=>$z,':f'=>$f,':g'=>$cname,':bcode'=>$bcode,':h'=>$discount_amount,':j'=>$j,':k'=>$user_id));
header("location: preview.php?invoice=$a");
exit();
}


if($d=='cash') {
$f = $_POST[''];
$k = $_POST['cash'];
$j = $discount_amount + $i ;
$balance = $k - $total_with_discount;
$sql = "INSERT INTO sales (invoice_number,cashier,date,type,amount,profit,due_date,cash,name,bcode,discountamount,fulldiscount,balance, user_id) VALUES (:a,:b,:c,:d,:e,:z,:f,:k,:g,:bcode,:h,:j,:balance,:i)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':z'=>$z,':f'=>$f,':k'=>$k,':g'=>$cname,':bcode'=>$bcode,':h'=>$discount_amount,':j'=>$j,':balance'=>$balance,':i'=>$user_id));
header("location: preview.php?invoice=$a");
exit();
}
// query



?>