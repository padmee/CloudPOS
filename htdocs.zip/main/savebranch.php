<?php
session_start();
include('../connect.php');

// Sanitize inputs
$a = trim($_POST['bcode']);
$b = trim($_POST['bname']);
$c = trim($_POST['baddress']);
$d = trim($_POST['bphone']);

if (empty($a) || empty($b) || empty($d)) {
    echo "<script>alert('Branch code, name and phone are required.'); history.back();</script>";
    exit;
}

// Check for duplicate branch code
$check = $db->prepare("SELECT COUNT(*) FROM branch WHERE bcode = ?");
$check->execute([$a]);
if ($check->fetchColumn() > 0) {
    echo "<script>alert('Branch code already exists'); history.back();</script>";
    exit;
}

// File upload
$fileTarget = "";
if (!empty($_FILES['filename']['name'])) {
    $fileName = basename($_FILES['filename']['name']);
    $targetDir = "images/branches/";
    $fileTarget = $targetDir . $fileName;
    $tempFileName = $_FILES["filename"]["tmp_name"];

    $check = getimagesize($tempFileName);
    if ($check !== false) {
        if (!move_uploaded_file($tempFileName, $fileTarget)) {
            echo "<script>alert('Failed to upload image'); history.back();</script>";
            exit;
        }
    } else {
        echo "<script>alert('Selected file is not an image'); history.back();</script>";
        exit;
    }
}

// Save to DB
$sql = "INSERT INTO branch (bcode, bname, baddress, bphone, images) 
        VALUES (:a, :b, :c, :d, :fileTarget)";
$q = $db->prepare($sql);
$q->execute([
    ':a' => $a,
    ':b' => $b,
    ':c' => $c,
    ':d' => $d,
    ':fileTarget' => $fileTarget
]);

header("Location: branchview.php");
exit;
?>
