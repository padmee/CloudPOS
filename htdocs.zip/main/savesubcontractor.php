<?php
session_start();
include('../connect.php');
$a = $_POST['subcontractor_name'];
$b = $_POST['subcontractor_address'];
$c = $_POST['subcontractor_contact'];
$d = $_POST['contact_person'];
$e = $_POST['note'];
$f = $_POST['mode'];
// query
$sql = "INSERT INTO subcontractor (subcontractor_name,subcontractor_address,subcontractor_contact,contact_person,note,mode) VALUES (:a,:b,:c,:d,:e,:f)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':f'=>$f));
header("location: subcontractor.php");


?>