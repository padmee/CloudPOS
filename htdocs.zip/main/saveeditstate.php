<?php
// configuration
include('../connect.php');

// new data




$id = $_POST['memi'];
$a = $_POST['state'];

$k = $_POST['bcode'];



// query
$sql = "UPDATE state 
        SET  state=?
		WHERE state_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$id));
header("location: state.php");

?>