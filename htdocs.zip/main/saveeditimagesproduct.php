<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['memi'];
$a = $_POST['images'];

// query
$sql = "UPDATE products 
        SET images=?
		WHERE product_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$id));
header("location: products.php");

?>