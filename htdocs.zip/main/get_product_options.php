<?php
include('../connect.php');

$productCode = $_GET['productCode'];

$stmt = $db->prepare("SELECT id, price, o_price, exdate FROM purchases_item WHERE product_code = ? AND qty > 0");
$stmt->execute([$productCode]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($results);
?>
