<?php
include('../connect.php');

$product_code = $_GET['product_code'];

$result = $db->prepare("SELECT * FROM products WHERE product_code = :product_code");
$result->bindParam(':product_code', $product_code);
$result->execute();

$product_data = $result->fetch(PDO::FETCH_ASSOC);

echo json_encode($product_data);
?>
