<?php
	include('../connect.php');
	$id=$_GET['subcontractor_id'];
	$result = $db->prepare("SELECT * FROM subcontractor WHERE subcontractor_id= : subcontractor_id");
	$result->bindParam(':subcontractor_id', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>


<form action="saveeditsubcontractor.php" method="post">
<center><h4><i class="icon-edit icon-large"></i> Edit Subcontractor</h4></center><hr>
<div id="ac">
<input type="hidden" name="memi" value="<?php echo $subcontractor_id; ?>" />
<span>Subcontractor Name : </span><input type="text" style="width:265px; height:30px;" name="name" value="<?php echo $row['subcontractor_name']; ?>" /><br>
<span>Address : </span><input type="text" style="width:265px; height:30px;" name="address" value="<?php echo $row['subcontractor_address']; ?>" /><br>
<span>Contact Person : </span><input type="text" style="width:265px; height:30px;" name="cperson" value="<?php echo $row['contact_person']; ?>" /><br>
<span>Contact No.: </span><input type="text" style="width:265px; height:30px;" name="contact" value="<?php echo $row['subcontractor_contact']; ?>" /><br>
<span>Note : </span><textarea style="width:265px; height:80px;" name="note"><?php echo $row['note']; ?></textarea><br>
<div style="float:right; margin-right:10px;">

<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save Changes</button>
</div>
</div>
</form>
<?php
}
?>