

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>
   
   <link rel="shortcut icon" href="main/images/pos.jpg">

  <link href="main/css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="main/css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="main/css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 70px;
        padding-bottom: 50px;
      }
      .sidebar-nav {
        padding: 10px 0;
      }
    </style>
    <link href="main/css/bootstrap-responsive.css" rel="stylesheet">

<link href="style.css" media="screen" rel="stylesheet" type="text/css" />

   <!-- font awesome cdn link  -->
   <!--<link rel="stylesheet" href="assets/css/fontawesome-6.0.0-all.min.css">-->

   <!-- custom css file link  -->
   <!--<link rel="stylesheet" href="main/css/style.css">-->

</head>
<body>

<div class="container-fluid">
      <div class="row-fluid">
		<div class="span4">
		</div>
	
</div>
<div id="branch">


<form action="main/branch.php" method="post">

			<font style=" font:bold 30px 'Aleo'; text-shadow:1px 1px 15px #000; color:#fff;"><center>Branch Registration</center></font>
		<br>

<div class="input-prepend">
		<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="text" name="bcode" Placeholder="Enter Branch Code" required/><br>
</div>
<div class="input-prepend">
		<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="text" name="bname" Placeholder="Enter Branch name" required/><br>
</div>
<div class="input-prepend">
		<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="text" name="baddress" Placeholder="Enter Branch Address" required/><br>
</div>
<div class="input-prepend">
		<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="text" name="bphone" Placeholder="Enter Branch Phone Number" required/><br>
</div>


<span class="" id='message'></span>
<br>

<div class="qwe">
	<button class="btn btn-large btn-primary btn-block pull-right" href="dashboard.html" type="submit"><i class="icon-signin icon-large"></i> Create Branch </button><br><br>
		 <!--<br> <a href="register.php">Create a new account...</a>-->
</div>
		 </form>


</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<font style=" font:80px 'Aleo'; text-shadow:1px 1px 15px #000; color:#fff;"><center>Buddy Technical Solution</center></font>
		<br>




<script src="assets/js/jquery-2.1.1.min.js"></script>

</body>
</html>