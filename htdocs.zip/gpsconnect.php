<?php 
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'ebuddylk_gpsdata'); 
define('DB_PASSWORD', 'Nadeera.40581772'); 
define('DB_NAME', 'ebuddylk_gpsdata');

date_default_timezone_set('Asia/Colombo');


// Connect with the database 
$db = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME); 
 
// Display error if failed to connect 
if ($db->connect_errno) { 
    echo "Connection to database is failed: ".$db->connect_error;
    exit();
}