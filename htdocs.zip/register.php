

<!DOCTYPE html>
<html lang="en">
<head>
    
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>
   
   <link rel="shortcut icon" href="main/images/pos.jpg">

  <link href="main/css/bootstrap.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="main/css/DT_bootstrap.css">
  
  <link rel="stylesheet" href="main/css/font-awesome.min.css">
    <style type="text/css">
      body {
        padding-top: 70px;
        padding-bottom: 50px;
      }
      .sidebar-nav {
        padding: 10px 0;
      }
    </style>
    <link href="main/css/bootstrap-responsive.css" rel="stylesheet">

<link href="style.css" media="screen" rel="stylesheet" type="text/css" />

   <!-- font awesome cdn link  -->
   <!--<link rel="stylesheet" href="assets/css/fontawesome-6.0.0-all.min.css">-->

   <!-- custom css file link  -->
   <!--<link rel="stylesheet" href="main/css/style.css">-->

</head>
<body>

<div class="container-fluid">
      <div class="row-fluid">
		<div class="span4">
		</div>
	
</div>
<div id="register">
    


<form action="main/register.php" method="post">

			<font style=" font:bold 30px 'Aleo'; text-shadow:1px 1px 15px #000; color:#fff;"><center>User Registration</center></font>
		<br>

		
<div class="input-prepend">
		<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="text" name="name" Placeholder="enter your name" required/><br>
</div>
<div class="input-prepend">
		<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span><input style="height:40px;" type="email" name="email" Placeholder="enter your email" required/><br>
</div>

<div class="input-prepend">
	<span style="height:30px; width:25px;" class="add-on"><i class="icon-lock icon-2x"></i></span><input type="password" style="height:40px;" id="password" name="password" Placeholder="enter your password" title="Eight or more characters" required/><br>
</div>
<div class="input-prepend">
	<span style="height:30px; width:25px;" class="add-on"><i class="icon-lock icon-2x"></i></span><input type="password" style="height:40px;" id="cpassword" name="cpassword" Placeholder="confirm your password" title="Eight or more characters" required/><br>
</div>






<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span>
    <select name="type" class="form-select" aria-label="Position" required>
        <option></option>
         <option value="admin">Admin</option>
         <option value="cashiyer">Cashiyer</option>
         <option value="grn">GRN Editor</option>
         <option value="production">Production</option>
    </select>
    
    

<br>


<span style="height:30px; width:25px;" class="add-on"><i class="icon-user icon-2x"></i></span>
<select name="bcode" class="form-select"  Required>
<option></option>
	<?php
	include('connect.php');
	$result = $db->prepare("SELECT * FROM branch WHERE bcode");
		$result->bindParam(':bcode', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['bcode']; ?></option>
	<?php
	}
	?>
</select><br> 










   

<span class="" id='message'></span>
<br>

<div class="qwe">
	<button class="btn btn-large btn-primary btn-block pull-right" href="dashboard.html" type="submit"><i class="icon-signin icon-large"></i> Register </button><br><br>
		 <!--<br> <a href="register.php">Create a new account...</a>-->
</div>
		 </form>


</div>


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<font style=" font:80px 'Aleo'; text-shadow:1px 1px 15px #000; color:#fff;"><center>Buddy Technical Solution</center></font>
		<br>


   <!-- register form -->
<!--<div class="form-container">-->

<!--   <form action="main/register.php" method="post">-->
<!--      <h3>register here</h3>-->
<!--      <input type="text" name="name" placeholder="enter your name" required class="box">-->
<!--      <input type="email" name="email" placeholder="enter your email" required class="box">-->
<!--      <input type="password"  id="password" name="password" placeholder="enter your password"  title="Eight or more characters" required class="box">-->
<!--      <input type="password"  id="cpassword" name="cpassword" placeholder="confirm your password"  title="Eight or more characters" required class="box">-->
<!--      <select name="type" class="box">-->
<!--          <option value="admin">Admin</option>-->
<!--         <option value="cashiyer">Cashiyer</option>-->
<!--         <option value="production">Production</option>-->
<!--      </select>-->
<!--      <span class="" id='message'></span>-->
<!--      <div style="width:100%;"></div>-->
<!--      <input type="submit" name="submit" value="sign up" class="btn">-->
<!--      <p>already have an account? <a href="login.php">login now</a></p>-->
<!--   </form>-->

<!--</div>-->



<script src="assets/js/jquery-2.1.1.min.js"></script>

<script>
    $('#password, #cpassword').on('keyup', function () {
    if ($('#password').val() == $('#cpassword').val()) {
        $('#message').html('').css('color', 'green');
    } else 
        $('#message').html('Not Matching').css('color', 'red');
    });

    $('form').on('submit',function(){
        if($(this).find('input[name="password"]').val() != $(this).find('input[name="cpassword"]').val()){
            // show error
            return false;
        }
    });
</script>

</body>
</html>