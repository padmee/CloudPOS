# Requires: PowerShell 5+ and Internet connectivity for the one-time setup
$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $PSScriptRoot
New-Item -ItemType Directory -Force -Path "assets/css" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" -OutFile "assets/css/bootstrap-3.4.1.min.css"
New-Item -ItemType Directory -Force -Path "assets/css" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" -OutFile "assets/css/fontawesome-6.0.0-all.min.css"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/3.3.3/adapter.min.js" -OutFile "assets/js/adapter-3.3.3.min.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" -OutFile "assets/js/bootstrap-3.4.1.min.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.4/html5-qrcode.min.js" -OutFile "assets/js/html5-qrcode-2.3.4.min.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://raw.githubusercontent.com/schmich/instascan-builds/master/instascan.min.js" -OutFile "assets/js/instascan.min.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" -OutFile "assets/js/jquery-1.3.2.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js" -OutFile "assets/js/jquery-2.1.1.min.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://code.jquery.com/jquery-3.6.0.min.js" -OutFile "assets/js/jquery-3.6.0.min.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://code.jquery.com/jquery-3.7.1.js" -OutFile "assets/js/jquery-3.7.1.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://code.jquery.com/jquery-3.7.1.min.js" -OutFile "assets/js/jquery-3.7.1.min.js"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://www.softcomplex.com/products/tigra_calendar/" -OutFile "assets/js/tigra_calendar_placeholder.txt"
New-Item -ItemType Directory -Force -Path "assets/js" | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri "https://cdnjs.cloudflare.com/ajax/libs/vue/2.1.10/vue.min.js" -OutFile "assets/js/vue-2.1.10.min.js"
