-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 03, 2023 at 11:12 PM
-- Server version: 8.0.32
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ebuddylk_sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int NOT NULL,
  `bcode` varchar(10) DEFAULT NULL,
  `bname` text,
  `baddress` text,
  `bphone` int DEFAULT NULL,
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `bcode`, `bname`, `baddress`, `bphone`, `images`) VALUES
(1, '101', 'kirindiwela', 'nawetiya 321 ffffffffff', 711461785, ''),
(2, '523', 'Gampaha', 'Gampaha kirindiwela', 1234567895, ''),
(4, '222', '222', ' 2222', 222222222, 'images/63810-anonymus-hacker-computer.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE `collection` (
  `transaction_id` int NOT NULL,
  `date` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `invoice` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `amount` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `remarks` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `balance` int DEFAULT NULL,
  `payment` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collection`
--

INSERT INTO `collection` (`transaction_id`, `date`, `name`, `invoice`, `amount`, `remarks`, `balance`, `payment`) VALUES
(38, '08/01/2023', 'Padmashan Nadeera', 'IN-090223', '500', '500', -500, 0),
(39, '08/02/2023', 'Customer', 'IN-333609', '500', '500', -500, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `colour`
--

CREATE TABLE `colour` (
  `colour_id` int NOT NULL,
  `colour_code` int DEFAULT NULL,
  `colour` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `colour`
--

INSERT INTO `colour` (`colour_id`, `colour_code`, `colour`) VALUES
(1, 1, 'red'),
(2, 2, 'Brown');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int NOT NULL,
  `customer_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `address` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `contact` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `membership_number` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `prod_name` varchar(550) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `expected_date` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `note` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `address`, `contact`, `membership_number`, `prod_name`, `expected_date`, `note`) VALUES
(15, 'Customer', '', '', '', '', '', ''),
(16, 'Padmashan Nadeera', '27 U 1/12, Nugahena waththa', '0711461785', '5000', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `file_name`, `uploaded_on`) VALUES
(1, 'Crystal-smart-home-security-system-scaled.jpeg', '2023-04-05 13:12:40'),
(2, 'Home-security-cameras-Wireless-and-other-CCTV-cameras’-guide-and-installation-tips-FB-1200x700-compressed.jpg', '2023-04-05 13:14:20'),
(3, '-iStockchinaface-525038035-696x392.jpg', '2023-04-05 13:35:13'),
(4, 'OU-MSEE-Six-Essential-Terms-in-Computer-Networking.jpg', '2023-04-05 13:35:40'),
(5, 'computer-programming.jpg', '2023-04-05 13:36:49'),
(6, '1779916.jpg', '2023-04-05 16:25:52');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mode`
--

CREATE TABLE `mode` (
  `mode` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `mode_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `mode`
--

INSERT INTO `mode` (`mode`, `mode_id`) VALUES
('Line', 1),
('Sub', 2);

-- --------------------------------------------------------

--
-- Table structure for table `payment_type`
--

CREATE TABLE `payment_type` (
  `id` int NOT NULL,
  `ptype` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payment_type`
--

INSERT INTO `payment_type` (`id`, `ptype`) VALUES
(1, 'cash'),
(2, 'credit'),
(3, 'cheques');

-- --------------------------------------------------------

--
-- Table structure for table `production`
--

CREATE TABLE `production` (
  `production_id` int NOT NULL,
  `design_no` int DEFAULT NULL,
  `date` date DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `mode` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `colour_code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `target_date` date DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `subcontractor_name` text,
  `images` text,
  `bcode` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `production`
--

INSERT INTO `production` (`production_id`, `design_no`, `date`, `qty`, `mode`, `colour_code`, `target_date`, `state`, `subcontractor_name`, `images`, `bcode`) VALUES
(22, 88, '2023-07-13', 100, 'Line', '1', '2023-07-28', 'Cut', 'anja', 'images/', NULL),
(23, 55, '2023-07-04', 100, 'Sub', '', '2023-08-15', 'Sawing', 'anja', 'images/High_resolution_wallpaper_background_ID_77701546174.jpg', NULL),
(24, 44, '2023-07-03', 300, 'Line', 'zzzzzzzz', '2023-07-26', 'Sawing', 'anja', 'images/glass-windows-10-on-square-pattern-46560-3840x2160', NULL),
(25, 1, '2023-07-05', 100, 'Line', 'zzzzzzzz', '2023-07-27', 'Sawing', 'anja', 'images/', NULL),
(26, 1, '2023-06-28', 100, 'Sub', 'zzzzzzzz', '2023-07-04', 'Cut', 'anja', 'images/', NULL),
(27, 88, '2023-06-29', 300, 'Line', 'zzzzzzzz', '2023-07-26', 'Sawing', 'anja', NULL, NULL),
(28, 55, '2023-07-20', 100, 'Line', 'zzzzzzzz', '2023-06-28', 'Sawing', 'kkkkkkk', 'images/', 101);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int NOT NULL,
  `product_code` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `images` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `file` varchar(500) DEFAULT NULL,
  `gen_name` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `product_name` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `cost` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `o_price` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `price` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `profit` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `supplier` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `onhand_qty` int DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `expiry_date` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `date` varchar(500) DEFAULT NULL,
  `bcode` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `images`, `file`, `gen_name`, `product_name`, `cost`, `o_price`, `price`, `profit`, `supplier`, `onhand_qty`, `qty`, `expiry_date`, `date`, `bcode`) VALUES
(1, 'Promate', 'images/922453.jpg', NULL, 'aaaaaaaaaa', ' ', NULL, '95', '100', '5', 'printXcel', NULL, 112, '', '2023-06-27', 101),
(2, 'rathna 500', 'images/High_resolution_wallpaper_background_ID_77701546174.jpg', NULL, 'aaaaaaaaaa', '  egtregte4rw', NULL, '95', '100', '5', 'printXcel', NULL, 114, '', '2023-07-10', 101),
(3, 'Mango', 'images/63810-anonymus-hacker-computer.jpg', NULL, 'A4', ' rweferfw', NULL, '95', '100', '5', 'General', NULL, 165, '', '2023-06-26', 105),
(8, '4792066002802111111', 'images/63810-anonymus-hacker-computer.jpg', NULL, 'A4', ' ', NULL, '95', '100', '5', 'printXcel', NULL, 271, '2023-07-18', '2023-06-27', 101),
(9, 'asasasasasas', 'images/glass-windows-10-on-square-pattern-46560-3840x2160.jpg', NULL, 'asasasasa', ' sasasasa', NULL, '95', '100', '5', 'Atles', NULL, 100, '2023-07-20', '2023-06-27', NULL),
(10, '4792066002802111', 'images/glass-windows-10-on-square-pattern-46560-3840x2160.jpg', NULL, 'dddddddddddd', ' tyerrrrrrrr', NULL, '95', '100', '5', 'printXcel', NULL, 100, '2023-07-26', '2023-06-27', NULL),
(11, '4792066002802111111', 'images/glass-windows-10-on-square-pattern-46560-3840x2160.jpg', NULL, 'aaaaaaaaaa', ' ', NULL, '95', '100', '5', 'printXcel', NULL, 436, '2023-07-28', '2023-06-26', NULL),
(12, '4792066002802111111', 'images/', NULL, 'aaaaaaaaaa', ' rgegtr', NULL, '95', '100', '5', 'printXcel', NULL, 197, '2023-07-13', '2023-06-27', 523),
(13, 'Promate', 'images/', NULL, 'aaaaaaaaaa', '  ', NULL, '95', '100', '5', 'printXcel', NULL, 116, '', '', 523),
(14, '4792066002802111111', 'images/', NULL, 'dddddddddddd', ' ', NULL, '95', '100', '5', 'printXcel', NULL, 234, '', '', 101),
(15, 'Promate', 'images/', NULL, 'aaaaaaaaaa', ' ', NULL, '95', '100', '5', 'Atles', NULL, 125, '', '', 222),
(17, '44444444444444444444444', 'images/', NULL, '44444444444', ' 444444444444444444', NULL, '95', '100', '5', 'Atles', NULL, 100, '', '', NULL),
(18, '888888888', 'images/', NULL, '88888888888888', ' ', NULL, '95', '100', '5', 'Atles', NULL, 98, '', '', 523),
(19, '6767676767676', 'images/', NULL, '67676767676', ' 76767676767', NULL, '700', '800', '100', 'promate', NULL, 300, '2023-08-31', '2023-08-01', 523);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `transaction_id` int NOT NULL,
  `invoice_number` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `date` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `suplier` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `remarks` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `bcode` int DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `pt` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`transaction_id`, `invoice_number`, `date`, `suplier`, `remarks`, `bcode`, `amount`, `pt`) VALUES
(14, '12345', '2023-03-10', 'printXcel', '1111', NULL, NULL, ''),
(15, '444444', '2023-03-17', 'printXcel', '800', NULL, NULL, ''),
(16, '12345', '2023-03-02', 'printXcel', '800', NULL, NULL, ''),
(17, '555555', '2023-07-12', 'Atles', 'money', NULL, NULL, ''),
(18, '66666', '2023-07-28', 'printXcel', 'rrr', NULL, NULL, ''),
(19, '8888888', '2023-07-30', 'promate', 'A4with A5', NULL, NULL, ''),
(20, '55555', '2023-07-30', 'Atles', '800', NULL, NULL, ''),
(21, '12345', '2023-07-12', 'Atles', '800', 101, NULL, ''),
(22, '1212121', '2023-07-30', 'Atles', '12121', 222, NULL, ''),
(23, '1234545646', '2023-08-02', 'General', '800', 101, NULL, ''),
(24, '12345', '2023-07-31', 'Atles', '1111', 101, NULL, ''),
(25, '12345', '2023-08-01', 'printXcel', '800', 523, NULL, ''),
(26, '12345', '2023-08-01', 'printXcel', '800', 523, NULL, ''),
(27, '565656565', '2023-08-01', 'promate', '565656565', 523, NULL, ''),
(28, '452131', '2023-08-01', 'printXcel', '13646', 523, NULL, ''),
(29, '412356', '2023-08-02', 'Atles', 'yujykj', 523, NULL, ''),
(30, '45225895', '2023-08-02', 'promate', '', 523, NULL, ''),
(31, '1234533', '2023-08-02', 'promate', '', 523, NULL, NULL),
(32, '345', '2023-08-02', 'printXcel', '345dfg', 523, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchases_item`
--

CREATE TABLE `purchases_item` (
  `id` int NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `cost` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `invoice` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases_item`
--

INSERT INTO `purchases_item` (`id`, `name`, `qty`, `cost`, `invoice`) VALUES
(12, '4792066002802', 125, '5000', '12345'),
(13, '4792066002802111', 200, '20000', '444444'),
(14, '4792066002802111', 5, '500', '12345'),
(15, 'rathna 500', 10, '1000', '555555'),
(16, 'Mango', 5, '500', '555555'),
(17, '4792066002802111111', 40, '4000', '555555'),
(18, 'Mango', 50, '5000', '66666'),
(19, 'Mango', 10, '1000', '8888888'),
(20, 'rathna 500', 20, '2000', '8888888'),
(21, 'Promate', 20, '2000', '8888888'),
(22, '4792066002802111111', 10, '1000', '1234545646'),
(23, '4792066002802111111', 10, '1000', '12345'),
(24, '4792066002802111111', 100, '10000', '12345'),
(25, '4792066002802111111', 6, '600', '565656565'),
(26, '4792066002802111111', 3, '300', '452131'),
(27, '4792066002802111111', 3, '300', '412356'),
(28, 'Promate', 4, '400', '412356'),
(29, '4792066002802111111', 4, '400', '1234533'),
(30, 'Promate', 1, '100', '345');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `transaction_id` int NOT NULL,
  `invoice_number` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `cashier` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `date` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `type` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `amount` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `profit` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `due_date` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `balance` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `bcode` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`transaction_id`, `invoice_number`, `cashier`, `date`, `type`, `amount`, `profit`, `due_date`, `name`, `balance`, `bcode`) VALUES
(191, 'SB-396039', 'Admin', '08/01/23', 'cash', '100', '5', '200', 'Customer', NULL, NULL),
(192, 'SB-2233273', 'Admin', '08/01/23', 'credit', '100', '5', '2023-08-23', 'Padmashan Nadeera', NULL, NULL),
(193, 'SB-3034223', 'Admin', '08/01/23', 'cheques', '99', '5', '2023-08-31', 'Customer', NULL, NULL),
(194, 'SB-3063828', 'Admin', '08/01/23', 'Cash', '98', '5', '500', 'Customer', NULL, NULL),
(195, 'SB-2323002', 'Admin', '08/01/23', 'Cash', '100', '5', '100', 'Customer', NULL, NULL),
(196, 'SB-085703', 'Admin', '08/01/23', 'Cash', '100', '5', '500', 'Customer', NULL, NULL),
(197, 'SB-03333', 'Admin', '08/01/23', 'Cash', '100', '5', '200', 'Customer', NULL, NULL),
(198, 'SB-703280', 'Admin', '08/01/23', 'Cash', '100', '5', '500', 'Customer', NULL, NULL),
(199, 'SB-053426', 'Admin', '08/01/23', 'cash', '100', '5', '500', 'Customer', NULL, NULL),
(200, 'SB-70073', 'Admin', '08/01/23', 'credit', '200', '10', '2023-08-16', 'Padmashan Nadeera', NULL, NULL),
(201, 'SB-020', 'Admin', '08/01/23', 'credit', '100', '5', '2023-08-01', 'Padmashan Nadeera', NULL, NULL),
(202, 'SB-0273223', 'Admin', '08/01/23', 'cash', '100', '5', '200', 'Customer', NULL, NULL),
(203, 'SB-6226032', 'Admin', '08/01/23', 'cash', '100', '5', '100', 'Customer', NULL, 523),
(204, 'SB-7232220', 'Admin', '08/01/23', 'credit', '100', '5', '2023-08-16', 'Padmashan Nadeera', NULL, 523),
(205, 'SB-05207327', 'Admin', '08/01/23', 'cash', '100', '5', '300', 'Padmashan Nadeera', NULL, 523),
(206, 'SB-6237822', 'Admin', '08/01/23', 'cheques', '300', '15', '2023-08-01', 'Customer', NULL, 523),
(207, 'SB-73223', 'Admin', '08/01/23', 'credit', '200', '10', '2023-08-02', 'Customer', NULL, 523),
(208, 'SB-342322', 'Admin', '08/01/23', 'credit', '100', '5', '2023-08-01', 'Padmashan Nadeera', NULL, 523);

-- --------------------------------------------------------

--
-- Table structure for table `sales_order`
--

CREATE TABLE `sales_order` (
  `transaction_id` int NOT NULL,
  `invoice` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `product` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `qty` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `amount` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `profit` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `product_code` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `gen_name` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `name` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `price` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `discount` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `date` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_order`
--

INSERT INTO `sales_order` (`transaction_id`, `invoice`, `product`, `qty`, `amount`, `profit`, `product_code`, `gen_name`, `name`, `price`, `discount`, `date`) VALUES
(315, 'RS-59332373', '58', '5', '500', '25', 'Promate', 'A4', '  ', '100', '', '03/08/23'),
(316, 'RS-59332373', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', '', '03/08/23'),
(317, 'RS-3222523', '58', '1', '100', '5', 'Promate', 'A4', '  ', '100', '', '03/08/23'),
(318, 'RS-3222523', '59', '10', '2000', '500', 'Promate', 'A3', ' ', '200', '', '03/08/23'),
(319, 'RS-20339220', '58', '10', '1000', '50', 'Promate', 'A4', '  ', '100', '', '03/08/23'),
(320, 'RS-20339220', '59', '5', '1000', '250', 'Promate', 'A3', ' ', '200', '', '03/08/23'),
(321, 'RS-3288658', '58', '1', '100', '5', 'Promate', 'A4', '  ', '100', '', '03/08/23'),
(323, 'SB-022033', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', '', '03/08/23'),
(324, 'SB-3202433', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(325, 'SB-3202433', '60', '10', '400', '20', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(326, 'SB-3202433', '60', '5', '200', '10', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(329, 'SB-35804200', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(330, 'RS-3303268', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(331, 'RS-3303268', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', '', '03/09/23'),
(332, 'SB-2332024', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(333, 'SB-30022923', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(334, 'SB-30022923', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(335, 'SB-30022923', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', '', '03/09/23'),
(336, 'SB-4200224', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(337, 'SB-0523300', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', '', '03/09/23'),
(338, 'RS-0002332', '60', '5', '200', '10', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(339, 'RS-0002332', '58', '4', '400', '20', 'Promate', 'A4', '  ', '100', '', '03/09/23'),
(340, 'SB-2352330', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(342, 'SB-3026632', '60', '5', '200', '10', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(343, 'SB-3026632', '60', '10', '400', '20', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/09/23'),
(344, 'SB-27353', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/10/23'),
(345, 'RS-933092', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages', '40', '', '03/10/23'),
(346, 'SB-3290343', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages ', '40', NULL, '03/11/23'),
(347, 'SB-3290343', '60', '1', '40', '2', '4792066002802', 'Colouray 80', ' 80 pages ', '40', NULL, '03/11/23'),
(348, 'SB-2002732', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', NULL, '03/11/23'),
(349, 'SB-6220022', '61', '1', '100', '5', '4792066002802111', 'aaaaaaaaaa', ' aaaaaaaaa', '100', NULL, '03/11/23'),
(350, 'SB-2400936', '61', '1', '100', '5', '4792066002802111', 'aaaaaaaaaa', ' aaaaaaaaa', '100', NULL, '03/11/23'),
(351, 'RS-63233', '61', '1', '100', '5', '4792066002802111', 'aaaaaaaaaa', ' aaaaaaaaa', '100', NULL, '03/11/23'),
(352, 'SB-2232023', '61', '1', '100', '5', '4792066002802111', 'aaaaaaaaaa', ' aaaaaaaaa', '100', NULL, '03/11/23'),
(353, '', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', NULL, '03/17/23'),
(354, 'SB-9292538', '58', '10', '1000', '50', 'Promate', 'A4', '  ', '100', NULL, '03/18/23'),
(355, 'SB-49032', '59', '1', '200', '50', 'Promate', 'A3', ' ', '200', NULL, '04/02/23'),
(356, 'SB-870655', '61', '1', '100', '5', '4792066002802111', 'aaaaaaaaaa', ' aaaaaaaaa', '100', NULL, '04/02/23'),
(357, 'RS-080204', '61', '1', '100', '5', '4792066002802111', 'aaaaaaaaaa', ' aaaaaaaaa', '100', NULL, '04/02/23'),
(358, 'RS-080204', '62', '3', '300', '15', '4792066002802111111', 'dddddddddddd', ' ', '100', NULL, '04/02/23'),
(359, 'SB-8030260', '67', '1', '55555555', '55500000', '5555555555', '5555555', ' 55555', '55555555', NULL, '07/07/23'),
(360, 'SB-8030260', '68', '1', '333333333', '330000000', '33333333333', '333333333', ' 3333333', '333333333', NULL, '07/07/23'),
(361, 'SB-8030260', '67', '1', '55555555', '55500000', '5555555555', '5555555', ' 55555', '55555555', NULL, '07/07/23'),
(362, 'SB-8030260', '67', '1', '55555555', '55500000', '5555555555', '5555555', ' 55555', '55555555', NULL, '07/07/23'),
(363, 'SB-8030260', '69', '5', '3500', '1000', '4792066002802111111', 'aaaaaaaaaa', ' gggggggg', '700', NULL, '07/07/23'),
(364, 'SB-3333233', NULL, '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '07/19/23'),
(365, 'SB-3333233', '1', '5', '500', '25', 'Promate', 'aaaaaaaaaa', ' ', '100', NULL, '07/19/23'),
(370, 'SB-3332232', '1', '1', '100', '5', 'Promate', 'aaaaaaaaaa', ' ', '100', NULL, '07/28/23'),
(371, 'SB-2633200', '1', '1', '100', '5', 'Promate', 'aaaaaaaaaa', ' ', '100', NULL, '07/30/23'),
(372, 'SB-2633200', '2', '1', '100', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(373, 'SB-2633200', '8', '1', '100', '5', '4792066002802111111', 'A4', ' ', '100', NULL, '07/30/23'),
(374, 'SB-203290', NULL, '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '07/30/23'),
(375, 'SB-203290', NULL, '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '07/30/23'),
(376, 'SB-203290', NULL, '1', '0', '0', NULL, NULL, NULL, NULL, NULL, '07/30/23'),
(377, 'SB-28333002', '2', '1', '100', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(378, 'SB-28333002', '2', '1', '100', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(379, 'SB-28333002', '1', '1', '100', '5', 'Promate', 'aaaaaaaaaa', ' ', '100', NULL, '07/30/23'),
(380, 'SB-28333002', '2', '1', '100', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(381, 'SB-60302929', '2', '1', '90', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(382, 'SB-2378330', '2', '1', '100', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(383, 'SB-72335225', '2', '1', '90', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(384, 'SB-72335225', '8', '1', '90', '5', '4792066002802111111', 'A4', ' ', '100', NULL, '07/30/23'),
(385, 'SB-00328000', '1', '1', '100', '5', 'Promate', 'aaaaaaaaaa', ' ', '100', NULL, '07/30/23'),
(386, 'SB-00328000', '1', '1', '80', '5', 'Promate', 'aaaaaaaaaa', ' ', '100', NULL, '07/30/23'),
(387, 'SB-00328000', '2', '2', '200', '10', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(388, 'SB-00328000', '2', '2', '180', '10', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(389, 'SB-00328000', '2', '1', '90', '5', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(390, 'SB-00328000', '8', '2', '180', '10', '4792066002802111111', 'A4', ' ', '100', NULL, '07/30/23'),
(391, 'SB-00328000', '2', '2', '180', '10', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(392, 'SB-00328000', '2', '2', '180', '10', 'rathna 500', 'aaaaaaaaaa', '  egtregte4rw', '100', NULL, '07/30/23'),
(394, 'SB-053432', '8', '1', '100', '5', '4792066002802111111', 'A4', ' ', '100', NULL, '07/30/23'),
(395, 'SB-053432', '14', '1', '100', '5', '4792066002802111111', 'dddddddddddd', ' ', '100', NULL, '07/30/23'),
(396, 'SB-92223290', '1', '3', '270', '15', 'Promate', 'aaaaaaaaaa', ' ', '100', NULL, '07/30/23'),
(397, 'SB-92223290', '14', '1', '100', '5', '4792066002802111111', 'dddddddddddd', ' ', '100', NULL, '07/30/23'),
(398, 'SB-34033', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '07/31/23'),
(399, 'SB-9370033', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '07/31/23'),
(400, 'SB-9370033', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '07/31/23'),
(401, 'SB-200723', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '07/31/23'),
(402, 'SB-929202', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '07/31/23'),
(403, 'SB-222033', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '07/31/23'),
(404, 'SB-29073020', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(405, 'SB-29073020', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '08/01/23'),
(406, 'SB-22733', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(407, 'SB-24734333', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(408, 'SB-2473332', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(409, 'SB-38220203', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(410, 'SB-733233', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '08/01/23'),
(411, 'SB-62030', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '08/01/23'),
(412, 'SB-2330653', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(413, 'SB-497243', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(414, 'SB-52330200', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(415, 'SB-52330200', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(416, 'SB-8323403', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(417, 'SB-33025009', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '08/01/23'),
(418, 'SB-0273203', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(419, 'SB-396039', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(420, 'SB-2233273', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(421, 'SB-3034223', '12', '1', '99', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(422, 'SB-232202', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(423, 'SB-3063828', '12', '1', '98', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(424, 'SB-2323002', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(425, 'SB-085703', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(426, 'SB-03333', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(427, 'SB-703280', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(428, 'SB-053426', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(429, 'SB-70073', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(430, 'SB-70073', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(431, 'SB-020', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(432, 'SB-0273223', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(433, 'SB-6226032', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(434, 'SB-7232220', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(435, 'SB-05207327', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '08/01/23'),
(436, 'SB-6237822', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(437, 'SB-6237822', '18', '1', '100', '5', '888888888', '88888888888888', ' ', '100', NULL, '08/01/23'),
(438, 'SB-6237822', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(439, 'SB-73223', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(440, 'SB-73223', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(441, 'SB-333293', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(442, 'SB-333293', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '08/01/23'),
(443, 'SB-333293', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(444, 'SB-333293', '18', '1', '100', '5', '888888888', '88888888888888', ' ', '100', NULL, '08/01/23'),
(445, 'SB-333293', '13', '1', '100', '5', 'Promate', 'aaaaaaaaaa', '  ', '100', NULL, '08/01/23'),
(446, 'SB-333293', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23'),
(447, 'SB-342322', '12', '1', '100', '5', '4792066002802111111', 'aaaaaaaaaa', ' rgegtr', '100', NULL, '08/01/23');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `state_id` int NOT NULL,
  `state` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state`) VALUES
(1, 'Cut'),
(2, 'Sawing');

-- --------------------------------------------------------

--
-- Table structure for table `subcontractor`
--

CREATE TABLE `subcontractor` (
  `subcontractor_id` int NOT NULL,
  `subcontractor_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `subcontractor_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `subcontractor_contact` int DEFAULT NULL,
  `contact_person` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `mode` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subcontractor`
--

INSERT INTO `subcontractor` (`subcontractor_id`, `subcontractor_name`, `subcontractor_address`, `subcontractor_contact`, `contact_person`, `note`, `mode`) VALUES
(1, 'anja', '743/A , Nawetiya', 711461785, 'Padmashan Nadeera', 'fdwsedf', NULL),
(2, 'anja', '743/A , Nawetiya', 711461785, 'Padmashan Nadeera', '', NULL),
(3, 'kkkkkkk', '27 U 1/12', 711461785, 'Padmashan Nadeera', 'kkkkkkk', NULL),
(4, 'dd', '743/A , Nawetiya', 711461785, 'Padmashan Nadeera', 'ddddddddddd', 'Line'),
(5, 'anja', '27 U 1/12', 712818988, 'Padmashan Nadeera', '666', 'Sub');

-- --------------------------------------------------------

--
-- Table structure for table `supliers`
--

CREATE TABLE `supliers` (
  `suplier_id` int NOT NULL,
  `suplier_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `suplier_address` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `suplier_contact` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `contact_person` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `note` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supliers`
--

INSERT INTO `supliers` (`suplier_id`, `suplier_name`, `suplier_address`, `suplier_contact`, `contact_person`, `note`) VALUES
(5, 'printXcel', '743/A , Nawetiya', '1234567854', 'sampath', '145ffff'),
(6, 'Atles', '27 U 1/12, Nugahena waththa', '0711461785', 'nishan', 'efw3fre'),
(7, 'General', 'General', '', '', ''),
(10, 'promate', '31 B , Udawela , Hiswella Kirindiwela', '0711461785', 'samantha', '');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int NOT NULL,
  `invoice_number` int DEFAULT NULL,
  `bcode` int DEFAULT NULL,
  `images` text,
  `supliers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `date` date DEFAULT NULL,
  `o_price` int DEFAULT NULL,
  `price` int DEFAULT NULL,
  `ptype` varchar(100) DEFAULT NULL,
  `remark` text,
  `addeduser` varchar(100) DEFAULT NULL,
  `dueprice` int DEFAULT NULL,
  `mtype` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `invoice_number`, `bcode`, `images`, `supliers`, `date`, `o_price`, `price`, `ptype`, `remark`, `addeduser`, `dueprice`, `mtype`) VALUES
(7, 2324, 523, 'images/', 'Atles', '2023-08-02', 95, 100, 'credit', 'wdwf', 'Admin', 5, 'Outcome');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `username` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `password` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `position` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `bcode` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `phone` int DEFAULT NULL,
  `address` text,
  `images` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `position`, `bcode`, `phone`, `address`, `images`) VALUES
(187, 'my.nadeera@gmail.com', '12345678', 'Padmashan Nadeera', 'admin', '101', 711461785, '27 U 1/12\r\nNugahena waththa', 'images/DSC_0569 copy1.jpg'),
(190, 'admin', '12345678', 'Admin', 'admin', '523', 711461785, '27 U 1/12\r\nNugahena waththa', 'images/dan-4.png');

-- --------------------------------------------------------

--
-- Table structure for table `web_contact`
--

CREATE TABLE `web_contact` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `web_contact`
--

INSERT INTO `web_contact` (`id`, `name`, `email`, `message`) VALUES
(9, 'Padmashan Nadeera', 'my.nadeera@gmail.com', 'gggggggggggggggggggg'),
(10, 'nadeera', 'it18060904@my.sliit.lk', 'asdfgghhjk'),
(11, 'Robertval', 'alfredegov@gmail.com', 'Hi, roeddwn i eisiau gwybod eich pris.'),
(12, 'Robertval', 'alfredegov@gmail.com', 'Ciao, volevo sapere il tuo prezzo.'),
(13, 'Robertval', 'alfredegov@gmail.com', 'Szia, meg akartam tudni az árát.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `colour`
--
ALTER TABLE `colour`
  ADD PRIMARY KEY (`colour_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mode`
--
ALTER TABLE `mode`
  ADD PRIMARY KEY (`mode_id`);

--
-- Indexes for table `payment_type`
--
ALTER TABLE `payment_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `production`
--
ALTER TABLE `production`
  ADD PRIMARY KEY (`production_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `purchases_item`
--
ALTER TABLE `purchases_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `sales_order`
--
ALTER TABLE `sales_order`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `subcontractor`
--
ALTER TABLE `subcontractor`
  ADD PRIMARY KEY (`subcontractor_id`);

--
-- Indexes for table `supliers`
--
ALTER TABLE `supliers`
  ADD PRIMARY KEY (`suplier_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `web_contact`
--
ALTER TABLE `web_contact`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `transaction_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `colour`
--
ALTER TABLE `colour`
  MODIFY `colour_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `mode`
--
ALTER TABLE `mode`
  MODIFY `mode_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payment_type`
--
ALTER TABLE `payment_type`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `production`
--
ALTER TABLE `production`
  MODIFY `production_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `transaction_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `purchases_item`
--
ALTER TABLE `purchases_item`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `transaction_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `sales_order`
--
ALTER TABLE `sales_order`
  MODIFY `transaction_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=448;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `state_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subcontractor`
--
ALTER TABLE `subcontractor`
  MODIFY `subcontractor_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `supliers`
--
ALTER TABLE `supliers`
  MODIFY `suplier_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;

--
-- AUTO_INCREMENT for table `web_contact`
--
ALTER TABLE `web_contact`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
